package kaspi_back_admin.kaspi_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaspiBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
