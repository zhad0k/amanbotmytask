package kaspi_back_admin.kaspi_back.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kaspi_back_admin.kaspi_back.configuration.SecurityConfiguration;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.dto.request.CreateCustomerRequest;
import kaspi_back_admin.kaspi_back.processor.CustomerProcessor;
import kaspi_back_admin.kaspi_back.processor.ModeratorProcessor;
import kaspi_back_admin.kaspi_back.service.CustomerCreateService;
import kaspi_back_admin.kaspi_back.service.impl.ModeratorDetailsServiceImpl;
import kaspi_back_admin.kaspi_back.service.util_services.CustomAuthenticationProvider;
import kaspi_back_admin.kaspi_back.service.util_services.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ModeratorController.class)
@Import(SecurityConfiguration.class)
@ActiveProfiles("local")
class ModeratorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ModeratorProcessor moderatorProcessor;
    @MockitoBean
    private CustomerProcessor customerProcessor;
    @MockitoBean
    private JwtService jwtService;
    @MockitoBean
    private CustomerCreateService customerCreateService;
    @MockitoBean
    private ModeratorDetailsServiceImpl moderatorDetailsService;
    @MockitoBean
    private CustomAuthenticationProvider customAuthenticationProvider;

    @Autowired
    private ObjectMapper objectMapper;

    private String strRequest;

    @BeforeEach
    void setUp() throws JsonProcessingException {
        CreateCustomerRequest request = new CreateCustomerRequest();
        request.setPhone("7001112233");
        request.setPassword("123456");
        strRequest = objectMapper.writeValueAsString(request);
    }

    @Test
    void createCustomer_shouldSucceed_withRoleAdmin() throws Exception {
        when(moderatorProcessor.createCustomer(anyLong(), any(CreateCustomerRequest.class)))
                .thenReturn(Map.of("success", "Пользователь успешно создан"));

        mockMvc.perform(post("/moderators/customers/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .with(authentication(authWithRole("ROLE_ADMIN")))
                        .content(strRequest))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value("Пользователь успешно создан"));
    }

    @Test
    void createCustomer_shouldSucceed_withRoleLeadAdmin() throws Exception {
        when(moderatorProcessor.createCustomer(anyLong(), any(CreateCustomerRequest.class)))
                .thenReturn(Map.of("success", "Пользователь успешно создан"));

        mockMvc.perform(post("/moderators/customers/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .with(authentication(authWithRole("ROLE_LEAD_ADMIN")))
                        .content(strRequest))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value("Пользователь успешно создан"));

        verify(moderatorProcessor).createCustomer(anyLong(), any(CreateCustomerRequest.class));
    }

    @Test
    void createCustomer_shouldFail_withClientRole() throws Exception {
        Customer customer = new Customer();
        customer.setId(1L);
        customer.setPhone("7001112233");
        customer.setPassword("123456");

        Authentication auth = new UsernamePasswordAuthenticationToken(
                customer, null, List.of(new SimpleGrantedAuthority("ROLE_CLIENT"))
        );


        mockMvc.perform(post("/moderators/customers/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .with(authentication(auth))
                        .content(strRequest))
                .andExpect(status().isForbidden());
        verify(moderatorProcessor, never()).createCustomer(anyLong(), any(CreateCustomerRequest.class));
    }

    @Test
    void createCustomer_shouldFailWithoutAuthentication() throws Exception {
        mockMvc.perform(post("/moderators/customers/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(strRequest))
                .andExpect(status().isForbidden());

        verify(moderatorProcessor, never()).createCustomer(anyLong(), any(CreateCustomerRequest.class));
    }

    private Authentication authWithRole(String role) {
        Moderator moderator = new Moderator();
        moderator.setId(1L);
        moderator.setPhone("7001112233");
        moderator.setPassword("123456");

        return new UsernamePasswordAuthenticationToken(
                moderator, null, List.of(new SimpleGrantedAuthority(role))
        );
    }
}