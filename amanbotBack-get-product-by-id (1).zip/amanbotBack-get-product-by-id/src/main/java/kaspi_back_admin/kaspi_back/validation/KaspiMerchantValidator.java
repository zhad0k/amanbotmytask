package kaspi_back_admin.kaspi_back.validation;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.dto.exceptions.UnprocessableEntityException;
import kaspi_back_admin.kaspi_back.dto.request.ChangeSubscriptionRequest;
import kaspi_back_admin.kaspi_back.dto.request.CustomerUpdateRequest;
import kaspi_back_admin.kaspi_back.service.util_services.SecurityContextService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class KaspiMerchantValidator {

    private final SecurityContextService securityContextService;

    public void validateKaspiMerchantUpdate(Customer customer, ChangeSubscriptionRequest request) {
        boolean hasExistingCredentials = customer.hasExistingKaspiCredentials();

        if (!hasExistingCredentials) {
            validateNewCredentialsCreation(request);
        } else {
            validateExistingCredentialsUpdate();
        }
    }

    private void validateNewCredentialsCreation(ChangeSubscriptionRequest request) {
        if (!securityContextService.hasAnyRole("ROLE_ADMIN", "ROLE_LEAD_ADMIN")) {
            throw new AccessDeniedException("Only ADMIN or LEAD_ADMIN can add Kaspi Merchant");
        }

        if (!request.hasCompleteKaspiCredentials()) {
            throw new UnprocessableEntityException(
                "Both kaspiMerchantEmail and kaspiMerchantPassword are required to add new credentials");
        }
    }

    private void validateExistingCredentialsUpdate() {
        if (!securityContextService.hasRole("ROLE_LEAD_ADMIN")) {
            throw new AccessDeniedException("Only LEAD_ADMIN can update existing Kaspi Merchant");
        }
    }

    public void validateKaspiMerchantUpdate(Customer customer, CustomerUpdateRequest request) {
        boolean hasExistingCredentials = customer.hasExistingKaspiCredentials();

        if (!hasExistingCredentials) {
            validateNewCredentialsCreation(request);
        } else {
            validateExistingCredentialsUpdate();
        }
    }

    private void validateNewCredentialsCreation(CustomerUpdateRequest request) {
        if (!securityContextService.hasAnyRole("ROLE_ADMIN", "ROLE_LEAD_ADMIN")) {
            throw new AccessDeniedException("Only ADMIN or LEAD_ADMIN can add Kaspi Merchant");
        }

        if (!request.hasCompleteKaspiCredentials()) {
            throw new UnprocessableEntityException(
                    "Both kaspiMerchantEmail and kaspiMerchantPassword are required to add new credentials");
        }
    }
}