package kaspi_back_admin.kaspi_back.api;

import kaspi_back_admin.kaspi_back.dto.response.DeleteInstanceResponse;
import kaspi_back_admin.kaspi_back.dto.response.GreenApiInstanceResponse;
import kaspi_back_admin.kaspi_back.metrics.ApiMetrics;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class GreenApi {
    private final ApiMetrics apiMetrics;
    private final WebClient.Builder webClientBuilder;

    @Value("${green.api.base-url}")
    private String baseUrl;
    @Value("${green.api.delete-url}")
    private String deleteUrl;


    public List<GreenApiInstanceResponse> getOrders() {
        long start = System.currentTimeMillis();
        try {
            List<GreenApiInstanceResponse> response = webClientBuilder.build()
                    .get()
                    .uri(baseUrl)
                    .retrieve()
                    .bodyToFlux(GreenApiInstanceResponse.class)
                    .collectList()
                    .block();
            apiMetrics.recordSuccessGreenApi(System.currentTimeMillis() - start);
            return response;
        }
        catch (Exception e) {
            apiMetrics.recordErrorGreenApi(System.nanoTime() - start);
            throw e;
        }
    }

    public DeleteInstanceResponse deleteInstance(Long idInstance) {
        long start = System.currentTimeMillis();
        try {

            Map<String, Long> body = Map.of("idInstance", idInstance);

            DeleteInstanceResponse response = webClientBuilder.build()
                    .post()
                    .uri(deleteUrl)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(DeleteInstanceResponse.class)
                    .block();
            apiMetrics.recordSuccessGreenApi(System.currentTimeMillis() - start);
            return response;
        }
        catch (Exception e) {
            apiMetrics.recordErrorGreenApi(System.nanoTime() - start);
            throw e;
        }
    }

}
