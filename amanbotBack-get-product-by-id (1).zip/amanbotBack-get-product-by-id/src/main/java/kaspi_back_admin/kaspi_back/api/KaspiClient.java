package kaspi_back_admin.kaspi_back.api;


import kaspi_back_admin.kaspi_back.dto.response.KaspiOrderEntriesResponse;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrdersResponse;
import kaspi_back_admin.kaspi_back.dto.response.KaspiMasterProductResponse;
import kaspi_back_admin.kaspi_back.metrics.ApiMetrics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;



@Component
@RequiredArgsConstructor
@Slf4j
public class KaspiClient {

    private final ApiMetrics apiMetrics;
    private final WebClient.Builder webClientBuilder;

    @Value("${kaspi.api.base-url:https://kaspi.kz/shop/api/v2}")
    private String baseUrl;

    @Value("${kaspi.api.base-url:https://kaspi.kz/shop/api}")
    private String apiUrl;

    public KaspiOrdersResponse getOrders(String token, String query) {
        long startTime = System.currentTimeMillis();
        try{
            KaspiOrdersResponse response = webClientBuilder.build()
                    .get()
                    .uri(baseUrl + "/orders" + query)
                    .header("X-Auth-Token", token)
                    .accept(MediaType.valueOf("application/vnd.api+json"))
                    .retrieve()
                    .bodyToMono(KaspiOrdersResponse.class)
                    .block();
            apiMetrics.recordKaspiSuccess(System.currentTimeMillis()-startTime);
            return response;
        }
        catch (Exception e){
            apiMetrics.recordKaspiError(System.currentTimeMillis() - startTime);
            throw e;
        }
    }

    public KaspiOrderEntriesResponse getOrderEntries(String token, String orderId) {
        long startTime = System.currentTimeMillis();
        try {
            KaspiOrderEntriesResponse response = webClientBuilder.build()
                    .get()
                    .uri(baseUrl + "/orders/" + orderId + "/entries")
                    .header("X-Auth-Token", token)
                    .accept(MediaType.valueOf("application/vnd.api+json"))
                    .retrieve()
                    .bodyToMono(KaspiOrderEntriesResponse.class)
                    .block();
            apiMetrics.recordKaspiSuccess(System.currentTimeMillis()-System.currentTimeMillis());
            return response;
        }
        catch (Exception e){
            apiMetrics.recordKaspiError(System.currentTimeMillis() - startTime);
            throw e;
        }
    }

    public KaspiMasterProductResponse getMasterProduct(String token, String masterProductId) {
        long startTime = System.currentTimeMillis();
        try{
        KaspiMasterProductResponse response = webClientBuilder.build()
                .get()
                .uri(baseUrl + "/masterproducts/" + masterProductId)
                .header("X-Auth-Token", token)
                .accept(MediaType.valueOf("application/vnd.api+json"))
                .retrieve()
                .bodyToMono(KaspiMasterProductResponse.class)
                .block();
        apiMetrics.recordKaspiSuccess(System.currentTimeMillis()-System.currentTimeMillis());
        return response;}
        catch (Exception e){
            apiMetrics.recordKaspiError(System.currentTimeMillis() - startTime);
            throw e;
        }
    }

    public byte[] downloadWaybillPdf(String token, String waybillUrl) {
        long start = System.currentTimeMillis();

        try {
            return webClientBuilder.build()
                    .get()
                    .uri(waybillUrl)
                    .header("X-Auth-Token", token)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36")
                    .header("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7")
                    .header("Referer", "https://kaspi.kz/")
                    .header("Accept", "application/pdf,application/octet-stream;q=0.9,*/*;q=0.8")
                    .exchangeToMono(resp -> {
                        int code = resp.statusCode().value();
                        String ct = resp.headers().contentType().map(Object::toString).orElse("n/a");

                        String location = resp.headers().asHttpHeaders().getFirst("Location");

                        return resp.bodyToMono(byte[].class)
                                .defaultIfEmpty(new byte[0])
                                .<byte[]>handle((body, sink) -> {
                                    if (code >= 400) {
                                        String head = new String(body, 0, Math.min(body.length, 300));
                                        sink.error(new IllegalStateException(
                                                "Kaspi waybill error: status=" + code +
                                                        " contentType=" + ct +
                                                        (location != null ? " location=" + location : "") +
                                                        " bodyHead=" + head
                                        ));
                                        return;
                                    }

                                    if (ct.contains("text/html") || !isPdf(body)) {
                                        String head = new String(body, 0, Math.min(body.length, 300));
                                        sink.error(new IllegalStateException(
                                                "Kaspi waybill not a PDF: status=" + code +
                                                        " contentType=" + ct +
                                                        " bodyHead=" + head
                                        ));
                                        return;
                                    }

                                    sink.next(body);
                                });
                    })
                    // ретраи только на 5xx и сетевые ошибки
                    .retryWhen(reactor.util.retry.Retry.backoff(3, java.time.Duration.ofMillis(300))
                            .maxBackoff(java.time.Duration.ofSeconds(3))
                            .filter(ex -> ex instanceof java.io.IOException
                                    || (ex.getMessage() != null && ex.getMessage().contains("status=5"))))
                    .block();

        } finally {
            long ms = System.currentTimeMillis() - start;
            apiMetrics.recordKaspiSuccess(ms);
        }
    }

    private boolean isPdf(byte[] bytes) {
        return bytes != null && bytes.length >= 4
                && bytes[0] == 0x25 && bytes[1] == 0x50 && bytes[2] == 0x44 && bytes[3] == 0x46;
    }

}
