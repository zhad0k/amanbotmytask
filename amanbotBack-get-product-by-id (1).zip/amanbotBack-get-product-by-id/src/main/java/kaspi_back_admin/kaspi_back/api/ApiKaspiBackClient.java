package kaspi_back_admin.kaspi_back.api;

import kaspi_back_admin.kaspi_back.configuration.FeignLongWaitConfig;
import kaspi_back_admin.kaspi_back.dto.request.AssembleAndRefreshRequest;
import kaspi_back_admin.kaspi_back.dto.response.AssembleAndRefreshResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = "kaspi-back-admin",
//        url = "http://localhost:8070",
        url = "https://kaspi-admin.aman.kz",
        configuration = FeignLongWaitConfig.class
)
public interface ApiKaspiBackClient {

    @PostMapping("/kaspi/assemble-and-refresh")
    AssembleAndRefreshResponse assembleAndRefresh(@RequestParam Long customerId,
                                                  @RequestBody AssembleAndRefreshRequest request);

    @PostMapping("kaspi/test")
    String syncOrders(@RequestParam Long customerId);
}