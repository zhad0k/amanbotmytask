package kaspi_back_admin.kaspi_back.mapper;

import io.micrometer.common.lang.Nullable;
import kaspi_back_admin.kaspi_back.db.entities.City;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.entities.ProductPreorder;
import kaspi_back_admin.kaspi_back.db.entities.ProductStock;
import kaspi_back_admin.kaspi_back.db.repository.CityRepository;
import kaspi_back_admin.kaspi_back.dto.CityStocksDto;
import kaspi_back_admin.kaspi_back.dto.InventoryDto;
import kaspi_back_admin.kaspi_back.dto.PointDto;
import kaspi_back_admin.kaspi_back.dto.PreorderDto;
import kaspi_back_admin.kaspi_back.dto.StockDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ProductPreorderMapper {

    private final CityRepository cityRepository;
    public InventoryDto toInventoryDto(Map<String, ProductPreorder> preorders, Product product) {
        InventoryDto dto = new InventoryDto();
        dto.setProductId(product.getId());
        dto.setCustomerId(product.getCustomer().getId());
        dto.setTitle(product.getTitle());
        dto.setPhotoUrl(product.getUrlImage());
        dto.setKaspiCardUrl(product.getProductCardLongUrl());
        dto.setCityName(product.getCityName());

        Map<String, ProductPreorder> safePreorders =
                preorders == null ? Collections.emptyMap() : preorders;

        List<StockDto> stock = product.getStocks() == null
                ? Collections.emptyList()
                : product.getStocks().stream()
                .map(ps -> {
                    String stockName = ps.getStoreId();
                    ProductPreorder preorder = safePreorders.getOrDefault(
                            stockName,
                            ProductPreorder.builder()
                                    .preorderDays(0)
                                    .preorderCount(0)
                                    .build()
                            );
                    return new StockDto(
                            extractPointCode(stockName),
                            ps.getStock() == null ? null : ps.getStock(),
                            ps.getMinimalStock(),
                            ps.getStockByCustomer() == null ? null : ps.getStockByCustomer(),
                            ps.getAction(),
                            preorder.getPreorderDays(),
                            preorder.getPreorderCount(),
                            (Boolean.TRUE.equals(ps.getStockSpecified()))

                    );
                })
                .toList();
        dto.setStock(stock);

        return dto;
    }

    public PreorderDto toDto(@Nullable Map<String, ProductPreorder> preorders, Product product) {
        return PreorderDto.builder()
                .productId(product.getId())
                .customerId(product.getCustomer().getId())
                .price(product.getPrice())

                .title(product.getTitle())
                .photoUrl(product.getUrlImage())
                .kaspiCardUrl(product.getProductCardLongUrl())
                .cities(toCityStocksList(preorders, product))
                .build();
    }

    /** Bulk-friendly вариант: принимает заранее загруженную карту cityId→name, не делает запросов в БД. */
    public PreorderDto toDto(@Nullable Map<String, ProductPreorder> preorders, Product product,
                             Map<String, String> cityNamesById) {
        return PreorderDto.builder()
                .id(product.getId())
                .productId(product.getId())
                .customerId(product.getCustomer().getId())
                .price(product.getPrice())
                .isPreorderActive(preorders != null && !preorders.isEmpty())
                .title(product.getTitle())
                .photoUrl(product.getUrlImage())
                .kaspiCardUrl(product.getProductCardLongUrl())
                .cities(toCityStocksList(preorders, product, cityNamesById))
                .build();
    }

    public List<PreorderDto> toDtoList(List<Map<String, ProductPreorder>> preorders,
                                       Map<Long, Product> productById) {
        return preorders.stream()
                .map(pp -> toDto(pp, productById.get(
                        pp.values().stream().toList().get(0).getProductId())))
                .collect(Collectors.toList());
    }

    private List<CityStocksDto> toCityStocksList(@Nullable Map<String, ProductPreorder> preorders, Product product,
                                                 Map<String, String> cityNamesById) {
        Map<String, ProductPreorder> safePreorders = preorders != null ? preorders : new HashMap<>();

        Map<String, List<ProductStock>> stocksByCity = product.getStocks().stream()
                .collect(Collectors.groupingBy(
                        ps -> ps.getCityId() != null ? ps.getCityId() : ""
                ));

        return stocksByCity.entrySet().stream()
                .map(entry -> {
                    String cityId = entry.getKey().isBlank() ? null : entry.getKey();
                    String cityName = cityId != null ? cityNamesById.get(cityId) : null;

                    List<PointDto> points = entry.getValue().stream()
                            .map(stock -> {
                                ProductPreorder pp = safePreorders.get(stock.getStoreId());
                                int days = pp != null && pp.getPreorderDays() != null ? pp.getPreorderDays() : 0;
                                int count = pp != null && pp.getPreorderCount() != null ? pp.getPreorderCount() : 0;
                                return toPointDto(stock, days, count);
                            })
                            .toList();

                    return CityStocksDto.builder()
                            .cityId(cityId)
                            .cityName(cityName)
                            .points(points)
                            .build();
                })
                .toList();
    }

    private List<CityStocksDto> toCityStocksList(@Nullable Map<String, ProductPreorder> preorders, Product product) {
        Map<String, ProductPreorder> safePreorders = preorders != null ? preorders : new HashMap<>();

        // Группируем склады по cityId
        Map<String, List<ProductStock>> stocksByCity = product.getStocks().stream()
                .collect(Collectors.groupingBy(
                        ps -> ps.getCityId() != null ? ps.getCityId() : ""
                ));

        // Загружаем названия городов одним запросом
        Set<String> cityIds = stocksByCity.keySet().stream()
                .filter(id -> !id.isBlank())
                .collect(Collectors.toSet());
        Map<String, String> cityNames = cityRepository.findAllById(cityIds).stream()
                .collect(Collectors.toMap(City::getId, City::getName));

        return stocksByCity.entrySet().stream()
                .map(entry -> {
                    String cityId = entry.getKey().isBlank() ? null : entry.getKey();
                    String cityName = cityId != null ? cityNames.get(cityId) : null;

                    List<PointDto> points = entry.getValue().stream()
                            .map(stock -> {
                                ProductPreorder pp = safePreorders.get(stock.getStoreId());
                                int days = pp != null && pp.getPreorderDays() != null ? pp.getPreorderDays() : 0;
                                int count = pp != null && pp.getPreorderCount() != null ? pp.getPreorderCount() : 0;
                                return toPointDto(stock, days, count);
                            })
                            .toList();

                    return CityStocksDto.builder()
                            .cityId(cityId)
                            .cityName(cityName)
                            .points(points)
                            .build();
                })
                .toList();
    }

    private PointDto toPointDto(ProductStock productStock, Integer preorderDays, Integer preorderCount) {
        return PointDto.builder()
                .point(productStock.getPoint())
                .cityId(productStock.getCityId())
                .quantity(toInt(productStock.getStock()))
                .minimalStock(toInt(productStock.getMinimalStock()))
                .stockByCustomer(toInt(productStock.getStockByCustomer()))
                .action(productStock.getAction())
                .preorderDays(toInt(preorderDays))
                .preorderCount(toInt(preorderCount))
                .stockSpecified(Boolean.TRUE.equals(productStock.getStockSpecified()))
                .build();
    }

    private String extractPointCode(String storeId) {
        if (storeId == null) {
            return null;
        }
        int idx = storeId.lastIndexOf('_');
        return idx >= 0 ? storeId.substring(idx + 1) : storeId;
    }

    private Integer toInt(Long value) {
        return value != null ? Math.toIntExact(value) : null;
    }

    private Integer toInt(Integer value) {
        return value;
    }
}