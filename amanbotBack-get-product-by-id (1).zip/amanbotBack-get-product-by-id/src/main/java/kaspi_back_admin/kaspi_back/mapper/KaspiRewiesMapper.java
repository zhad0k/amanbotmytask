package kaspi_back_admin.kaspi_back.mapper;


import kaspi_back_admin.kaspi_back.db.entities.KaspiReview;
import kaspi_back_admin.kaspi_back.dto.KaspiReviewDto;
import org.springframework.stereotype.Component;

@Component
public class KaspiRewiesMapper {

    public KaspiReviewDto fromEntity(KaspiReview kaspiReview,String phone) {
        if (kaspiReview == null) {
            return null;
        }
        KaspiReviewDto dto = new KaspiReviewDto();
        dto.setKaspiMessageText(kaspiReview.getKaspiMessageText());
        dto.setCustomerPhone(phone);
        dto.setSentAt(kaspiReview.getCreatedDate());
        return dto;
    }
}
