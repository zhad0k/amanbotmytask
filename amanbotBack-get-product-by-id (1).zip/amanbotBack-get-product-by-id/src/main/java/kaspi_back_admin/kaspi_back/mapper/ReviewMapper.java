package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.Review;
import kaspi_back_admin.kaspi_back.dto.ReviewDto;
import org.springframework.stereotype.Component;

@Component
public class ReviewMapper {

    public ReviewDto toReviewDto(Review review) {
        if(review == null) {return null;}
        ReviewDto reviewDto = new ReviewDto();
        reviewDto.setId(review.getId());
        reviewDto.setContent(review.getContent());
        reviewDto.setScore(review.getScore());
        reviewDto.setCreatedDate(review.getCreatedDate());
        reviewDto.setUpdatedDate(review.getUpdateDate());
        reviewDto.setCustomerName(review.getCustomer().getFullName());
        return reviewDto;
    }
}
