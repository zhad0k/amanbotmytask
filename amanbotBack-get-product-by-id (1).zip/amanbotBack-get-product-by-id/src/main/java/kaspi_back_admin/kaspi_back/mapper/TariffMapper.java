package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.dto.BillingOptionDto;
import kaspi_back_admin.kaspi_back.dto.TariffDto;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class TariffMapper {

    private static final Map<TariffType, Map<TariffType.BillingPlan, Long>> PRICE_OVERRIDES = Map.ofEntries(
//           VIP Tariff
            Map.entry(
                    TariffType.VIP_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 49_999L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 99_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 224_999L
                    )
            ),
            Map.entry(
                    TariffType.VIP_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 64_999L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 179_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 269_999L
                    )
            ),
            Map.entry(
                    TariffType.VIP_UP_TO_500,
                    Map.of(
                        TariffType.BillingPlan.TWO_PLUS_ONE, 104_999L,
                        TariffType.BillingPlan.FOUR_PLUS_TWO, 209_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 314_999L
                    )
            ),
            Map.entry(
                    TariffType.VIP_UNLIMITED,
                    Map.of(
                        TariffType.BillingPlan.TWO_PLUS_ONE, 157_999L,
                        TariffType.BillingPlan.FOUR_PLUS_TWO, 314_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 471_999L
                    )
            ),

            Map.entry(
                    TariffType.VIP_COMBO_UP_TO_50,
                    Map.of(
                        TariffType.BillingPlan.TWO_PLUS_ONE, 59_999L,
                        TariffType.BillingPlan.FOUR_PLUS_TWO, 109_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 234_999L
                    )
            ),

            Map.entry(
                    TariffType.VIP_COMBO_UP_TO_200,
                    Map.of(
                        TariffType.BillingPlan.TWO_PLUS_ONE, 74_999L,
                        TariffType.BillingPlan.FOUR_PLUS_TWO, 189_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 279_999L
                    )
            ),

            Map.entry(
                    TariffType.VIP_COMBO_UP_TO_500,
                    Map.of(
                        TariffType.BillingPlan.TWO_PLUS_ONE, 114_999L,
                        TariffType.BillingPlan.FOUR_PLUS_TWO, 219_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 324_999L
                    )
            ),

            Map.entry(
                    TariffType.VIP_COMBO_UNLIMITED,
                    Map.of(
                        TariffType.BillingPlan.TWO_PLUS_ONE, 167_999L,
                        TariffType.BillingPlan.FOUR_PLUS_TWO, 324_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 481_999L
                    )
            ),
//            Damping tariff

            Map.entry(
                    TariffType.DAMPING_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 19_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 59_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 89_999L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 44_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 89_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 134_999L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_UP_TO_500,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 59_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 119_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 179_999L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_UNLIMITED,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 97_499L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 194_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 292_499L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 39_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 119_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 179_999L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 74_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 149_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 224_999L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UP_TO_500,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 89_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 179_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 269_999L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UNLIMITED,
                    Map.of(
                        TariffType.BillingPlan.THREE_PLUS_ONE, 127_499L,
                        TariffType.BillingPlan.SIX_PLUS_TWO, 254_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 382_499L
                    )
            ),
//            Notification tariff
            Map.entry(
                    TariffType.NOTIFICATION_BASIC,
                    Map.of(
                        TariffType.BillingPlan.THREE_PLUS_ONE, 29_999L,
                        TariffType.BillingPlan.SIX_PLUS_TWO, 89_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 134_999L
                    )
            ),
            Map.entry(
                    TariffType.NOTIFICATION_BASIC_PLUS,
                    Map.of(
                        TariffType.BillingPlan.THREE_PLUS_ONE, 59_999L,
                        TariffType.BillingPlan.SIX_PLUS_TWO, 119_999L,
                        TariffType.BillingPlan.NINE_PLUS_THREE, 179_999L
                    )
            ),
            Map.entry(
                    TariffType.NOTIFICATION_PRO,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 49_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 149_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 224_999L
                    )
            ),
            Map.entry(
                    TariffType.NOTIFICATION_PRO_PLUS,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 89_999L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 179_999L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 269_999L
                    )
            )
    );

    private static final Map<TariffType, Map<TariffType.BillingPlan, Long>> BASE_PRICE_OVERRIDES = Map.ofEntries(

            /* ===================== VIP ===================== */

            Map.entry(
                    TariffType.VIP_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 75_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 150_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 360_000L
                    )
            ),
            Map.entry(
                    TariffType.VIP_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 90_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 240_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 360_000L
                    )
            ),
            Map.entry(
                    TariffType.VIP_UP_TO_500,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 135_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 280_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 420_000L
                    )
            ),
            Map.entry(
                    TariffType.VIP_UNLIMITED,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 210_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 420_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 630_000L
                    )
            ),

            /* =============== VIP COMBO+ ================= */

            Map.entry(
                    TariffType.VIP_COMBO_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 85_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 160_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 310_000L
                    )
            ),
            Map.entry(
                    TariffType.VIP_COMBO_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 100_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 250_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 370_000L
                    )
            ),
            Map.entry(
                    TariffType.VIP_COMBO_UP_TO_500,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 135_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 280_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 420_000L
                    )
            ),
            Map.entry(
                    TariffType.VIP_COMBO_UNLIMITED,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 220_000L,
                            TariffType.BillingPlan.FOUR_PLUS_TWO, 430_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 640_000L
                    )
            ),

            /* ================== DAMPING ================== */

            Map.entry(
                    TariffType.DAMPING_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 30_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 80_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 120_000L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 60_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 120_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 180_000L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_UP_TO_500,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 80_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 160_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 240_000L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_UNLIMITED,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 130_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 260_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 390_000L
                    )
            ),

            /* ============== DAMPING PRO ================= */

            Map.entry(
                    TariffType.DAMPING_PRO_UP_TO_50,
                    Map.of(
                            TariffType.BillingPlan.TWO_PLUS_ONE, 60_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 160_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 200_000L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UP_TO_200,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 100_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 200_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 300_000L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UP_TO_500,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 120_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 240_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 360_000L
                    )
            ),
            Map.entry(
                    TariffType.DAMPING_PRO_UNLIMITED,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 170_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 340_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 510_000L
                    )
            ),

            /* =============== NOTIFICATION ================= */

            Map.entry(
                    TariffType.NOTIFICATION_BASIC,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 45_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 120_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 180_000L
                    )
            ),
            Map.entry(
                    TariffType.NOTIFICATION_BASIC_PLUS,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 80_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 160_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 240_000L
                    )
            ),
            Map.entry(
                    TariffType.NOTIFICATION_PRO,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 75_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 200_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 300_000L
                    )
            ),
            Map.entry(
                    TariffType.NOTIFICATION_PRO_PLUS,
                    Map.of(
                            TariffType.BillingPlan.THREE_PLUS_ONE, 120_000L,
                            TariffType.BillingPlan.SIX_PLUS_TWO, 240_000L,
                            TariffType.BillingPlan.NINE_PLUS_THREE, 360_000L
                    )
            )
    );

    public TariffDto toTariffDto(TariffType tariff) {
        long monthlyPrice = tariff.getMonthlyPriceKzt();

        List<BillingOptionDto> billingOptions = getBillingPlansForTariff(tariff).stream()
                .map(plan -> toBillingOptionDto(tariff, plan, monthlyPrice))
                .collect(Collectors.toList());

        return new TariffDto(
                tariff.name(),
                tariff.getKind(),
                tariff.getTier(),
                tariff.getDisplayName(),
                monthlyPrice,
                billingOptions
        );
    }

    List<TariffType.BillingPlan> getBillingPlansForTariff(TariffType tariff) {
        if  (tariff.getKind().equals(TariffType.Kind.NOTIFICATION)) {
            return List.of(
                    TariffType.BillingPlan.ONE_MONTH,
                    TariffType.BillingPlan.THREE_PLUS_ONE,
                    TariffType.BillingPlan.SIX_PLUS_TWO,
                    TariffType.BillingPlan.NINE_PLUS_THREE
            );
        } else if (tariff.getKind().equals(TariffType.Kind.DAMPING)) {
            if(tariff.getTier().equals(TariffType.ProductTier.UP_TO_50)){
                return List.of(
                        TariffType.BillingPlan.ONE_MONTH,
                        TariffType.BillingPlan.TWO_PLUS_ONE,
                        TariffType.BillingPlan.SIX_PLUS_TWO,
                        TariffType.BillingPlan.NINE_PLUS_THREE
                );
            }else {
                return List.of(
                        TariffType.BillingPlan.ONE_MONTH,
                        TariffType.BillingPlan.THREE_PLUS_ONE,
                        TariffType.BillingPlan.SIX_PLUS_TWO,
                        TariffType.BillingPlan.NINE_PLUS_THREE
                );
            }
        } else if (tariff.getKind().equals(TariffType.Kind.VIP)) {
            return List.of(
                    TariffType.BillingPlan.TWO_PLUS_ONE,
                    TariffType.BillingPlan.FOUR_PLUS_TWO,
                    TariffType.BillingPlan.NINE_PLUS_THREE
            );
        } else{
            return null;
        }
    }

    private Optional<Long> overridePriceToPayIfAny(TariffType tariff, TariffType.BillingPlan plan) {
        return Optional.ofNullable(PRICE_OVERRIDES.get(tariff))
                .map(planMap -> planMap.get(plan));
    }

    private Optional<Long> overrideBasePriceIfAny(TariffType tariff, TariffType.BillingPlan plan) {
        return Optional.ofNullable(BASE_PRICE_OVERRIDES.get(tariff))
                .map(planMap -> planMap.get(plan));
    }


    private BillingOptionDto toBillingOptionDto(TariffType tariff,
                                                TariffType.BillingPlan plan,
                                                long monthlyPrice) {
        long priceToPay = overridePriceToPayIfAny(tariff, plan)
                .orElse(plan.priceToPay(monthlyPrice));

        long priceIfMonthly = overrideBasePriceIfAny(tariff, plan)
                .orElse(plan.priceIfPaidMonthly(monthlyPrice));

        long saving = Math.max(0, priceIfMonthly - priceToPay - 1);

        return new BillingOptionDto(
                plan.getLabel(),
                plan.getMonthsToPay(),
                plan.getTotalMonths(),
                priceToPay,
                priceIfMonthly,
                saving
        );
    }
}