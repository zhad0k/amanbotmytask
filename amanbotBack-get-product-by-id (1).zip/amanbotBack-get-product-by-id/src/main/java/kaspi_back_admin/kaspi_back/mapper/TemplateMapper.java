package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.Template;
import kaspi_back_admin.kaspi_back.dto.TemplateDto;
import org.springframework.stereotype.Component;

@Component
public class TemplateMapper {
    public TemplateDto toDto(Template template,boolean disabled) {
        return new TemplateDto(
                template.getId(),
                template.getValue(),
                template.getValueKz(),
                template.getType().name(),
                disabled
        );
    }
}
