package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.CustomerLiteEntity;
import kaspi_back_admin.kaspi_back.db.entities.Order;
import kaspi_back_admin.kaspi_back.db.entities.OrderEntry;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.dto.WaybillDto;
import kaspi_back_admin.kaspi_back.dto.WaybillItemDto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WaybillMapper {

    public static WaybillDto toWaybillDto(Order order, Map<String, Product> productByOfferCode) {
        WaybillDto dto = new WaybillDto();
        dto.setCode(order.getCode());
        dto.setPrice(order.getTotalPrice());
        dto.setStatus(order.getStatus());
        dto.setReceiptDate(order.getCreationDate());
        dto.setAssemble(order.getAssembled());

        // Накладная
        dto.setWaybillNumber(order.getWaybillNumber());
        dto.setWaybillReady(order.getWaybillUrl() != null && !order.getWaybillUrl().isBlank());
        dto.setKaspiExpress(order.getKaspiExpress());

        // Доставка / получатель
        dto.setDeliveryMode(order.getDeliveryMode());
        dto.setPlannedDeliveryDate(order.getPlannedDeliveryDate());
        dto.setCity(order.getOriginCityName());
        dto.setDeliveryAddress(order.getDeliveryFormattedAddress());

        CustomerLiteEntity cli = order.getCustomerLite();
        if (cli != null) {
            dto.setRecipientName(cli.getName());
        }

        // Товары
        List<WaybillItemDto> items = new ArrayList<>();
        if (order.getEntries() != null) {
            for (OrderEntry e : order.getEntries()) {
                Product p = (e.getOfferCode() == null) ? null
                        : productByOfferCode.get(e.getOfferCode());

                String photo = null;
                if (p != null) {
                    photo = (p.getPhotoUrl() != null && !p.getPhotoUrl().isBlank())
                            ? p.getPhotoUrl()
                            : p.getUrlImage();
                }

                String name = (e.getOfferName() != null && !e.getOfferName().isBlank())
                        ? e.getOfferName()
                        : (p != null ? p.getTitle() : null);

                items.add(new WaybillItemDto(
                        e.getOfferCode(),
                        name,
                        photo,
                        e.getQuantity(),
                        e.getTotalPrice()
                ));
            }
        }
        dto.setItems(items);
        dto.setItemsCount(items.size());

        return dto;
    }
}
