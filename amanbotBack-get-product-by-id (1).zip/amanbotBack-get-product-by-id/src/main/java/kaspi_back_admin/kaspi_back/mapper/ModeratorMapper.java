package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.dto.ModeratorDto;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ModeratorMapper {
    @Value("${admin.url}")
    private String adminUrl;

       public ModeratorDto toModeratorDTO(Moderator moderator) {
           ModeratorDto dto = new ModeratorDto();
           dto.setEmail(moderator.getEmail());
           dto.setName(moderator.getUsername());
           dto.setPhone(moderator.getPhone());
           dto.setImageUrl(adminUrl + moderator.getImageUrl());
           dto.setImageName(moderator.getImageName());
           return dto;
       }
   }