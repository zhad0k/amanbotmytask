package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.ZoneOffset;

public class CustomerRowMapper implements RowMapper<Customer> {
    @Override
    public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
        String type = rs.getString("tariff");
        Timestamp ts = rs.getTimestamp("tariff_start_at");
        Timestamp ts2 = rs.getTimestamp("tariff_start_at_dumping");
        Timestamp te = rs.getTimestamp("tariff_end_at");
        Timestamp te2 = rs.getTimestamp("tariff_end_at_dumping");
        Customer customer = new Customer();
        customer.setId(rs.getLong("id"));
        customer.setEmail(rs.getString("email"));
        customer.setPhone(rs.getString("phone"));
        customer.setKaspiEmailMerchant(rs.getString("kaspi_email_merchant"));
        customer.setKaspiPasswordMerchant(rs.getString("kaspi_password_merchant"));
        customer.setKaspiPassword(rs.getString("kaspi_password"));
        customer.setKaspiEmail(rs.getString("kaspi_email"));
        customer.setActive(rs.getBoolean("is_active"));
        customer.setIpName(rs.getString("ip_name"));
        customer.setFullName(rs.getString("full_name"));
        customer.setIdInstance(rs.getObject("id_instance", Long.class));
        customer.setHasKaspiMerchantPassword(rs.getObject("has_kaspi_password", Boolean.class));
        customer.setKaspiPhone(rs.getString("kaspi_phone"));
        customer.setTokenProd(rs.getString("token_prod"));
        customer.setTariffType(type != null ? TariffType.valueOf(type) : null);
        customer.setTariffStartAt(ts != null ? ts.toInstant().atOffset(ZoneOffset.UTC) : null);
        customer.setTariffEndAt(te != null ? te.toInstant().atOffset(ZoneOffset.UTC) : null);
        customer.setTariffStartAtDumping(ts2 != null ? ts2.toInstant().atOffset(ZoneOffset.UTC) : null);
        customer.setTariffEndAtDumping(te2 != null ? te2.toInstant().atOffset(ZoneOffset.UTC) : null);
        customer.setPreorderEnabled(rs.getObject("is_preorder_enabled", Boolean.class));
        customer.setInventoryEnabled(rs.getObject("is_inventory_enabled", Boolean.class));
        customer.setWaybillEnabled(rs.getObject("is_waybill_enabled", Boolean.class));
        Boolean isTrial = rs.getObject("is_trial", Boolean.class);
        customer.setIsTrial(isTrial);
        Long moderatorId = rs.getLong("m_id");

        if (!rs.wasNull()) {
            Moderator moderator = new Moderator();
            moderator.setId(moderatorId);
            moderator.setUsername(rs.getString("m_username"));
            moderator.setPhone(rs.getString("m_phone"));
            moderator.setEmail(rs.getString("m_email"));
            moderator.setImageName(rs.getString("m_image_name"));
            moderator.setImageUrl(rs.getString("m_image_url"));

            customer.setModerator(moderator);
        }
        return customer;
    }
}
