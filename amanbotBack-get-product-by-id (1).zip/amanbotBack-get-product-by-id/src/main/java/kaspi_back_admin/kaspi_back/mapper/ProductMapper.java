package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.*;
import kaspi_back_admin.kaspi_back.db.entities.City;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.entities.ProductCategory;
import kaspi_back_admin.kaspi_back.db.entities.ProductPreorder;
import kaspi_back_admin.kaspi_back.db.entities.ProductStock;
import kaspi_back_admin.kaspi_back.db.repository.CityRepository;
import kaspi_back_admin.kaspi_back.db.repository.ProductPreorderRepository;
import kaspi_back_admin.kaspi_back.dto.PointDto;
import kaspi_back_admin.kaspi_back.dto.ProductDto;
import kaspi_back_admin.kaspi_back.dto.response.CustomerProductInfoResponse;
import kaspi_back_admin.kaspi_back.dto.response.ProductInfoResponse;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import lombok.AllArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
public class ProductMapper {
    private final ProductPreorderRepository productPreorderRepository;
    private final CityRepository cityRepository;

    public ProductDto toProductDto(Product product) {
        if (product == null) {
            return null;
        }
        Long reservedRemainders = product.getStocks() == null
                ? 0L
                : product.getStocks().stream()
                .map(ProductStock::getStock)
                .filter(Objects::nonNull)
                .reduce(0L, Long::sum);
        return ProductDto.builder()
                .id(product.getId())
                .productCardLongUrl(product.getProductCardLongUrl())
                .title(product.getTitle())
                .reservedRemainders(reservedRemainders)
                .totalRemainders(product.getCalculatedRemainders())
                .price(product.getPrice())
                .minPrice(product.getMinPrice())
                .maxPrice(product.getMaxPrice())
                .url(product.getUrlImage())
                .priceAutoChange(product.isPriceAutoChange())
                .available(product.isAvailable())
                .currentPricePlace(product.getPlace() != null
                        ? product.getPlace()
                        : "")
                .allPlaces(product.getAllPlaces() != null ? product.getAllPlaces() : "")
                .currentPrice(product.getCurrentPrice())
                .build();
    }

    public Page<ProductDto> toProductDtoPage(Page<Product> productPage) {
        if (productPage == null) {
            return Page.empty();
        }
        return productPage.map(this::toProductDto);
    }

    public CustomerProductInfoResponse toCustomerProductInfoResponse(Product product, Double weight, ProductCategory category) {
        return CustomerProductInfoResponse.builder()
                .id(product.getId())
                .code(product.getCode())
                .url(product.getProductCardLongUrl())
                .imageUrl(product.getUrlImage())
                .title(product.getTitle())
                .brand(product.getBrand())
                .createdDate(product.getCreatedDate())
                .price(product.getPrice())
                .sellerCount(product.getAllPlaces())
                .weight(weight)
                .rating(product.getRating())
                .kaspiCommission(category != null ? category.getKaspiCommissionEnd() : 0.0f)
                .category(category != null ? category.getTitle() : "")
                .build();
    }

    public ProductInfoResponse toProductInfoResponse(Product product) {
        List<ProductPreorder> preorders = productPreorderRepository.findActiveByProduct(product.getId());

        return ProductInfoResponse.builder()
                .id(product.getId())
                .title(product.getTitle())
                .masterSku(product.getMasterSku())
                .sku(product.getSku())
                .photoUrl(resolvePhotoUrl(product))
                .code(product.getCode())
                .damping(toDampingInfo(product))
                .preorder(toPreorderInfo(product, preorders))
                .inventory(toInventoryInfo(product, preorders))
                .build();
    }

    private ProductInfoResponse.DampingInfo toDampingInfo(Product product) {
        return ProductInfoResponse.DampingInfo.builder()
                .price(product.getPrice())
                .currentPricePlace(product.getCurrentPricePlace())
                .targetPricePlace(product.getTargetPricePlace())
                .minPrice(product.getMinPrice())
                .maxPrice(product.getMaxPrice())
                .available(product.isAvailable())
                .priceAutoChange(product.isPriceAutoChange())
                .place(product.getPlace())
                .allPlaces(product.getAllPlaces())
                .build();
    }

    private ProductInfoResponse.PreorderInfo toPreorderInfo(Product product, List<ProductPreorder> preorders) {
        return ProductInfoResponse.PreorderInfo.builder()
                .price(product.getPrice())
                .isPreorderActive(!preorders.isEmpty())
                .kaspiCardUrl(product.getProductCardLongUrl())
                .build();
    }

    private ProductInfoResponse.InventoryInfo toInventoryInfo(Product product, List<ProductPreorder> preorders) {
        Map<Long, ProductPreorder> preorderByStockId = preorders.stream()
                .filter(preorder -> preorder.getProductStock() != null && preorder.getProductStock().getId() != null)
                .collect(Collectors.toMap(
                        preorder -> preorder.getProductStock().getId(),
                        Function.identity(),
                        (first, second) -> first
                ));

        List<ProductStock> stocks = product.getStocks() == null
                ? Collections.emptyList()
                : product.getStocks();

        String cityId = product.getCityId();

        if (cityId == null && !stocks.isEmpty()) {
            cityId = stocks.get(0).getCityId();
        }

        String cityName = product.getCityName();

        if ((cityName == null || cityName.isBlank()) && cityId != null) {
            cityName = cityRepository.findById(cityId)
                    .map(City::getName)
                    .orElse(null);
        }

        List<PointDto> points = stocks.stream()
                .map(stock -> toPointDto(stock, preorderByStockId.get(stock.getId())))
                .toList();

        return ProductInfoResponse.InventoryInfo.builder()
                .cityId(cityId)
                .cityName(cityName)
                .points(points)
                .build();
    }

    private PointDto toPointDto(ProductStock stock, ProductPreorder preorder) {
        return PointDto.builder()
                .point(stock.getPoint())
                .cityId(stock.getCityId())
                .quantity(toInt(stock.getStock()))
                .stockByCustomer(stock.getStockByCustomer())
                .minimalStock(stock.getMinimalStock())
                .action(stock.getAction())
                .preorderDays(preorder != null ? preorder.getPreorderDays() : 0)
                .preorderCount(preorder != null ? preorder.getPreorderCount() : 0)
                .stockSpecified(Boolean.TRUE.equals(stock.getStockSpecified()))
                .build();
    }

    private String resolvePhotoUrl(Product product) {
        if (product.getPhotoUrl() != null && !product.getPhotoUrl().isBlank()) {
            return product.getPhotoUrl();
        }

        return product.getUrlImage();
    }

    private Integer toInt(Long value) {
        return value != null ? Math.toIntExact(value) : null;
    }

}
