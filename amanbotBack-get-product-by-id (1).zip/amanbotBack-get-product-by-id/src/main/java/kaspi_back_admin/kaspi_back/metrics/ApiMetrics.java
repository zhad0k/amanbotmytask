package kaspi_back_admin.kaspi_back.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;


@Component
public class ApiMetrics {
    private final Counter requestCounterKaspi;
    private final Counter errorCounterKaspi;
    private final Counter requestCounterGreenApi;
    private final Counter errorCounterGreenApi;
    private final Timer responseTimerKaspi;
    private final Timer responseTimerGreenApi;

    public ApiMetrics(MeterRegistry registry) {
        this.requestCounterKaspi = Counter.builder("kaspi_api_requests")
                .description("Total number of requests to external KaspiAPIs")
                .register(registry);

        this.errorCounterKaspi = Counter.builder("kaspi_api_errors")
                .description("Total number of failed requests to external KaspiAPIs")
                .register(registry);

        this.responseTimerKaspi = io.micrometer.core.instrument.Timer.builder("kaspi_api_response_time")
                .description("Response time of external KaspiAPIs")
                .register(registry);
        this.requestCounterGreenApi = Counter.builder("green_api_requests")
                .description("Total number of requests to external GreenApis")
                .register(registry);
        this.errorCounterGreenApi = Counter.builder("green_api_errors")
                .description("Total number of filed requests to external GreenApis")
                .register(registry);
        this.responseTimerGreenApi = Timer.builder("green_api_response_time")
                .description("Response time of external GreenApi")
                .register(registry);
    }

    public void recordKaspiSuccess(long duration) {
        recordSuccess(duration, requestCounterKaspi, responseTimerKaspi);
    }
    public void recordKaspiError(long duration) {
        recordError(duration, requestCounterKaspi, errorCounterKaspi, responseTimerKaspi);
    }
    public void recordSuccessGreenApi(long duration) {
        recordSuccess(duration, requestCounterGreenApi, responseTimerGreenApi);
    }
    public void recordErrorGreenApi(long duration) {
        recordError(duration, requestCounterGreenApi, errorCounterGreenApi, responseTimerGreenApi);
    }


    public void recordSuccess(long duration, Counter counter, Timer  timer) {
        counter.increment();
        timer.record(duration, TimeUnit.MILLISECONDS);
    }

    public void recordError(long duration, Counter requestCounter, Counter counterError, Timer  timer) {
        requestCounter.increment();
        counterError.increment();
        timer.record(duration, TimeUnit.MILLISECONDS);
    }

}
