package kaspi_back_admin.kaspi_back.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KaspiReviewStaticticsDto {
    private LocalDate dateStart;
    private LocalDate dateFinish;
    private Long countOrders;
    private Long countSmsSent;
    private Long countClicks;
    private BigDecimal conversion;

}
