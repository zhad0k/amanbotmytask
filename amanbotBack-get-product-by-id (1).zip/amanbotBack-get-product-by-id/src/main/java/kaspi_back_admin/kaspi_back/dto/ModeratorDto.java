package kaspi_back_admin.kaspi_back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModeratorDto {
    private Long id;
    private String name;
    private String phone;
    private String email;
    private String imageUrl;
    private String imageName;
}
