package kaspi_back_admin.kaspi_back.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.OffsetDateTime;

@Data
@Builder
public class TariffExpiredCustomerResponse {
    private Long idInstance;
    private String fullName;
    private OffsetDateTime tariffStartAt;
    private OffsetDateTime tariffEndAt;
    private String tariffName;
    private String whatsappPhone;
}
