package kaspi_back_admin.kaspi_back.dto;

public record KindDto(String name, String displayName, String description) { }
