package kaspi_back_admin.kaspi_back.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class KaspiCargoAssembledRequest {
    private List<CargoItem> cargos;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CargoItem {
        private String orderCode;      // 813496083
        private Integer newCargoSpace; // 1
        private Integer quantity;      // 1
    }
}