package kaspi_back_admin.kaspi_back.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class KaspiOrdersResponse {
    private List<DataItem> data;
    private Meta meta;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Meta {
        private Integer pageCount;
        private Integer totalCount;
    }
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DataItem {
        private String id;
        private String type;
        private Attributes attributes;
        private Relationships relationships;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Attributes {
        private String code;
        private Long creationDate;
        private Double totalPrice;
        private Double deliveryCostForSeller;
        private Boolean isKaspiDelivery;
        private Boolean preOrder;
        private Long approvedByBankDate;
        private Boolean signatureRequired;
        private String status;
        private String pickupPointId;
        private String state;
        private Double deliveryCost;
        private CustomerLite customer;
        private DeliveryAddress deliveryAddress;
        private OriginAddress originAddress;
        private KaspiDelivery kaspiDelivery;
        private Boolean assembled;
        private String deliveryMode;
        private String paymentMode;
        private Long plannedDeliveryDate;
        private Long reservationDate;
        private Boolean express;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CustomerLite {
        private String id;
        private String name;
        private String cellPhone;
        private String firstName;
        private String lastName;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeliveryAddress {
        private String streetName;
        private String streetNumber;
        private String town;
        private String district;
        private String building;
        private String apartment;
        private String formattedAddress;
        private Double latitude;
        private Double longitude;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OriginAddress {
        private String id;
        private String displayName;
        private OriginInnerAddress address;
        private City city;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OriginInnerAddress {
        private String streetName;
        private String streetNumber;
        private String town;
        private String district;
        private String building;
        private String apartment;
        private String formattedAddress;
        private Double latitude;
        private Double longitude;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class City {
        private String id;
        private String code;
        private String name;
        private Boolean active;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class KaspiDelivery {
        private String waybill;
        private Long courierTransmissionDate;
        private Long courierTransmissionPlanningDate;
        private String waybillNumber;
        private Boolean express;
        private Boolean returnedToWarehouse;
        private String firstMileCourier;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Relationships {
        private Rel entries;
        private Rel user;

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Rel {
            private Object data;
            private Links links;
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Links {
            private String self;
            private String related;
        }
    }
}
