package kaspi_back_admin.kaspi_back.dto.request;

import lombok.Data;

@Data
public class FeedbackRequest {
    private String name;
    private String phone;
    private String comment;
    private String tariff;
}
