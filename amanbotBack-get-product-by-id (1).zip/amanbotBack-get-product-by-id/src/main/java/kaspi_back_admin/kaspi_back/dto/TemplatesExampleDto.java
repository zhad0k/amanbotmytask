package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

@Data
public class TemplatesExampleDto {
    private String templateRu;
    private String templateKz;
}
