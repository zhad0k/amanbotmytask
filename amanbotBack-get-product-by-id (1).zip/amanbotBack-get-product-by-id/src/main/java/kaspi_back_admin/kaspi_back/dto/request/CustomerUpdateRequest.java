package kaspi_back_admin.kaspi_back.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.time.LocalDate;

@Data
public class CustomerUpdateRequest {
    @NotBlank
    private Long instanceId;
    private String kaspiMerchantEmail;
    private String kaspiMerchantPassword;
    private String kaspiMerchantId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate start;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate end;

    private String tariffName;
    private String ipName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate startDumping;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate endDumping;

    private Boolean preorderEnabled;
    private Boolean inventoryEnabled;
    private Boolean waybillEnabled;

    private Boolean isTrial;

    private UpdatePriceGlobalModeratorRequest updatePriceGlobalModeratorRequest;

    public boolean hasKaspiCredentials() {
        return StringUtils.hasText(kaspiMerchantEmail) ||
                StringUtils.hasText(kaspiMerchantPassword);
    }

    public boolean hasCompleteKaspiCredentials() {
        return StringUtils.hasText(kaspiMerchantEmail) &&
                StringUtils.hasText(kaspiMerchantPassword);
    }

    @JsonIgnore
    @AssertTrue(message = "dateTo не может быть раньше dateFrom.")
    public boolean isMainRangeChronologicallyValid() {
        if (start == null || end == null) return true;
        return !end.isBefore(start);
    }

    @AssertTrue(message = "endDumping не может быть раньше startDumping.")
    public boolean isDumpingRangeChronologicallyValid() {
        if (startDumping == null || endDumping == null) return true;
        return !endDumping.isBefore(startDumping);
    }
}
