package kaspi_back_admin.kaspi_back.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductDto {
    private Long id;
    private String productCardLongUrl;
    private String title;
    private Long reservedRemainders;
    private Long totalRemainders;
    private Long price;
    private Long minPrice;
    private Long maxPrice;
    private boolean priceAutoChange;
    private boolean available;
    private String currentPricePlace;
    private Long targetPricePlace;
    private String allPlaces;
    private String url;
    private Long currentPrice;
}
