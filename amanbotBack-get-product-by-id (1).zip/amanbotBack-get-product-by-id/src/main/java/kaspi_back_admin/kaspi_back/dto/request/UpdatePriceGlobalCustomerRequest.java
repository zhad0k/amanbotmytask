package kaspi_back_admin.kaspi_back.dto.request;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import java.util.List;

public record UpdatePriceGlobalCustomerRequest(
        @NotEmpty List<Long> productIds,

        Direction direction,
        ChangeType type,
        @Positive @Min(1) Long value,

        @Positive Long minPrice,
        @Positive Long maxPrice
) {
    public enum Direction { INCREASE, DECREASE }
    public enum ChangeType { PERCENT, FIXED }

    @AssertTrue(message = "Должны быть заполнены либо параметры дельты (direction, type, value), либо новые цены (minPrice, maxPrice)")
    public boolean isValidUpdateMethod() {
        boolean hasAnyDeltaField = direction != null || type != null || value != null;
        boolean hasAllDeltaFields = direction != null && type != null && value != null;
        boolean hasAnyLimitField = minPrice != null || maxPrice != null;

        return (hasAllDeltaFields && !hasAnyLimitField) || (!hasAnyDeltaField && hasAnyLimitField);
    }

    @AssertTrue(message = "Минимальная цена не может быть больше максимальной")
    public boolean isValidLimits() {
        if (minPrice != null && maxPrice != null) {
            return minPrice <= maxPrice;
        }
        return true;
    }
}
