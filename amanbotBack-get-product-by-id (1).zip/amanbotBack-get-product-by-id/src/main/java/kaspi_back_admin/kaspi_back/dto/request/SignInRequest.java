package kaspi_back_admin.kaspi_back.dto.request;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(description = "Запрос на авторизацию физ.лица")
public class    SignInRequest {


    private String phone;
    @NotBlank
    @Size(min = 4, max = 20)
    private String password;



}
