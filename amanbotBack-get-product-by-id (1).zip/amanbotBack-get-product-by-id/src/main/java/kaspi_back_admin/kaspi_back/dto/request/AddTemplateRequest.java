package kaspi_back_admin.kaspi_back.dto.request;

public record AddTemplateRequest(String type,String valueRu,String valueKz) { }
