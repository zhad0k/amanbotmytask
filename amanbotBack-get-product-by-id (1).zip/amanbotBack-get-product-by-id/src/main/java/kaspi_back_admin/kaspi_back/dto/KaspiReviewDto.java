package kaspi_back_admin.kaspi_back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KaspiReviewDto {
    private String kaspiMessageText;
    private String customerPhone;
    private OffsetDateTime sentAt;
}
