package kaspi_back_admin.kaspi_back.dto;

public record BillingOptionDto(String label, int monthsToPay, int totalMonths,
                               long priceToPayKzt,long priceIfPaidMonthlyKzt,
                               long savingKzt) {
}
