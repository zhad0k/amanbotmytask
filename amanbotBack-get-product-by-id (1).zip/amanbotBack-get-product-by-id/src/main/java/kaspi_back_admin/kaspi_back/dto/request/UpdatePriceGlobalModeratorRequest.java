package kaspi_back_admin.kaspi_back.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record UpdatePriceGlobalModeratorRequest(
    @NotNull Direction direction,
    @NotNull ChangeType type,
    @NotNull @Positive @Min(1) Long value
) {
        public enum Direction { INCREASE, DECREASE }
        public enum ChangeType { PERCENT, FIXED }
}