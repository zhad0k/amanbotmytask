package kaspi_back_admin.kaspi_back.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CustomerProductInfoResponse {
    private Long id;
    private String code;
    private String url;
    private String imageUrl;
    private String title;
    private OffsetDateTime createdDate;
    private String brand;
    private Double rating;
    private String sellerCount;//allPlaces
    private Long price;
    private Double weight;
    private Float kaspiCommission;
    private String category;
}
