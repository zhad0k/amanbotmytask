package kaspi_back_admin.kaspi_back.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductRevenueResponse {
    private Long kaspiCommission;
    private Long defect;
    private Long delivery;
    private Long tax;
    private Long kaspiPay;
    private CalculationPerUnit calculationPerUnit;
    private PartyCalculation partyCalculation;

    @Data
    @AllArgsConstructor
    public static class CalculationPerUnit {
        private Long investment;
        private Long profitability;
        private Long marginality;
        private Long marginalProfit;
        private Long minimalPrice;
    }

    @Data
    @AllArgsConstructor
    public static class PartyCalculation {
        private Long productCount;
        private Long revenue;
        private Long marginalProfit;
        private Long minimalCount;
    }
}
