package kaspi_back_admin.kaspi_back.dto.request;

import lombok.Data;

@Data
public class UpdateProductRequest {
    private Long newMinPrice;
    private Long newMaxPrice;
}
