package kaspi_back_admin.kaspi_back.dto.request;

import lombok.Data;

@Data
public class ChangePasswordRequest {
    private String newPassword;
}

