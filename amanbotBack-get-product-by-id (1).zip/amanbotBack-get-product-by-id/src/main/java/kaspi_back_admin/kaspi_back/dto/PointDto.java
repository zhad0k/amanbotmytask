package kaspi_back_admin.kaspi_back.dto;

import jakarta.validation.constraints.NotNull;
import kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PointDto {

//    @Pattern(regexp = "^PP\\d$", message = "К сожалению, предзаказ доступен только для товаров на складах Kaspi. " +
//            "Для товаров с индивидуальным хранением его установить нельзя.")
    private String point;
    private String cityId;             // обязателен при create/update для различия городов с одинаковым point
    private Integer quantity;          // текущий остаток
    private Integer stockByCustomer;   // остаток введенный пользователем

    @NotNull
    private Integer minimalStock;      // минимальный остаток (учет)
    private MinimalStockAction action; // действие при минимальном остатке (учет)

    @NotNull
    private Integer preorderDays;

    @NotNull
    private Integer preorderCount;   // остаток который надо установить на товар с предзаказом

    private Boolean stockSpecified;  // отслеживается остаток по товару в каспи
}
