package kaspi_back_admin.kaspi_back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CityStocksDto {
    private String cityId;
    private String cityName;
    private List<PointDto> points;
}
