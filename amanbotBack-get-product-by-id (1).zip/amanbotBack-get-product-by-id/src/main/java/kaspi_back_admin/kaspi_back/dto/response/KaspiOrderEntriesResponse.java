package kaspi_back_admin.kaspi_back.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class KaspiOrderEntriesResponse {
    private List<DataItem> data;

    @Data
    public static class DataItem {
        private String id;
        private String type;
        private Attributes attributes;
        private Relationships relationships;
    }

    @Data
    public static class Attributes {
        private Integer entryNumber;
        private Double deliveryCost;
        private Double quantity;
        private Double weight;
        private Double basePrice;
        private Double totalPrice;
        private String unitType;

        private Category category;
        private Offer offer;

        private Boolean isImeiRequired;

        @Data
        public static class Category {
            private String code;
            private String title;
        }

        @Data
        public static class Offer {
            private String code;
            private String name;
        }
    }

    @Data
    public static class Relationships {
        private ProductRel product;

        @Data
        public static class ProductRel {
            private RelData data;
            private Links links;

            @Data
            public static class RelData {
                private String id;
                private String type;
            }

            @Data
            public static class Links {
                private String self;
                private String related;
            }
        }
    }
}
