package kaspi_back_admin.kaspi_back.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.AssertTrue;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.time.LocalDate;

@Data
public class ChangeSubscriptionRequest {
    private Long customerId;
    private String ipName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateFrom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateTo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateFromDumping;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateToDumping;
    private TariffType tariff;
    private Long managerId;
    private Long idInstance;

    private Boolean preorderEnabled;
    private Boolean inventoryEnabled;
    private Boolean waybillEnabled;

    private String kaspiMerchantEmail;
    private String kaspiMerchantPassword;

    private UpdatePriceGlobalModeratorRequest updatePriceGlobalModeratorRequest;

    public boolean hasKaspiCredentials() {
        return StringUtils.hasText(kaspiMerchantEmail) ||
                StringUtils.hasText(kaspiMerchantPassword);
    }

    public boolean hasCompleteKaspiCredentials() {
        return StringUtils.hasText(kaspiMerchantEmail) &&
                StringUtils.hasText(kaspiMerchantPassword);
    }

    @JsonIgnore
    @AssertTrue(message = "dateTo не может быть раньше dateFrom.")
    public boolean isMainRangeChronologicallyValid() {
        if (dateFrom == null || dateTo == null) return true;
        return !dateTo.isBefore(dateFrom);
    }

    @JsonIgnore
    @AssertTrue(message = "dateToDumping не может быть раньше dateFromDumping.")
    public boolean isDumpingRangeChronologicallyValid() {
        if (dateFromDumping == null || dateToDumping == null) return true;
        return !dateToDumping.isBefore(dateFromDumping);
    }

    @JsonIgnore
    @AssertTrue(message = "Для NOTIFICATION/VIP обязательны dateFrom и dateTo.")
    public boolean isMainRangeRequiredWhenNeeded() {
        if (tariff == null) return true;
        if (tariff.getKind() == TariffType.Kind.NOTIFICATION || tariff.getKind() == TariffType.Kind.VIP) {
            return dateFrom != null && dateTo != null;
        }
        return true;
    }

    @JsonIgnore
    @AssertTrue(message = "Для DAMPING/VIP обязательны dateFromDumping и dateToDumping.")
    public boolean isDumpingRangeRequiredWhenNeeded() {
        if (tariff == null) return true;
        if (tariff.getKind() == TariffType.Kind.DAMPING) {
            return dateFromDumping != null && dateToDumping != null;
        }
        return true;
    }
}
