package kaspi_back_admin.kaspi_back.dto;

public record TemplateDto(Long id,String valueRu,String valueKz,String type,boolean disabled) { }
