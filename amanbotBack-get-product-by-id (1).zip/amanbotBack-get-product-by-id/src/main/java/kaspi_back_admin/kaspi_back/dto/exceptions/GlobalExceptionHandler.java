package kaspi_back_admin.kaspi_back.dto.exceptions;

import io.jsonwebtoken.JwtException;
import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSourceResolvable;
import org.slf4j.MDC;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.method.ParameterValidationResult;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /* ====== 400 Bad Request: валидации и неверные данные ====== */

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ProblemDetail> handleValidation(MethodArgumentNotValidException ex,
                                                          HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        pd.setTitle("Bad Request");
        pd.setProperty("errors", ex.getBindingResult().getFieldErrors().stream()
                .map(fe -> Map.of(
                        "field", fe.getField(),
                        "message", Objects.requireNonNull(fe.getDefaultMessage()),
                        "code", Objects.requireNonNull(fe.getCode())))
                .collect(Collectors.toList()));
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(pd);
    }

    @ExceptionHandler(HandlerMethodValidationException.class)
    public ResponseEntity<ProblemDetail> handleHandlerMethodValidation(HandlerMethodValidationException ex,
                                                                       HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        pd.setTitle("Bad Request");
        pd.setProperty("errors", ex.getParameterValidationResults().stream()
                .flatMap(result -> result.getResolvableErrors().stream()
                        .map(error -> validationError(result, error)))
                .collect(Collectors.toList()));
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(pd);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ProblemDetail> handleConstraint(ConstraintViolationException ex,
                                                          HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Constraint violation");
        pd.setTitle("Bad Request");
        pd.setProperty("errors", ex.getConstraintViolations().stream()
                .map(v -> Map.of(
                        "field", v.getPropertyPath().toString(),
                        "message", v.getMessage(),
                        "constraint", v.getConstraintDescriptor().getAnnotation().annotationType().getSimpleName()))
                .collect(Collectors.toList()));
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(pd);
    }

    @ExceptionHandler({
            HttpMessageNotReadableException.class,
            MissingServletRequestParameterException.class,
            HttpMessageConversionException.class,
            IllegalArgumentException.class,
            IllegalStateException.class,
            TransactionSystemException.class
    })
    public ResponseEntity<ProblemDetail> handleBadRequest(Exception ex, HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, safeMsg(ex));
        pd.setTitle("Bad Request");
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(pd);
    }

    /* ====== 401/403 ====== */

    @ExceptionHandler({AuthenticationServiceException.class, JwtException.class})
    public ResponseEntity<ProblemDetail> handleAuth(Exception ex, HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.UNAUTHORIZED, "Unauthorized");
        pd.setTitle("Unauthorized");
        pd.setProperty("error", safeMsg(ex));
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(pd);
    }

    @ExceptionHandler({ AccessDeniedException.class, AuthorizationDeniedException.class })
    public ResponseEntity<ProblemDetail> handleAccessDenied(RuntimeException ex, HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.FORBIDDEN, "Access denied");
        pd.setTitle("Forbidden");
        pd.setProperty("error", ex.getClass().getSimpleName());
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(pd);
    }

    /* ====== 404 ====== */

    @ExceptionHandler({NoHandlerFoundException.class, EntityNotFoundException.class})
    public ResponseEntity<ProblemDetail> handleNotFound(Exception ex, HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, "Resource not found");
        pd.setTitle("Not Found");
        pd.setProperty("error", safeMsg(ex));
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(pd);
    }

    /* ====== 405 ====== */

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ProblemDetail> handleMethodNotAllowed(HttpRequestMethodNotSupportedException ex,
                                                                HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.METHOD_NOT_ALLOWED, "Method not allowed");
        pd.setTitle("Method Not Allowed");
        pd.setProperty("method", ex.getMethod());
        pd.setProperty("supported", ex.getSupportedHttpMethods());
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(pd);
    }

    /* ====== 409 ====== */

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ProblemDetail> handleConflict(DataIntegrityViolationException ex,
                                                        HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, "Data integrity violation");
        pd.setTitle("Conflict");
        pd.setProperty("error", safeMsg(ex));
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.CONFLICT).body(pd);
    }

    /* ====== 422 ====== */
    
    @ExceptionHandler(UnprocessableEntityException.class)
    public ResponseEntity<ProblemDetail> handleUnprocessable(UnprocessableEntityException ex,
                                                             HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage());
        pd.setTitle("Unprocessable Entity");
        enrich(pd, req);
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(pd);
    }

    /* ====== helpers ====== */

    private void enrich(ProblemDetail pd, HttpServletRequest req) {
        String corr = MDC.get("correlationId");
        if (corr != null && !corr.isBlank()) {
            pd.setProperty("correlationId", corr);
        }
        if (req != null) {
            pd.setProperty("path", req.getRequestURI());
            pd.setProperty("method", req.getMethod());
        }
    }

    private String safeMsg(Throwable ex) {
        String m = ex.getMessage();
        return m == null ? ex.getClass().getSimpleName() : truncate(m);
    }

    private Map<String, String> validationError(ParameterValidationResult result, MessageSourceResolvable error) {
        String field = result.getMethodParameter().getParameterName();
        if (error instanceof FieldError fieldError) {
            field = fieldError.getField();
        } else if (error instanceof ObjectError objectError) {
            field = objectError.getObjectName();
        }

        return Map.of(
                "field", field != null ? field : "arg" + result.getMethodParameter().getParameterIndex(),
                "message", error.getDefaultMessage() != null ? error.getDefaultMessage() : "Validation failed",
                "code", firstCode(error)
        );
    }

    private String firstCode(MessageSourceResolvable error) {
        String[] codes = error.getCodes();
        if (codes == null || codes.length == 0) {
            return error.getClass().getSimpleName();
        }
        return codes[0];
    }

    private String truncate(String s) {
        if (s == null) return null;
        return s.length() <= 1000 ? s : s.substring(0, 1000) + "…";
    }
}
