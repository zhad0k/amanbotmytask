package kaspi_back_admin.kaspi_back.dto;

public record TypeDto(Integer id, String name) {
}
