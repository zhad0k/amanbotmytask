package kaspi_back_admin.kaspi_back.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Товарная позиция в накладной: фото, название, количество, цена. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WaybillItemDto {
    private String offerCode;
    private String name;
    private String photoUrl;
    private Double quantity;
    private Double totalPrice;
}
