package kaspi_back_admin.kaspi_back.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CustomerFeaturesResponse {
    private boolean preorderEnabled;
    private boolean inventoryEnabled;
    private boolean waybillEnabled;
}
