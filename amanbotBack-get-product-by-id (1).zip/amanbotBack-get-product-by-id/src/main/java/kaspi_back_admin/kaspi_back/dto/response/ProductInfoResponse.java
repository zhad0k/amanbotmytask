package kaspi_back_admin.kaspi_back.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import kaspi_back_admin.kaspi_back.dto.PointDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductInfoResponse {

    // Common fields
    private Long id;
    private String title;
    private String masterSku;
    private String sku;
    private String photoUrl;
    private String code;

    // Blocks for one response
    private DampingInfo damping;
    private PreorderInfo preorder;
    private InventoryInfo inventory;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class DampingInfo {
        private Long price;
        private Long currentPricePlace;
        private Long targetPricePlace;
        private Long minPrice;
        private Long maxPrice;
        private Boolean available;
        private Boolean priceAutoChange;
        private String place;
        private String allPlaces;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class PreorderInfo {
        private Long price;
        private Boolean isPreorderActive;
        private String kaspiCardUrl;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class InventoryInfo {
        private String cityId;
        private String cityName;
        private List<PointDto> points;
    }
}