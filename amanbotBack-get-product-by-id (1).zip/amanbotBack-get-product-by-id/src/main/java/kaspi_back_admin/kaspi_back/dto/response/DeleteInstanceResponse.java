package kaspi_back_admin.kaspi_back.dto.response;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DeleteInstanceResponse {
    private Boolean deleteInstanceAccount;

}
