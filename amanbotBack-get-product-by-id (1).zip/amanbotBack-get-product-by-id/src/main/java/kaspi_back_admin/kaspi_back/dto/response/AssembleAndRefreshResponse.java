package kaspi_back_admin.kaspi_back.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class AssembleAndRefreshResponse {
    private boolean allReady;
    private int totalOrders;
    private int readyOrders;
    private List<WaybillItem> waybills;

    @Data
    public static class WaybillItem {
        private String orderCode;
        private String kaspiId;
        private String waybillUrl;
        private String waybillNumber;
    }
}