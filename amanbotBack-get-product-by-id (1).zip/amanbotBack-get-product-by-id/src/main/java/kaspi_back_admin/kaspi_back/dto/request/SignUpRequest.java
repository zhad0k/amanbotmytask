package kaspi_back_admin.kaspi_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Запрос на регистрацию физ.лица")
public class SignUpRequest {


    private String username;
    private String lastName;
    private String fullName;
    private String phone;
    private String password;
    private String smsCode;
    private String email;


}
