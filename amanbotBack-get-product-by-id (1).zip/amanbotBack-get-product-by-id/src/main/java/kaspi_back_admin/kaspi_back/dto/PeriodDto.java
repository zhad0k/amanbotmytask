package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

@Data
public class PeriodDto {
    private Long id;
    private String name;
}
