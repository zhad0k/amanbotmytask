package kaspi_back_admin.kaspi_back.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class IncomingMessageRequest {

    @JsonProperty("typeWebhook")
    private String typeWebhook;

    @JsonProperty("instanceData")
    private InstanceData instanceData;

    @JsonProperty("timestamp")
    private Long timestamp;

    @JsonProperty("idMessage")
    private String idMessage;

    @JsonProperty("senderData")
    private SenderData senderData;

    @JsonProperty("messageData")
    private MessageData messageData;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class InstanceData {
        private Long idInstance;
        private String wid;
        private String typeInstance;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SenderData {
        private String chatId;
        private String sender;
        private String chatName;
        private String senderName;
        private String senderContactName;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MessageData {
        private String typeMessage;

        @JsonProperty("textMessageData")
        private TextMessageData textMessageData;

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class TextMessageData {
            private String textMessage;
        }
    }
}
