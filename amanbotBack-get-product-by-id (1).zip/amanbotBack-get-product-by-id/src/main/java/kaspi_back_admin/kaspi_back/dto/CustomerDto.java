package kaspi_back_admin.kaspi_back.dto;

import lombok.*;
import java.time.OffsetDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerDto {
    private Long id;
    private String fullName;
    private String email;
    private String phone;
    private String ipName;
    private boolean isActive;
    private String tariff;
    private String tariffKind;
    private String tariffName;
    private Boolean isTrial;
    private OffsetDateTime startDate;
    private OffsetDateTime endDate;
    private OffsetDateTime startDateVip;
    private OffsetDateTime endDateVip;
    private OffsetDateTime startDateDumping;
    private OffsetDateTime endDateDumping;
    private ModeratorDto manager;
    private Long idInstance;

    private String kaspiEmailMerchant;
    private String kaspiPasswordMerchant;
    private boolean hasKaspiMerchantPassword;
    private String kaspiMerchantId;

    private boolean preorderEnabled;
    private boolean inventoryEnabled;
    private boolean waybillEnabled;
}
