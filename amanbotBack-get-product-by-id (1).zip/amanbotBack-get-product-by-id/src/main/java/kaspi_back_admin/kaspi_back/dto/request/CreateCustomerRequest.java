package kaspi_back_admin.kaspi_back.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.AssertTrue;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CreateCustomerRequest {
    private String phone;
    private String password;
    private String kaspiToken;
    private String ipName;
    private String phoneWhatsApp;
    private String tariff;
    private Long managerId;
    private Long idInstance;
    private String merchantId;
    private String email;
    private String emailPassword;

    private String tariffKind;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateFrom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateTo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateFromDumping;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy")
    private LocalDate dateToDumping;

    private boolean preorderEnabled;
    private boolean inventoryEnabled;
    private boolean waybillEnabled;

    private Boolean isTrial;

    @AssertTrue(message = "dateTo не может быть раньше dateFrom.")
    public boolean isMainRangeChronologicallyValid() {
        if (dateFrom == null || dateTo == null) return true;
        return !dateTo.isBefore(dateFrom);
    }

    @AssertTrue(message = "dateToDumping не может быть раньше dateFromDumping.")
    public boolean isDumpingRangeChronologicallyValid() {
        if (dateFromDumping == null || dateToDumping == null) return true;
        return !dateToDumping.isBefore(dateFromDumping);
    }
}
