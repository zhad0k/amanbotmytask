package kaspi_back_admin.kaspi_back.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductRevenueRequest {
    private Double price;
    private Double cost;
    private Double weight;
    private Float kaspiCommissionRate;
    private Float defectRate;
    private String deliveryType;
    private Double expenses;
    private Double investment;
    private String categoryTitle;
}
