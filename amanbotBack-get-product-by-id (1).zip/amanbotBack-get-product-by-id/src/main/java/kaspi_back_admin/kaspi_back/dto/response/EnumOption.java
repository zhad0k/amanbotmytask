package kaspi_back_admin.kaspi_back.dto.response;

public record EnumOption(String code, String name, String nameKz) {}
