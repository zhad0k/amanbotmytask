package kaspi_back_admin.kaspi_back.dto;

import kaspi_back_admin.kaspi_back.db.enums.TariffType;

import java.util.List;

public record TariffDto(String name,
                        TariffType.Kind kind,
                        TariffType.ProductTier tier,
                        String displayName,
                        long monthlyPriceKzt, List<BillingOptionDto> billingOptions) {}
