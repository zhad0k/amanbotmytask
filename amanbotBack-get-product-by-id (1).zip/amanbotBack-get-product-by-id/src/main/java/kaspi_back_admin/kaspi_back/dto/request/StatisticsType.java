package kaspi_back_admin.kaspi_back.dto.request;

public enum StatisticsType {
    DAILY,
    MONTHLY
}
