package kaspi_back_admin.kaspi_back.dto.request.greenapi;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.*;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MessagePayloadRequest {
    private String chatId;
    private String header;
    private String body;
    private String footer;

    @Singular
    private List<Button> buttons;

    public void normalize() {
        if (buttons == null) return;
        for (Button b : buttons) {
            if (b == null || b.getType() == null) continue;
            b.setButtonId(nullIfBlank(b.getButtonId()));
            b.setButtonText(nullIfBlank(b.getButtonText()));
            b.setCopyCode(nullIfBlank(b.getCopyCode()));
            b.setPhoneNumber(nullIfBlank(b.getPhoneNumber()));
            b.setUrl(nullIfBlank(b.getUrl()));

            switch (b.getType()) {
                case COPY -> {
                    b.setPhoneNumber(null);
                    b.setUrl(null);
                }
                case CALL -> {
                    b.setCopyCode(null);
                    b.setUrl(null);
                }
                case URL -> {
                    b.setCopyCode(null);
                    b.setPhoneNumber(null);
                }
            }
        }
    }

    private static String nullIfBlank(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Button {
        private ButtonType type;
        private String buttonId;
        private String buttonText;

        private String copyCode;
        private String phoneNumber;
        private String url;

        public static Button copy(String buttonId, String buttonText, String copyCode) {
            return Button.builder()
                    .type(ButtonType.COPY)
                    .buttonId(buttonId)
                    .buttonText(buttonText)
                    .copyCode(copyCode)
                    .build();
        }

        public static Button call(String buttonId, String buttonText, String phoneNumber) {
            return Button.builder()
                    .type(ButtonType.CALL)
                    .buttonId(buttonId)
                    .buttonText(buttonText)
                    .phoneNumber(phoneNumber)
                    .build();
        }

        public static Button url(String buttonId, String buttonText, String url) {
            return Button.builder()
                    .type(ButtonType.URL)
                    .buttonId(buttonId)
                    .buttonText(buttonText)
                    .url(url)
                    .build();
        }
    }

    public enum ButtonType {
        COPY, CALL, URL;

        @JsonValue
        public String toValue() {
            return name().toLowerCase();
        }

        @JsonCreator
        public static ButtonType fromValue(String value) {
            if (value == null) return null;
            return ButtonType.valueOf(value.trim().toUpperCase());
        }
    }
}