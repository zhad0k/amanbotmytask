package kaspi_back_admin.kaspi_back.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Data
public class GreenApiInstanceResponse {

    @JsonProperty("apiUrl")
    private String apiUrl;

    @JsonProperty("mediaUrl")
    private String mediaUrl;

    @JsonProperty("apiTokenInstance")
    private String apiTokenInstance;

    @JsonProperty("idInstance")
    private Long idInstance;

    @JsonProperty("name")
    private String name;

    @JsonProperty("typeInstance")
    private String typeInstance;

    @JsonProperty("typeAccount")
    private String typeAccount;

    @JsonProperty("partnerUserUiid")
    private String partnerUserUiid;

    @JsonProperty("timeCreated")
    private LocalDateTime timeCreated;

    @JsonProperty("timeDeleted")
    private LocalDateTime timeDeleted;

    @JsonProperty("deleted")
    private boolean deleted;

    @JsonProperty("tariff")
    private String tariff;

    @JsonProperty("isFree")
    private boolean isFree;

    @JsonProperty("isPartner")
    private boolean isPartner;

    @JsonProperty("enableCalls")
    private boolean enableCalls;

    @JsonProperty("expirationDate")
    private LocalDateTime expirationDate;

    @JsonProperty("isExpired")
    private boolean isExpired;

    @JsonProperty("messenger")
    private String messenger;
}
