package kaspi_back_admin.kaspi_back.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ReviewDto {
    private Long id;
    private String content;
    private Integer score;
    private String customerName;
    private OffsetDateTime createdDate;
    private OffsetDateTime updatedDate;
}
