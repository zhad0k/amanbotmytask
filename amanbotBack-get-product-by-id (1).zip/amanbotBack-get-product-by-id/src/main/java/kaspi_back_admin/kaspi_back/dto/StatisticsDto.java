package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class StatisticsDto {
    private Long id;
    private String name;
    private String code;
    private boolean active;
    private boolean available;
    private long sellsCount;
    private BigDecimal sellsSum;
    private long returnedCount;
    private long cancelledCount;
    private double rating;
    private String url;
    private String imageUrl;
    private long missingCount;
}