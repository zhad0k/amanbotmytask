package kaspi_back_admin.kaspi_back.dto;

import lombok.*;

import java.util.List;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PreorderDto {
    private Long id;
    private Long productId;
    private Long customerId;
    private Long price;

    private Boolean isPreorderActive;

    private String title;
    private String photoUrl;
    private String kaspiCardUrl;
    private List<CityStocksDto> cities;
}
