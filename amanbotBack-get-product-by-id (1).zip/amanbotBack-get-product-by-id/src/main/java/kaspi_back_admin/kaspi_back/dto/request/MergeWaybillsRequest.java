package kaspi_back_admin.kaspi_back.dto.request;

import java.util.List;

public record MergeWaybillsRequest(
        List<String> orderCodes,
        // Количество накладных/мест (Kaspi: numberOfSpace). null -> 1.
        Integer numberOfSpace
) {}