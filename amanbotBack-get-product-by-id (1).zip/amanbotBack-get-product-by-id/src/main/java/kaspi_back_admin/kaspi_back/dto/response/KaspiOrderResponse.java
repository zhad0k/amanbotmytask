package kaspi_back_admin.kaspi_back.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class KaspiOrderResponse {

    private DataNode data;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DataNode {
        private String id;
        private String type;
        private Attributes attributes;
        private Relationships relationships;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Attributes {

        private String code;

        // в ответе: "status": "ACCEPTED_BY_MERCHANT"
        private String status;

        // в ответе: 5397.0
        private Double totalPrice;

        // в ответе: 1770536796189 (millis)
        private Long creationDate;

        // если захочешь - там ещё есть plannedDeliveryDate и тд
        private Long plannedDeliveryDate;

        // assembled: true
        private Boolean assembled;

        // state: "KASPI_DELIVERY"
        private String state;

        // ВАЖНО: waybill и waybillNumber внутри kaspiDelivery
        private KaspiDelivery kaspiDelivery;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class KaspiDelivery {

        // в ответе это ПОЛНЫЙ URL
        // "https://kaspi.kz/shop/api/waybill/...."
        private String waybill;

        private String waybillNumber;

        // в ответе это millis (или null)
        private Long courierTransmissionDate;

        private Long courierTransmissionPlanningDate;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Relationships {
        private Entries entries;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Entries {
        private List<EntryData> data;
        private Links links;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EntryData {
        private String id;
        private String type;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Links {
        private String self;
        private String related;
    }

    public boolean hasWaybill() {
        return data != null
                && data.getAttributes() != null
                && data.getAttributes().getKaspiDelivery() != null
                && data.getAttributes().getKaspiDelivery().getWaybill() != null
                && !data.getAttributes().getKaspiDelivery().getWaybill().isBlank();
    }

    public String extractWaybillUrl() {
        return data.getAttributes().getKaspiDelivery().getWaybill();
    }

    public String extractWaybillNumber() {
        return data.getAttributes().getKaspiDelivery().getWaybillNumber();
    }
}