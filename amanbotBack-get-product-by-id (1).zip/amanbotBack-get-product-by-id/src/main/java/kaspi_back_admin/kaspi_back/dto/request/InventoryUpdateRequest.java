package kaspi_back_admin.kaspi_back.dto.request;

import jakarta.validation.constraints.NotBlank;
import kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction;
import kaspi_back_admin.kaspi_back.dto.PointDto;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class InventoryUpdateRequest {
    @NotBlank
    private List<PointDto> points;
    private Long stock;
    private Integer minimalStock;
    private MinimalStockAction action;
}