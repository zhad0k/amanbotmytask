package kaspi_back_admin.kaspi_back.dto.request;

import lombok.Data;

@Data
public class ChangeCustomerRequest {
    private String ipName;
    private String username;
    private String kaspiToken;
    private String kaspiPhone;
    private String kaspiPhonePassword;
    private String kaspiEmail;
    private String kaspiEmailPassword;
    private String newPassword;
    private String newPhone;
    private Long managerId;
}

