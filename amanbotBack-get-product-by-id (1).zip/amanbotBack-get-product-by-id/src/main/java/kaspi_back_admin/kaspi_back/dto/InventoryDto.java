package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

import java.util.List;

@Data
public class InventoryDto {
    private Long productId;
    private Long customerId;

    private String title;
    private String photoUrl;
    private String kaspiCardUrl;
    private String cityName;

    private List<StockDto> stock;
}