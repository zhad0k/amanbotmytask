package kaspi_back_admin.kaspi_back.dto.response;

import lombok.Data;

@Data
public class KaspiMasterProductResponse {
    private DataItem data;

    @Data
    public static class DataItem {
        private String id;
        private String type;
        private Attributes attributes;
    }

    @Data
    public static class Attributes {
        private String code;
        private String name;
        private String category;
    }
}