package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

import java.time.OffsetDateTime;

@Data
public class CustomerDetailsDto {
    private Long id;
    private String ipName;
    private String phone;
    private String kaspiEmail;
    private String kaspiPassword;
    private boolean hasKaspiMerchantPassword;
    private String tariff;
    private String tariffKind;
    private String tariffName;
    private OffsetDateTime startDate;
    private OffsetDateTime endDate;
    private OffsetDateTime startDateDumping;
    private OffsetDateTime endDateDumping;
    private boolean active;
    private Integer activeSlots;
    private Integer remainingSlots;
    private ModeratorDto managerDto;
    private Long instanceId;
    private String dumpingTariff;
    private boolean preorderEnabled;
    private boolean inventoryEnabled;
    private boolean waybillEnabled;
}
