package kaspi_back_admin.kaspi_back.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductInfoDto {
    private Long maxProductCount;
    private Long totalCount;
    private Long activeCount;
    private Long inActiveCount;
    private Long archiveCount;
}
