package kaspi_back_admin.kaspi_back.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
public class CustomerProductStatistics {
    private Long totalCount;
    private BigDecimal totalPrice;
    private List<CustomerProductStatisticsByPeriod> customerProductStatisticsByPeriod;

    @Data
    @AllArgsConstructor
    public static class CustomerProductStatisticsByPeriod {
        private LocalDate period;
        private Long count;
        private BigDecimal price;
    }
}
