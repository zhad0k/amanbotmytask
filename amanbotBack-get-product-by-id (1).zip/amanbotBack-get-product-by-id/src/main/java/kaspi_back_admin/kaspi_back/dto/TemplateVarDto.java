package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

@Data
public class TemplateVarDto {
    private final String name;
    private final String ruName;
    private final String KzName;
    private final String defaultValue;
}
