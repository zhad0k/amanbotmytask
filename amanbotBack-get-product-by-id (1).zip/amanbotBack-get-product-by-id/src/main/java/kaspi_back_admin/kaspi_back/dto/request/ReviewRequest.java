package kaspi_back_admin.kaspi_back.dto.request;

import lombok.Data;

@Data
public class ReviewRequest {
    Long id;
    String content;
    Integer rating;
}
