package kaspi_back_admin.kaspi_back.dto;

import lombok.Data;

import java.time.OffsetDateTime;
import java.util.List;

@Data
public class ModeratorTemplateDto {
    private String moderatorName;
    private OffsetDateTime createdAt;
    private boolean active;
    private Long sentCount;
    private List<TemplateDto> templatesNew;
    private List<TemplateDto> templatesDelivered;
}
