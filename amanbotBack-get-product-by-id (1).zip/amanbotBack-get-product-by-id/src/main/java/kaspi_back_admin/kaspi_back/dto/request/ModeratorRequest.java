package kaspi_back_admin.kaspi_back.dto.request;

import lombok.*;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ModeratorRequest {
    private Long id;
    private String name;
    private String phone;
    @NonNull
    private MultipartFile image;
}
