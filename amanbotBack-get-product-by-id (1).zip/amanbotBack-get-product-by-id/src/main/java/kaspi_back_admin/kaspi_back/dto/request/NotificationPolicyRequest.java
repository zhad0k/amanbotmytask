package kaspi_back_admin.kaspi_back.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Set;

public record NotificationPolicyRequest(
        @NotNull Long customerId,
        @NotNull @JsonFormat(pattern="HH:mm") LocalTime allowedFrom,
        @NotNull @JsonFormat(pattern="HH:mm") LocalTime allowedTo,
        @NotNull Set<DayOfWeek> days
) {}