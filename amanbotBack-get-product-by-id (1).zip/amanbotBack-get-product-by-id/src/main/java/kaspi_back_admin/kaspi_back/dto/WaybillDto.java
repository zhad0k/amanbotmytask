package kaspi_back_admin.kaspi_back.dto;

import kaspi_back_admin.kaspi_back.db.enums.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WaybillDto {
    private String code;
    private OrderStatus status;
    private Double price;
    private OffsetDateTime receiptDate;
    private Boolean assemble;

    // Накладная
    private String waybillNumber;     // номер накладной
    private Boolean waybillReady;     // накладная уже сформирована (есть waybillUrl)
    private Boolean kaspiExpress;     // экспресс-доставка Kaspi

    // Доставка / получатель
    private String deliveryMode;
    private OffsetDateTime plannedDeliveryDate;
    private String recipientName;
    private String city;
    private String deliveryAddress;

    // Товары
    private Integer itemsCount;
    private List<WaybillItemDto> items;
}
