package kaspi_back_admin.kaspi_back.dto;

import lombok.Builder;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.List;

@Data
@Builder
public class CompanyTemplatesSummaryDto {
    private String companyName;
    private OffsetDateTime addedAt;
    private List<String> status;
    private long sentCount;
    private long queuedCount;
    private long orderCount;
}
