package kaspi_back_admin.kaspi_back.dto;

import kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StockDto {
    private String point;
    private Long quantity;
    private Integer minimalQuantity;
    private Integer quantityByCustomer;
    private MinimalStockAction action;
    private Integer preorderDays;
    private Integer preorderCount;
    private Boolean stockSpecified;
}