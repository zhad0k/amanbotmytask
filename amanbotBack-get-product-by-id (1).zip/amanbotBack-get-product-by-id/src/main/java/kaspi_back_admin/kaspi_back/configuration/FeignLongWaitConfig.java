package kaspi_back_admin.kaspi_back.configuration;

import feign.Request;
import org.springframework.context.annotation.Bean;

import java.util.concurrent.TimeUnit;

public class FeignLongWaitConfig {

    @Bean
    public Request.Options feignOptions() {
        return new Request.Options(
                10, TimeUnit.SECONDS,
                6, TimeUnit.MINUTES,
                true
        );
    }
}