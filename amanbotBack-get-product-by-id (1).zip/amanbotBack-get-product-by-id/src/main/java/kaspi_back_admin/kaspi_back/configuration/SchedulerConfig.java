package kaspi_back_admin.kaspi_back.configuration;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.TimeZone;

@Configuration
public class SchedulerConfig {
    @Value("${scheduler.job.zone:Asia/Almaty}")
    private String timeZone;

    @PostConstruct
    public void setDefaultTimeZone() {
        TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
    }

}
