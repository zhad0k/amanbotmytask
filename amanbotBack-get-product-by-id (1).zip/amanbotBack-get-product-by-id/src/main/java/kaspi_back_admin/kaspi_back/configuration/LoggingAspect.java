package kaspi_back_admin.kaspi_back.configuration;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.lang.reflect.Parameter;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Value("${logging.aspect.slow-threshold-ms:2000}")
    private long slowThresholdMs;

    @Value("${logging.aspect.log-args:true}")
    private boolean logArgs;

    @Value("${logging.aspect.log-result:false}")
    private boolean logResult;

    @Value("${logging.aspect.max-string-len:500}")
    private int maxLen;

    @Setter
    private Set<String> maskedKeys = new HashSet<>(Arrays.asList(
            "password","token","authorization","cookie","secret","apiKey","apikey","access_token","refresh_token"
    ));

    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void controllerMethods() {}

    @Pointcut("within(@org.springframework.stereotype.Service *)")
    public void serviceMethods() {}

    @Pointcut("within(@org.springframework.stereotype.Repository *)")
    public void repositoryMethods() {}

    @Around("repositoryMethods()")
    public Object logRepositoryCall(ProceedingJoinPoint pjp) throws Throwable {
        ensureCorrelationId();

        long start = System.nanoTime();
        MethodSignature sig = (MethodSignature) pjp.getSignature();
        String className = resolveClassName(pjp);
        String method = sig.getName();

        Map<String, Object> argsMap = buildArgsMap(sig.getMethod().getParameters(), pjp.getArgs());

        try {
            Object result = pjp.proceed();
            long tookMs = Duration.ofNanos(System.nanoTime() - start).toMillis();

            Map<String, Object> fields = baseFields(className, method, tookMs);
            fields.put("event", "repository_call");
            fields.put("layer", "repository");
            if (logArgs) {
                fields.put("args", safe(argsMap));
            }

            boolean txActive = TransactionSynchronizationManager.isActualTransactionActive();
            fields.put("txActive", txActive);

            String line = toKvLine(fields);

            if (tookMs >= slowThresholdMs) {
                log.warn("SLOW-DB {}.{} {}", className, method, line);
            } else {
                log.info("DB {}.{} {}", className, method, line);
            }
            return result;
        } catch (Exception ex) {
            long tookMs = Duration.ofNanos(System.nanoTime() - start).toMillis();

            Map<String, Object> fields = baseFields(className, method, tookMs);
            fields.put("event", "repository_call");
            fields.put("layer", "repository");
            fields.put("exceptionType", ex.getClass().getName());
            fields.put("exceptionMessage", truncate(String.valueOf(ex.getMessage())));
            log.error("DB-ERROR {}.{} {}", className, method, toKvLine(fields), ex);
            throw ex;
        }
    }

    @Around("controllerMethods() || serviceMethods()")
    public Object logExecution(ProceedingJoinPoint pjp) throws Throwable {
        String className = resolveClassName(pjp);
        if (className.contains("Telegram")) return pjp.proceed();
        ensureCorrelationId();

        long start = System.nanoTime();
        MethodSignature sig = (MethodSignature) pjp.getSignature();
        String method = sig.getName();

        Map<String, Object> argsMap = buildArgsMap(sig.getMethod().getParameters(), pjp.getArgs());

        try {
            Object result = pjp.proceed();
            long tookMs = Duration.ofNanos(System.nanoTime() - start).toMillis();

            Map<String, Object> fields = baseFields(className, method, tookMs);
            if (logArgs)   fields.put("args", safe(argsMap));
            if (logResult) fields.put("result", summarize(result));

            String line = toKvLine(fields);

            if (tookMs >= slowThresholdMs) {
                log.warn("SLOW {}.{} {}", className, method, line);
            } else if (isSuspicious(result)) {
                fields.put("reason", "suspicious_result");
                log.warn("WARN {}.{} {}", className, method, toKvLine(fields));
            } else {
                log.info("SUCCESS {}.{} {}", className, method, line);
            }
            return result;
        } catch (Exception ex) {
            long tookMs = Duration.ofNanos(System.nanoTime() - start).toMillis();

            Map<String, Object> fields = baseFields(className, method, tookMs);
            fields.put("exceptionType", ex.getClass().getName());
            fields.put("exceptionMessage", truncate(String.valueOf(ex.getMessage())));
            log.error("ERROR {}.{} {}", className, method, toKvLine(fields), ex);
            throw ex;
        }
    }

    private void ensureCorrelationId() {
        String key = "correlationId";
        if (MDC.get(key) == null || MDC.get(key).isBlank()) {
            MDC.put(key, UUID.randomUUID().toString());
        }
    }

    private Map<String, Object> baseFields(String className, String method, long tookMs) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("event", "method_execution");
        m.put("class", className);
        m.put("method", method);
        m.put("durationMs", tookMs);
        putIfPresent(m, "traceId", MDC.get("traceId"));
        putIfPresent(m, "spanId", MDC.get("spanId"));
        putIfPresent(m, "correlationId", MDC.get("correlationId"));
        return m;
    }

    private String resolveClassName(ProceedingJoinPoint pjp) {
        MethodSignature sig = (MethodSignature) pjp.getSignature();
        Class<?> declType = sig.getDeclaringType();
        String simple = declType.getSimpleName();
        int idx = simple.indexOf("$$");
        return (idx > 0) ? simple.substring(0, idx) : simple;
    }

    private void putIfPresent(Map<String, Object> map, String key, String val) {
        if (val != null && !val.isBlank()) map.put(key, val);
    }

    private Map<String, Object> buildArgsMap(Parameter[] params, Object[] args) {
        Map<String, Object> m = new LinkedHashMap<>();
        IntStream.range(0, Math.min(params.length, args.length)).forEach(i -> {
            String name = params[i].getName();
            m.put(name, args[i]);
        });
        for (int i = params.length; i < args.length; i++) {
            m.put("arg" + i, args[i]);
        }
        return m;
    }

    private String toKvLine(Map<String, Object> fields) {
        return fields.entrySet().stream()
                .map(e -> e.getKey() + "=" + formatValue(e.getValue()))
                .collect(Collectors.joining(" "));
    }

    private String formatValue(Object v) {
        if (v == null) return "null";
        if (v instanceof CharSequence cs) return quote(truncate(cs.toString()));
        if (v instanceof Number || v instanceof Boolean) return v.toString();
        if (v instanceof Collection<?> c) return quote("{size=" + c.size() + "}");
        if (v instanceof Map<?, ?> m) return quote("{size=" + m.size() + "}");
        if (v instanceof byte[] b) return quote("{bytes=" + b.length + "}");
        return quote(truncate(String.valueOf(v)));
    }

    private String quote(String s) {
        String cleaned = s.replace("\n", "\\n").replace("\r", "\\r").replace("\"", "\\\"");
        return "\"" + cleaned + "\"";
    }

    private Object safe(Object value) {
        if (value == null) return null;
        if (value instanceof Map<?, ?> map) {
            Map<Object, Object> copy = new LinkedHashMap<>();
            for (var e : map.entrySet()) {
                Object k = e.getKey();
                if (k instanceof String s && isMaskedKey(s)) {
                    copy.put(k, "***");
                } else {
                    copy.put(k, safe(e.getValue()));
                }
            }
            return copy;
        }
        if (value instanceof Collection<?> col) {
            return Map.of("type", value.getClass().getSimpleName(), "size", col.size());
        }
        if (value instanceof Object[] arr) {
            return Map.of("type", "Array", "length", arr.length);
        }
        if (value instanceof CharSequence cs) {
            return truncate(cs.toString());
        }
        if (value instanceof byte[] bytes) {
            return Map.of("type", "byte[]", "length", bytes.length);
        }
        return truncate(String.valueOf(value));
    }

    private boolean isMaskedKey(String key) {
        String k = key.toLowerCase(Locale.ROOT);
        return maskedKeys.stream().anyMatch(k::contains);
    }

    private String truncate(String s) {
        if (s == null) return null;
        return s.length() <= maxLen ? s : (s.substring(0, maxLen) + "…");
    }

    private Object summarize(Object result) {
        if (result == null) return null;
        if (result instanceof Collection<?> c) return Map.of("collectionSize", c.size());
        if (result instanceof Map<?, ?> m) return Map.of("mapSize", m.size());
        if (result instanceof Optional<?> opt) return Map.of("present", opt.isPresent());
        return safe(result);
    }

    private boolean isSuspicious(Object result) {
        if (result == null) return false;
        if (result instanceof Collection<?> c) return c.isEmpty();
        if (result instanceof Map<?, ?> m) return m.isEmpty();
        if (result instanceof Optional<?> opt) return opt.isEmpty();
        return false;
    }
}