package kaspi_back_admin.kaspi_back.service.util_services;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
@Slf4j
public class JwtService {

   @Value("${token.signing.key}")
   private String jwtSigningKey;


   /**
    * Извлечение юзернейм пользователя из токена
    *
    * @param token токен
    * @return имя пользователя
    */
   public String extractUserName(String token) {
      return extractClaim(token, Claims::getSubject);
   }

   /**
    * Извлечение email пользователя из токена
    *
    * @param token токен
    * @return имя пользователя
    */

   public Map<String,String> extractTokenData(String token){
      final Claims claims = extractAllClaims(token);
      Map<String,String> tokenData = new HashMap<>();

      log.debug("Id type: {}", claims.get("id") != null ? claims.get("id").getClass().getName() : "null");

      tokenData.put("email",claims.get("email",String.class));
      tokenData.put("role",claims.get("role",String.class));
      tokenData.put("phone",claims.get("phone",String.class));
      tokenData.put("id", String.valueOf(claims.get("id", Long.class)));

      return tokenData;
   }

   /**
    * Генерация токена
    *
    * @param userDetails данные пользователя
    * @return токен
    */
   public String generateToken(UserDetails userDetails){
      Map<String,Object> claims = new HashMap<>();
      if (userDetails instanceof Customer customUserDetails){
         claims.put("id",customUserDetails.getId());
         claims.put("role",customUserDetails.getRole());
         claims.put("name", customUserDetails.getFullName());
         claims.put("phone",customUserDetails.getPhone());
         claims.put("hasKaspiToken", customUserDetails.getTokenProd() != null);
         claims.put("hasKaspiPassword", customUserDetails.getKaspiPassword() != null);
         claims.put("tariffNotification", customUserDetails.getTariffType());
      }
      return generateToken(claims,userDetails);
   }


   /**
    * Проверка токена на валидность
    *
    * @param token       токен
    * @param userDetails данные пользователя
    * @return true, если токен валиден
    */
   public boolean isTokenValid(String token,UserDetails userDetails){
      final String username = extractUserName(token);
      return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
   }

   /**
    * Извлечение данных из токена
    *
    * @param token           токен
    * @param claimsResolvers функция извлечения данных
    * @param <T>             тип данных
    * @return данные
    */
   private <T> T extractClaim(String token, Function<Claims,T> claimsResolvers){
      final Claims claims = extractAllClaims(token);
      return claimsResolvers.apply(claims);
   }

//   /**
//    * Генерация токена
//    *
//    * @param  дополнительные данные
//    * @param userDetails данные пользователя
//    * @return токен
//    */
   private String generateToken(Map <String,Object> extraclaims,UserDetails userDetails ){
      return Jwts.builder().setClaims(extraclaims).setSubject(userDetails.getUsername())
              .setIssuedAt(new Date(System.currentTimeMillis()))
              .setExpiration(new Date(Long.MAX_VALUE))
              .signWith(getSigningKey()).compact();
   }

   /**
    * Проверка токена на просроченность
    *
    * @param token токен
    * @return true, если токен просрочен
    */
   private boolean isTokenExpired(String token) {
      return extractExpiration(token).before(new Date());
   }

   /**
    * Извлечение даты истечения токена
    *
    * @param token токен
    * @return дата истечения
    */
   private Date extractExpiration(String token) {
      return extractClaim(token, Claims::getExpiration);
   }

   /**
    * Извлечение всех данных из токена
    *
    * @param token токен
    * @return данные
    */
   private Claims extractAllClaims(String token){
      return Jwts.parser().setSigningKey(getSigningKey()).build().parseClaimsJws(token)
              .getBody();
   }

   /**
    * Получение ключа для подписи токена
    *
    * @return ключ
    */
   private Key getSigningKey() {
      byte[] keyBytes = Decoders.BASE64.decode(jwtSigningKey);
      return Keys.hmacShaKeyFor(keyBytes);
   }


   public String generateTokenModerator(UserDetails userDetails){
      Map<String,Object> claims = new HashMap<>();
      if (userDetails instanceof Moderator customUserDetails) {
         claims.put("id",customUserDetails.getId());
         claims.put("email",customUserDetails.getEmail());
         claims.put("role",customUserDetails.getRole());
         claims.put("phone",customUserDetails.getPhone());
      }
      return generateToken(claims,userDetails);
   }
}
