package kaspi_back_admin.kaspi_back.service;

import kaspi_back_admin.kaspi_back.db.entities.ProductCategory;

import java.util.Optional;

public interface ProductCategoryService {
    ProductCategory getCommissionByCode(String code);
    Optional<ProductCategory> getByTitle(String title);
}