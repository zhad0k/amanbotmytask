package kaspi_back_admin.kaspi_back.service.impl;


import kaspi_back_admin.kaspi_back.db.entities.Order;
import kaspi_back_admin.kaspi_back.db.entities.OrderEntry;
import kaspi_back_admin.kaspi_back.db.enums.UnitType;
import kaspi_back_admin.kaspi_back.db.repository.OrderEntryRepository;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrderEntriesResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class OrderEntryService {


    private final OrderEntryRepository orderEntryRepository;

    @Transactional
    public void upsertEntries(Order order, KaspiOrderEntriesResponse resp) {
        if (resp == null || resp.getData() == null) return;

        for (var e : resp.getData()) {
            var ea = e.getAttributes();
            OrderEntry entry = orderEntryRepository.findByKaspiEntryId(e.getId())
                    .orElseGet(() -> OrderEntry.builder()
                            .kaspiEntryId(e.getId())
                            .order(order)
                            .build());

            entry.setOrder(order);
            entry.setEntryNumber(ea.getEntryNumber());
            entry.setUnitType(safeEnum(UnitType.class, ea.getUnitType()));
            entry.setQuantity(ea.getQuantity());
            entry.setWeight(ea.getWeight());
            entry.setDeliveryCost(ea.getDeliveryCost());
            entry.setBasePrice(ea.getBasePrice());
            entry.setTotalPrice(ea.getTotalPrice());

            if (ea.getCategory() != null) {
                entry.setCategoryCode(ea.getCategory().getCode());
                entry.setCategoryTitle(ea.getCategory().getTitle());
            }
            if (ea.getOffer() != null) {
                entry.setOfferName(ea.getOffer().getName());
            }
            entry.setIsImeiRequired(ea.getIsImeiRequired());

            orderEntryRepository.save(entry);
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateProductCodeByKaspiEntryId(String kaspiEntryId, String productCode) {
        orderEntryRepository.overwriteOfferCode(kaspiEntryId, productCode);
    }

    @Transactional(readOnly = true)
    public Double getWeightByProductCode(String productCode) {
        return orderEntryRepository.getLastWeightByProductCode(productCode);
    }

    private static <E extends Enum<E>> E safeEnum(Class<E> clazz, String raw) {
        if (raw == null) return null;
        try { return Enum.valueOf(clazz, raw); } catch (IllegalArgumentException ex) { return null; }
    }

}
