package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import kaspi_back_admin.kaspi_back.db.entities.NotificationPolicy;
import kaspi_back_admin.kaspi_back.db.repository.NotificationPolicyRepository;
import kaspi_back_admin.kaspi_back.dto.request.NotificationPolicyRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class NotificationService {
    private final NotificationPolicyRepository repo;
    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");

    @Transactional(readOnly = true)
    public Page<NotificationPolicy> getAll(Pageable pageable) {
        return repo.findAll(pageable);
    }

    @Transactional(readOnly = true)
    public NotificationPolicy getByCustomerId(Long customerId) {
        return repo.findAnyByCustomerId(customerId)
                .orElseThrow(() -> new EntityNotFoundException("No notification policy found for customer id: " + customerId));
    }

    @Transactional
    public NotificationPolicy create(NotificationPolicyRequest req) {
        var p = new NotificationPolicy();
        p.setCustomerId(req.customerId());
        p.setAllowedFrom(req.allowedFrom());
        p.setAllowedTo(req.allowedTo());
        p.setDaysMask(maskOf(req.days()));
        return repo.save(p);
    }

    @Transactional
    public NotificationPolicy update(NotificationPolicyRequest req) {
        NotificationPolicy p = repo.findAnyByCustomerId(req.customerId())
                .orElseThrow(() -> new EntityNotFoundException("Policy not found for customer id: " + req.customerId()));

        p.setAllowedFrom(req.allowedFrom());
        p.setAllowedTo(req.allowedTo());
        p.setDaysMask(maskOf(req.days()));

        return repo.save(p);
    }

    @Transactional
    public void delete(Long customerId) {
        NotificationPolicy p = repo.findAnyByCustomerId(customerId)
                .orElseThrow(() -> new EntityNotFoundException("Policy not found for customer id: " + customerId));
        repo.delete(p);
    }

    @Transactional
    public void toggleEnabled(Long customerId) {
        NotificationPolicy p = repo.findAnyByCustomerId(customerId)
                .orElseThrow(() -> new EntityNotFoundException("Policy not found for customer id: " + customerId));
        boolean newEnabledState = !p.isEnabled();
        p.setEnabled(newEnabledState);
        p.setDeletedDate(newEnabledState ? null : OffsetDateTime.now(ZoneOffset.UTC));
    }

    public SendDecision decide(Long customerId, OffsetDateTime nowUtc) {
        var opt = repo.findByCustomer(customerId);
        if (opt.isEmpty()) return new SendDecision(true);

        var p = opt.get();
        var nowLocal = nowUtc.atZoneSameInstant(KZ);
        if (!isDayAllowed(nowLocal.getDayOfWeek(), p.getDaysMask())) return new SendDecision(false);

        var from = p.getAllowedFrom();
        var to   = p.getAllowedTo();
        var t    = nowLocal.toLocalTime();

        boolean overnight = from.isAfter(to);
        boolean inWindow = overnight
                ? (!t.isBefore(from) || t.isBefore(to))
                : (!t.isBefore(from) && t.isBefore(to));

        return new SendDecision(inWindow);
    }

    private boolean isDayAllowed(DayOfWeek dow, int mask) {
        int bit = dow.getValue() - 1;
        return (mask & (1 << bit)) != 0;
    }


    private int maskOf(Set<DayOfWeek> days) {
        int m = 0;
        for (DayOfWeek d : days) {
            int bit = d.getValue() - 1; // Mon=1..Sun=7 -> 0..6
            m |= (1 << bit);
        }
        return m;
    }

    public record SendDecision (boolean allowed){}
}