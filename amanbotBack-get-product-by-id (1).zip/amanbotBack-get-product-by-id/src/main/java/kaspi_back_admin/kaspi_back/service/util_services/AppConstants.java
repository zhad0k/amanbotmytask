package kaspi_back_admin.kaspi_back.service.util_services;

public final class AppConstants {
    private AppConstants() { }

    public static final String DEFAULT_PASSWORD = "123456";

}
