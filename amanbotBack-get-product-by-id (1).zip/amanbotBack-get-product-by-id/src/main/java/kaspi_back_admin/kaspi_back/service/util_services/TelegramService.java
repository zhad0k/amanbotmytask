package kaspi_back_admin.kaspi_back.service.util_services;

import kaspi_back_admin.kaspi_back.db.enums.TelegramNotificationType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class TelegramService {

    private final TelegramSubscriberService telegramSubscriberService;

    @Value("${telegram.bot.token}")
    private String botToken;

    private final RestClient restClient = RestClient.create();

    public void sendCodeNotification(String phone, int code) {
        String text = """
                Новый код подтверждения AmanBot
                Телефон: %s
                Код: %s
                """.formatted(phone, code);

        List<Long> chatIds = telegramSubscriberService.getSubscribedChatIds(
                TelegramNotificationType.SMS_CODE
        );

        for (Long chatId : chatIds) {
            sendMessage(String.valueOf(chatId), text);
        }
    }

    public void sendMessage(String chatId, String text) {
        restClient.post()
                .uri(apiUrl("sendMessage"))
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "chat_id", chatId,
                        "text", text
                ))
                .retrieve()
                .toBodilessEntity();
    }

    public void sendMessageWithInlineKeyboard(
            String chatId,
            String text,
            List<List<Map<String, String>>> keyboard
    ) {
        restClient.post()
                .uri(apiUrl("sendMessage"))
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "chat_id", chatId,
                        "text", text,
                        "reply_markup", Map.of("inline_keyboard", keyboard)
                ))
                .retrieve()
                .toBodilessEntity();
    }

    public void editMessageReplyMarkup(
            String chatId,
            long messageId,
            List<List<Map<String, String>>> keyboard
    ) {
        try {
            restClient.post()
                    .uri(apiUrl("editMessageReplyMarkup"))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of(
                            "chat_id", chatId,
                            "message_id", messageId,
                            "reply_markup", Map.of("inline_keyboard", keyboard)
                    ))
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception e) {
            log.warn(
                    "editMessageReplyMarkup failed for chatId={} messageId={}: {}",
                    chatId,
                    messageId,
                    e.getMessage()
            );
        }
    }

    public void answerCallbackQuery(String callbackQueryId) {
        try {
            restClient.post()
                    .uri(apiUrl("answerCallbackQuery"))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of("callback_query_id", callbackQueryId))
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception e) {
            log.warn("answerCallbackQuery failed for id={}: {}", callbackQueryId, e.getMessage());
        }
    }

    public String getUpdates(long offset) {
        return restClient.get()
                .uri(apiUrl("getUpdates") + "?offset=" + offset + "&timeout=0&limit=100")
                .retrieve()
                .body(String.class);
    }

    private String apiUrl(String method) {
        return "https://api.telegram.org/bot" + botToken + "/" + method;
    }
}