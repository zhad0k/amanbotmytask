package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.repository.ModeratorRepository;
import kaspi_back_admin.kaspi_back.service.ModeratorDetailsService;
import lombok.AllArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ModeratorDetailsServiceImpl implements ModeratorDetailsService {
    private final ModeratorRepository moderatorRepository;

    public Moderator getByUsername(String phone) {
        return moderatorRepository.findByPhone(phone).orElseThrow(
                () -> new EntityNotFoundException("Модератор не найден")
        );
    }

    @Override
    public UserDetailsService userDetailsService() {
        return this::getByUsername;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
}
