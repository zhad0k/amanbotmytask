package kaspi_back_admin.kaspi_back.service.util_services;

import com.fasterxml.jackson.databind.ObjectMapper;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.NotifyStatus;
import kaspi_back_admin.kaspi_back.dto.request.FeedbackRequest;
import kaspi_back_admin.kaspi_back.dto.request.greenapi.MessagePayloadRequest;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.ModeratorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;


@Slf4j
@Service
@RequiredArgsConstructor
public class SmsService {

    @Value("${smsService.key}")
    private String apiKey;
    @Autowired
    private RestTemplate restTemplate;
    @Value("${smsService.whatsapp.apiUrl}")
    private String apiUrl;
    @Value("${smsService.whatsapp.idInstance}")
    private String idInstance;
    @Value("${smsService.whatsapp.apiTokenInstance}")
    private String apiTokenInstance;
    @Value("${smsService.whatsapp.phones}")
    private List<String> phones;
    @Value("${smsService.whatsapp.feedbackPhone}")
    private String feedbackPhone;
    private static final String PREFIX = "7";

    private final ModeratorService moderatorService;
    private final CustomerService customerService;

    public void sendSms(String recipient, String message) {
        HttpClient client = HttpClient.newHttpClient();

        try {
            String url = String.format(
                    "https://api.mobizon.kz/service/message/sendSMSMessage?" +
                            "output=json&apiKey=%s&recipient=%s&text=%s",
                    URLEncoder.encode(apiKey, StandardCharsets.UTF_8),
                    URLEncoder.encode(recipient, StandardCharsets.UTF_8),
                    URLEncoder.encode(message, StandardCharsets.UTF_8)
            );

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            log.info("Mobizon SMS -> recipient: {}, response: {}", recipient, response.body());

        } catch (Exception e) {
            log.error("Mobizon SMS send error -> recipient: {}", recipient, e);
        }
    }

    public void notifyStuff(NotifyStatus operation, Customer customer) {

        for (String phone : phones) {
            String msg;
            if (NotifyStatus.REGISTER.equals(operation)) {
                msg = "Пользователь зарегестрировался " + customer.getFullName() + " .Номер для связи " + customer.getPhone();
            } else {
                msg = "Запрос на покупку тариффа свяжитесь с пользователем чтобы произвести оплату за тарифф" +
                        " " + customer.getFullName() + " .Номер для связи " + customer.getPhone();
            }
            sendWhatsappSms(phone,msg);

        }
    }

    public void feedbackStuff(FeedbackRequest feedbackRequest, Long customerId) {

            if (customerId != null) {
                Customer customer = customerService.findCustomerById(customerId);
//                String message = String.format(
//                        "Имя: %s\nНомер телефона: %s\nТариф: %s",
//                        customer.getFullName(), customer.getPhone(), feedbackRequest.getTariff());
//                sendWhatsappSms(feedbackPhone,message);
            }
            else {
//                String message = String.format(
//                        "Имя: %s\nНомер телефона: %s\nКомментарий: %s\nТариф: %s",
//                        feedbackRequest.getName(), feedbackRequest.getPhone(), feedbackRequest.getComment(), feedbackRequest.getTariff());
//                sendWhatsappSms(feedbackPhone,message);
            }

    }

    public void sendWhatsappSms(String phone, String text) {
        var requestUrl = new StringBuilder();
        requestUrl
                .append(apiUrl)
                .append("/waInstance").append(idInstance)
                .append("/sendMessage/")
                .append(apiTokenInstance);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, String> payload = Map.of(
                "chatId", PREFIX + phone + "@c.us",
                "message", text
        );

        try {
            String body = new ObjectMapper().writeValueAsString(payload);
            HttpEntity<String> requestEntity = new HttpEntity<>(body, headers);

            String response = restTemplate.exchange(requestUrl.toString(), HttpMethod.POST, requestEntity, String.class).getBody();
            log.info("Response: " + response);
        } catch (Exception e) {
            log.error(e.getMessage());
            sendSms(phone, text);
        }
    }

    public void sendWhatsapp(String phone, String text,Long idInstanceCustomer,String tokenGreenApi) {
        var requestUrl = new StringBuilder();
        requestUrl
                .append(apiUrl)
                .append("/waInstance").append(idInstanceCustomer)
                .append("/sendMessage/")
                .append(tokenGreenApi);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, String> payload = Map.of(
                "chatId", PREFIX + phone + "@c.us",
                "message", text
        );

        try {
            String body = new ObjectMapper().writeValueAsString(payload);
            HttpEntity<String> requestEntity = new HttpEntity<>(body, headers);

            String response = restTemplate.exchange(requestUrl.toString(), HttpMethod.POST, requestEntity, String.class).getBody();
            log.info("Response: " + response);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    public void clearQueue(Long customerId) {
        Customer customer = customerService.findCustomerById(customerId);

        var requestUrl = new StringBuilder();
        requestUrl
                .append(apiUrl)
                .append("/waInstance").append(customer.getIdInstance())
                .append("/clearWebhooksQueue/")
                .append(customer.getTokenGreenApi());

        try {
            var response = restTemplate.exchange(requestUrl.toString(), HttpMethod.DELETE, null, String.class);

            log.info("Response: {}", response);
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }

    public void sendWhatsappWithButtons(String phone, String text,Long idInstanceCustomer,
                                        String tokenGreenApi, String url, String shopPhone) {
        var requestUrl = new StringBuilder();
        requestUrl
                .append(apiUrl)
                .append("/waInstance").append(idInstanceCustomer)
                .append("/sendInteractiveButtons/")
                .append(tokenGreenApi);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        MessagePayloadRequest request = MessagePayloadRequest.builder()
                .chatId(PREFIX + phone + "@c.us")
                .body(text)
                .button(MessagePayloadRequest.Button.url("1", "Пікір қалдыру/Оставить отзыв", url))
                .button(MessagePayloadRequest.Button.call("2", "Сатушыға хабарласыңыз/\nСвязаться с продавцом", shopPhone))
                .build();

        request.normalize();

        try {
            String body = new ObjectMapper().writeValueAsString(request);
            HttpEntity<String> requestEntity = new HttpEntity<>(body, headers);

            String response = restTemplate.exchange(requestUrl.toString(), HttpMethod.POST, requestEntity, String.class).getBody();
            log.info("Response: " + response);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }
}
