package kaspi_back_admin.kaspi_back.service.util_services;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Optional;

public class DateConverterUtil {
    private static final ZoneId ZONE_ID = ZoneId.of("Asia/Almaty");

    public static OffsetDateTime toStartOfDay(LocalDate date) {
        return Optional.ofNullable(date)
                .map(d -> d.atStartOfDay(ZONE_ID).toOffsetDateTime())
                .orElse(null);
    }

    public static OffsetDateTime toEndOfDay(LocalDate date) {
        return Optional.ofNullable(date)
                .map(d -> d.atTime(23, 59, 59).atZone(ZONE_ID).toOffsetDateTime())
                .orElse(null);
    }

    public static OffsetDateTime toStartCorrectDate(LocalDate date) {
        return Optional.ofNullable(date)
                .map(d -> d.atTime(12, 0).atZone(ZONE_ID).toOffsetDateTime())
                .orElse(null);
    }
    public static OffsetDateTime toEndCorrectDate(LocalDate date) {
        return Optional.ofNullable(date)
                .map(d -> d.atTime(LocalTime.MAX).atZone(ZONE_ID).toOffsetDateTime().minusSeconds(1))
                .orElse(null);
    }

}
