package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.transaction.Transactional;
import kaspi_back_admin.kaspi_back.db.entities.Review;
import kaspi_back_admin.kaspi_back.db.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {
    private final ReviewRepository reviewRepository;

    @Transactional
    public void  save(Review review) {
        reviewRepository.save(review);
    }

    @Transactional
    public void deleteById(Long reviewId) {
        reviewRepository.deleteById(reviewId);
    }

    public Review findReviewByIdAndCustomerId(Long reviewId, Long customerId) {
        return reviewRepository.findReviewByIdAndCustomerId(reviewId, customerId);
    };

    public List<Review> getReviewsByCustomerId(Long customerId) {
        return reviewRepository.getReviewsByCustomerId(customerId);
    }

    public List<Review> getReviews() {
        return reviewRepository.findAll();
    }
}
