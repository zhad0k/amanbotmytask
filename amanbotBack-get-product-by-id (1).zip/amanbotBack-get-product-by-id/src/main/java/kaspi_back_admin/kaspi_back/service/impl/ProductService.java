package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.repository.ProductRepository;
import kaspi_back_admin.kaspi_back.db.repository.projections.StatisticsRow;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.OffsetDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;

    public Page<Product> getProductsForCustomer(Long customerId, String forSearch, Boolean active, Boolean dampingActive, Pageable pageable) {
        Page<Product> page;
        if (StringUtils.hasText(forSearch)) {
             page = productRepository.findAllByCustomerIdAndTitle(customerId, forSearch.trim(), active, dampingActive, pageable);
        }else {
            page = productRepository.findAllProductByCustomerId(customerId, active, dampingActive, null, pageable);
        }
        if (!page.isEmpty()) {
            productRepository.fetchStocks(page.getContent());
        }
        return page;
    }

    public Long getActiveCountOfProductsForCustomer(Long id) {
        return productRepository.getActiveCountOfProductsForCustomer(id);
    }

    public void save(Product product) {
        productRepository.save(product);
    }

    public Product findByProductIdAndCustomerId(Long customerId, Long productId) {
        return productRepository.findByIdAndCustomerId(customerId,productId)
                .orElseThrow(EntityNotFoundException::new);
    }

    public void delete(Product product) {
        productRepository.delete(product);
    }

    public List<Object[]> aggregateCountForCustomer(Long customerId) {
        return productRepository.aggregateCountForCustomer(customerId);
    }

    public List<Product> findAllByCustomerId(Long customerId){
        return productRepository.findAllByCustomerId(customerId);
    }

    public List<Product> findAllByIdsAndCustomerId(List<Long> ids, Long customerId) {
        return productRepository.findAllByIdInAndCustomerId(ids, customerId);
    }
    public List<Product> findAllActiveByCustomerId(Long customerId) {
        return productRepository.findAllActiveByCustomerId(customerId);
    }

    public List<Product> findAllMassDeactivatedByCustomerId(Long customerId) {
        return productRepository.findAllMassDeactivatedByCustomerId(customerId);
    }
    public void saveAll(List<Product> products) {
        productRepository.saveAll(products);
    }

    public Page<StatisticsRow> findAllWithFullStats(Long id, String forSearch, boolean available, OffsetDateTime start, OffsetDateTime end, Pageable pageable) {
        return productRepository.findAllWithFullStats(id, forSearch, available, start ,end, pageable);
    }

    @Transactional(readOnly = true)
    public List<Object[]> getCustomerProductDailyStatistics(Long customerId, Long productId, OffsetDateTime fromDate, OffsetDateTime toDate) {
        return productRepository.getCustomerProductDailyStatistics(customerId, productId, fromDate, toDate);
    }

    @Transactional(readOnly = true)
    public List<Object[]> getCustomerProductMonthlyStatistics(Long customerId, Long productId, OffsetDateTime fromDate, OffsetDateTime toDate) {
        return productRepository.getCustomerProductMonthlyStatistics(customerId, productId, fromDate, toDate);
    }

    @Transactional(readOnly = true)
    public List<Object[]> getCustomerProductSalesStatistics(Long customerId, Long productId, OffsetDateTime fromDate, OffsetDateTime toDate) {
        return productRepository.getCustomerProductSales(customerId, productId, fromDate, toDate);
    }


}
