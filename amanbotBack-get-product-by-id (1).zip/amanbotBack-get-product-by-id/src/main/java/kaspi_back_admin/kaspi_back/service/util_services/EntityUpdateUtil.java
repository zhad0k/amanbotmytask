package kaspi_back_admin.kaspi_back.service.util_services;

import org.springframework.util.StringUtils;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public final class EntityUpdateUtil {

    private EntityUpdateUtil() {}

    /** Присвоить, если поставщик вернул не null */
    public static <T> void setIfPresent(Consumer<T> setter, T value) {
        if (value != null) setter.accept(value);
    }

    /** Присвоить строку, если она не пустая/не состоит из пробелов (trim применяется) */
    public static void setIfHasText(Consumer<String> setter, Supplier<String> supplier) {
        String v = supplier.get();
        if (StringUtils.hasText(v)) setter.accept(v.trim());
    }

    /** Присвоить с преобразованием, если исходное значение не null */
    public static <I, O> void setIfPresent(Consumer<O> setter, Supplier<I> supplier, Function<I, O> mapper) {
        I in = supplier.get();
        if (in != null) setter.accept(mapper.apply(in));
    }
}