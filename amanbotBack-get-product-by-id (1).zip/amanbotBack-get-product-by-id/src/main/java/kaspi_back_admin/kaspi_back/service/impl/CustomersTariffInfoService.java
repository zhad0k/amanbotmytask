package kaspi_back_admin.kaspi_back.service.impl;

import kaspi_back_admin.kaspi_back.db.entities.CustomersTariffInfo;
import kaspi_back_admin.kaspi_back.db.repository.CustomersTariffInfoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class CustomersTariffInfoService {
    private final CustomersTariffInfoRepository customersTariffInfoRepository;

    public void save(CustomersTariffInfo customersTariffInfo) {
        customersTariffInfoRepository.save(customersTariffInfo);
    }

    public List<CustomersTariffInfo> getAllForCustomer(Long customerId) {
        return customersTariffInfoRepository.getAllByCustomerId(customerId);
    }

    public void saveAll(List<CustomersTariffInfo> activeTariffs) {
        customersTariffInfoRepository.saveAll(activeTariffs);
    }
}
