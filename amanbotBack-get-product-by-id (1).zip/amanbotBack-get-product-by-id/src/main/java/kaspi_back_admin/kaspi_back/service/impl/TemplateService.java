package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import kaspi_back_admin.kaspi_back.db.entities.Template;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import kaspi_back_admin.kaspi_back.db.repository.TemplateRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.EnumSet;
import java.util.List;

@Service
@AllArgsConstructor
public class TemplateService {
    private final TemplateRepository templateRepository;

    public void save(Template template) {
        templateRepository.save(template);
    }

    public Template findTemplateByCustomerId(Long id, SyncType type) {
        return templateRepository.findAllTemplatesByCustomerId(id,type);
    }

    public Template findRandomTemplate(SyncType syncType) {
        return templateRepository.findRandomTemplate(syncType);
    }

    public List<Template> findAllByTypeIn(EnumSet<SyncType> types) {
        return templateRepository.findAllByTypeIn(types);
    }

    public void deleteTemplateById(Long templateId) {
        templateRepository.deleteById(templateId);
    }

    public Template findTemplateById(Long templateId) {
        return templateRepository.findById(templateId).orElseThrow(
                EntityNotFoundException::new
        );
    }
}
