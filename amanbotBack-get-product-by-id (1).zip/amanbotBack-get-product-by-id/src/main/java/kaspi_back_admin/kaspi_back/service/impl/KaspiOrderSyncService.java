package kaspi_back_admin.kaspi_back.service.impl;


import kaspi_back_admin.kaspi_back.api.KaspiClient;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Order;
import kaspi_back_admin.kaspi_back.db.enums.DeliveryType;
import kaspi_back_admin.kaspi_back.db.enums.OrderState;
import kaspi_back_admin.kaspi_back.db.enums.OrderStatus;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrderEntriesResponse;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrdersResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class KaspiOrderSyncService {

    private final KaspiClient kaspiClient;
    private final OrderService orderService;
    private final OrderEntryService orderEntryService;

    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");

    @Transactional
    public void syncForCustomerForPeriod(Customer customer, OffsetDateTime from,  OffsetDateTime to) {
        String token = customer.getTokenProd();
        long ge = from.toInstant().toEpochMilli();
        long le = to.toInstant().toEpochMilli();

        List<OrderState> states = Arrays.asList(OrderState.values());
        List<OrderStatus> statuses = Arrays.asList(OrderStatus.values());
        List<DeliveryType> deliveries = Arrays.asList(DeliveryType.PICKUP, DeliveryType.DELIVERY);

        for (OrderState state : states) {
            for (OrderStatus status : statuses) {
                for (DeliveryType delivery : deliveries) {

                    int pageSize = 20;
                    boolean keep = true;

                    while (keep) {
                        String query = buildQuery(state, status, delivery, ge, le, 0, pageSize, false);

                        KaspiOrdersResponse resp = null;
                        try {
                            resp = kaspiClient.getOrders(token, query);
                        } catch (Exception e) {
                            log.warn("Kaspi getOrders failed: {}", e.getMessage());
                        }

                        if (resp == null || resp.getData() == null || resp.getData().isEmpty()) {
                            keep = false;
                            continue;
                        }

                        for (var d : resp.getData()) {
                            Order order = orderService.upsertFromKaspi(customer, d);
                            KaspiOrderEntriesResponse entries = null;
                            try {
                                entries = kaspiClient.getOrderEntries(token, d.getId());
                            } catch (Exception e) {
                                log.warn("Kaspi getOrderEntries failed for {}: {}", d.getId(), e.getMessage());
                            }
                            orderEntryService.upsertEntries(order, entries);
                        }

                        pageSize += 50;
                    }
                }
            }
        }
    }

    private String buildQuery(OrderState state, OrderStatus status, DeliveryType delivery,
                              long ge, long le, int pageNumber, int pageSize, boolean signatureRequired) {
        return new StringBuilder()
                .append("?page[number]=").append(pageNumber)
                .append("&page[size]=").append(pageSize)
                .append("&filter[orders][state]=").append(state.name())
                .append("&filter[orders][creationDate][$ge]=").append(ge)
                .append("&filter[orders][creationDate][$le]=").append(le)
                .append("&filter[orders][status]=").append(status.name())
                .append("&filter[orders][deliveryType]=").append(delivery.name())
                .append("&filter[orders][signatureRequired]=").append(signatureRequired)
                .append("&include[orders]=user")
                .toString();
    }
}
