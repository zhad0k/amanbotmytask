package kaspi_back_admin.kaspi_back.service.util_services;

import jakarta.annotation.PostConstruct;
import kaspi_back_admin.kaspi_back.db.enums.NewOrderTemplate;
import kaspi_back_admin.kaspi_back.db.enums.ReviewTemplate;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import kaspi_back_admin.kaspi_back.dto.TemplateVarDto;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import static kaspi_back_admin.kaspi_back.db.enums.PermissionMessageTemplate.*;

@Component
public class DefaultMessagesUtil {

    public static Map<SyncType, List<TemplateVarDto>> TEMPLATE_VARS;

    @PostConstruct
    private void init() {
        //Общие переменные )=
        TemplateVarDto CUSTOMER_NAME = new TemplateVarDto("customerName", "Имя покупателя", "Сатып алушының аты", "Жанатаев Оразбек");
        TemplateVarDto SHOP_NAME = new TemplateVarDto("shopName", "Название магазина", "Дүкен атауы", "ТОО «Digital World»");
        TemplateVarDto PRODUCT_NAME = new TemplateVarDto("productName", "Название товара", "Тауар атауы", "Apple MacBook Air M2");
        TemplateVarDto ORDER_ID = new TemplateVarDto("orderId", "Номер заказа", "Тапсырыс нөмірі", "ORD-10245");

        // NEW_ORDER переменные )=
        TemplateVarDto AMOUNT = new TemplateVarDto("amount", "Количество", "Саны", "2");
        TemplateVarDto DELIVERY_ADDRESS = new TemplateVarDto("deliveryAddress", "Адрес доставки", "Жеткізу мекенжайы", "г. Алматы, ул. Абая, 45, офис 12");
        TemplateVarDto EXPECTED_ARRIVAL_DATE = new TemplateVarDto("expectedArrivalDate", "Ожидаемая дата прибытия", "Күтілетін келу күні", "2025-10-10");

        // DELIVERED_COMPLETED переменные )=
        TemplateVarDto PRICE = new TemplateVarDto("price", "Цена", "Бағасы", "720000");
        TemplateVarDto LINK = new TemplateVarDto("link", "Ссылка на отзыв", "Пікір сілтемесі", "https://digitalworld.kz/orders/ORD-10245");

        List<TemplateVarDto> all = List.of(CUSTOMER_NAME, SHOP_NAME, PRODUCT_NAME, ORDER_ID, AMOUNT, DELIVERY_ADDRESS, EXPECTED_ARRIVAL_DATE, PRICE, LINK);

        Map<SyncType, List<TemplateVarDto>> map = new EnumMap<>(SyncType.class);
        map.put(SyncType.NEW_ORDER, List.of(
                CUSTOMER_NAME, SHOP_NAME, PRODUCT_NAME, AMOUNT, ORDER_ID, DELIVERY_ADDRESS, EXPECTED_ARRIVAL_DATE
        ));

        map.put(SyncType.DELIVERED_COMPLETED, List.of(
                CUSTOMER_NAME, SHOP_NAME, PRODUCT_NAME, PRICE, ORDER_ID, LINK
        ));

        TEMPLATE_VARS = Collections.unmodifiableMap(map);
    }

    public static String buildDefaultDeliveredCompletedRu(String name, String shop, String offer, String price, String orderNum,
                                                          String reviewUrl) {
        return String.format(ReviewTemplate.START_RU.getText(), name, shop)
                + String.format(ReviewTemplate.ORDER_INFO_RU.getText(), offer, price, orderNum)
                + String.format(ReviewTemplate.PRODUCT_LINK_RU.getText(), reviewUrl)
                + ReviewTemplate.CONTACT_RU.getText();
    }

    public static String buildDefaultDeliveredCompletedKz(String name, String shop, String offer, String price, String orderNum,
                                                    String reviewUrl) {
        return String.format(ReviewTemplate.START_KZ.getText(), name, shop)
                + String.format(ReviewTemplate.ORDER_INFO_KZ.getText(), offer, price, orderNum)
                + String.format(ReviewTemplate.PRODUCT_LINK_KZ.getText(), reviewUrl)
                + ReviewTemplate.CONTACT_KZ.getText();
    }

    public static String buildDefaultNewOrderRu(String name, String shop, String offer, String quantity, String orderNum,
                                          String address, String date) {
        return String.format(NewOrderTemplate.START_RU.getText(), name, shop)
                + String.format(NewOrderTemplate.ORDER_INFO_RU.getText(), offer, quantity, orderNum)
                + String.format(NewOrderTemplate.DELIVERY_INFO_RU.getText(), address, date)
                + String.format(NewOrderTemplate.FOOTER_RU.getText(), shop);
    }

    public static String buildDefaultNewOrderKz(String name, String shop, String offer, String quantity, String orderNum,
                                          String address, String date) {
        return String.format(NewOrderTemplate.START_KZ.getText(), name, shop)
                + String.format(NewOrderTemplate.ORDER_INFO_KZ.getText(), offer, quantity, orderNum)
                + String.format(NewOrderTemplate.DELIVERY_INFO_KZ.getText(), address, date)
                + String.format(NewOrderTemplate.FOOTER_KZ.getText(), shop);
    }

    public static String buildDefaultDeliveredCompletedRuPermission(String name, String shop) {
        return String.format(AFTER_RECEIVING_RU.getText(), name,shop);
    }

    public static String buildDefaultDeliveredCompletedKzPermission(String name, String shop) {
        return String.format(AFTER_RECEIVING_KZ.getText(), name,shop);
    }

    public static String buildDefaultNewOrderRuPermission(String name, String shop) {
        return String.format(AFTER_PAYMENT_RU.getText(), name,shop);
    }

    public static String buildDefaultNewOrderKzPermission(String name, String shop) {
        return String.format(AFTER_PAYMENT_KZ.getText(), name,shop);
    }
}
