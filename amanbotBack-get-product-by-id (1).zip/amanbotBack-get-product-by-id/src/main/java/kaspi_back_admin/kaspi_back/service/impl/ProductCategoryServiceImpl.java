package kaspi_back_admin.kaspi_back.service.impl;

import kaspi_back_admin.kaspi_back.db.entities.ProductCategory;
import kaspi_back_admin.kaspi_back.db.repository.ProductCategoryRepository;
import kaspi_back_admin.kaspi_back.service.ProductCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class ProductCategoryServiceImpl implements ProductCategoryService {
    private final ProductCategoryRepository productCategoryRepository;

    @Override
    @Transactional(readOnly = true)
    public ProductCategory getCommissionByCode(String code) {
        return productCategoryRepository.findByCode(code).orElse(null);
    }

    @Override
    @Transactional
    public Optional<ProductCategory> getByTitle(String title) {
        return productCategoryRepository.findByTitle(title);
    }
}
