package kaspi_back_admin.kaspi_back.service;

import kaspi_back_admin.kaspi_back.db.entities.KaspiDeliveryRate;

import java.math.BigDecimal;

public interface KaspiDeliveryRateService {
    BigDecimal getPrice(
            BigDecimal orderTotal,
            BigDecimal weightKg,
            KaspiDeliveryRate.TireType tireType,
            Zone zone
    );

    enum Zone {CITY, KZ, EXPRESS}
}
