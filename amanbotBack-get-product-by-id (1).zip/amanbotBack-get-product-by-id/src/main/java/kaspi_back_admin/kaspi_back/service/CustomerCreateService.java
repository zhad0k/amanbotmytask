package kaspi_back_admin.kaspi_back.service;

import kaspi_back_admin.kaspi_back.dto.request.SignUpRequest;
import org.springframework.data.util.Pair;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface CustomerCreateService extends UserDetailsService {

    Pair<String,Long> create(SignUpRequest request) throws Exception;

    UserDetailsService userDetailsService();

    Pair<String,Long> passwordRecovery(SignUpRequest request) throws Exception;

}
