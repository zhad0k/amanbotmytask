package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import kaspi_back_admin.kaspi_back.db.entities.Period;
import kaspi_back_admin.kaspi_back.db.repository.PeriodRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class PeriodService {
    private final PeriodRepository periodRepository;

    public Period findById(Long periodId) {
        return periodRepository.findById(periodId).orElseThrow(
                () -> new EntityNotFoundException("Period not found with id: " + periodId));
    }

    public List<Period> getAll() {
        return periodRepository.findAll();
    }
}
