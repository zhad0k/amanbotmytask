package kaspi_back_admin.kaspi_back.service.util_services;


import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import kaspi_back_admin.kaspi_back.dto.request.SignInRequest;
import lombok.AllArgsConstructor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
@AllArgsConstructor
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        SignInRequest signInRequest = (SignInRequest) authentication.getPrincipal();
        Customer customer = customerRepository.findByPhone(signInRequest.getPhone());
        if (customer != null && passwordEncoder.matches(signInRequest.getPassword(), customer.getPassword())) {
            return new UsernamePasswordAuthenticationToken(customer.getId(), signInRequest.getPassword(), new ArrayList<>());
        } else {
            throw new BadCredentialsException("Неверные учетные данные");
        }
    }


    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
