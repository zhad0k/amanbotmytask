package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.transaction.Transactional;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.SmsAndWhatCode;
import kaspi_back_admin.kaspi_back.db.enums.Role;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import kaspi_back_admin.kaspi_back.db.repository.SmsAndWhatCodeRepository;
import kaspi_back_admin.kaspi_back.dto.request.SignUpRequest;
import kaspi_back_admin.kaspi_back.service.CustomerCreateService;
import kaspi_back_admin.kaspi_back.service.util_services.SmsService;
import kaspi_back_admin.kaspi_back.service.util_services.TelegramService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.util.Pair;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerCreateServiceImpl implements CustomerCreateService {

    private final CustomerRepository customerRepository;
    private final SmsAndWhatCodeRepository smsCodeRepository;
    private final PasswordEncoder passwordEncoder;
    private final SmsService smsService;
    private final TelegramService telegramService;

    @Transactional
    public Pair<String,Long> create(SignUpRequest request) throws Exception {

        if (customerRepository.existsByPhone(request.getPhone())){
            return Pair.of("Пользователь с таким номером уже существует",0L);
        }
        if (request.getPassword() != null) {
            return handleCustomerCreate(request);
        }else if (request.getSmsCode()==null || request.getSmsCode().isEmpty()){
            return handleSmsCodeGeneration(request);
        }else {
            return handleSmsCodeClientVerification(request);
        }
    }

    public Customer getByUsername(String username) {
        return customerRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Пользователь не найден"));

    }

    @Override
    public UserDetailsService userDetailsService() {
        return this::getByUsername;
    }

    @Override
    public Pair<String, Long> passwordRecovery(SignUpRequest request) throws Exception {
        if (request.getSmsCode().isEmpty()){
            return handleSmsCodeGenerationPasswordRecovery(request);
        } else if (!request.getPassword().isEmpty()) {
            return handleSmsCodeVerificationForPassRecovery(request);
        }else {
            return handleSmsCodeClientVerification(request);
        }
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }


    private Pair<String, Long> handleSmsCodeGeneration(SignUpRequest request) throws Exception {
        int random_number = generateRandomCode();
        String text = "AmanAl: " + random_number;
        saveSmsCode(request.getPhone(), random_number);
        smsService.sendSms(request.getPhone(), text);
        telegramService.sendCodeNotification(request.getPhone(), random_number);
        return Pair.of("smsCode отправлен", 0L );
    }

    private void saveSmsCode(String phone, int code) {
        SmsAndWhatCode smsCode = SmsAndWhatCode.builder()
                .code(code)
                .phone(phone)
                .used(false)
                .build();
        smsCodeRepository.save(smsCode);
    }

    private int generateRandomCode() {
        return 1111 + (int) (Math.random() * ((9999 - 1111) + 1));
    }

    private Pair<String, Long> handleSmsCodeClientVerification(SignUpRequest request) {
        if (smsCodeRepository.existsByPhoneAndCode(request.getPhone(), request.getSmsCode())) {
            return Pair.of("Смс код верный", 0L);
        } else {
            return Pair.of("Смс код неверный", 0L);
        }
    }

    private Pair<String,Long> handleCustomerCreate(SignUpRequest request){
        Customer customer = createCustomer(request);
        log.info("Создан объект клиента (без сохранения в БД): {}", customer);
        Customer customerSave = customerRepository.save(customer);
        return Pair.of("customer создан или обновлен",customerSave.getId());
    }

    private Customer createCustomer(SignUpRequest request){
        return Customer.builder()
                .role(Role.ROLE_CLIENT)
                .phone(request.getPhone())
                .fullName(request.getFullName())
                .lastName(request.getLastName())
                .isActive(true)
                .email(request.getEmail())
                .isManuallyEdited(false)
                .createdDate(OffsetDateTime.now())
                .password(passwordEncoder.encode(request.getPassword()))
                .email(request.getEmail())
                .tariffType(TariffType.NOTIFICATION_FREE)
                .hasKaspiMerchantPassword(Boolean.FALSE)
                .build();

    }

    private Pair<String, Long> handleSmsCodeVerificationForPassRecovery(SignUpRequest request) {
        Customer customer = customerRepository.findByPhone(request.getPhone());
        if (customer == null) {
            log.error("Пользователь не найден");
            throw new NoSuchElementException("Пользователь не найден");
        }
        customer.setPassword(passwordEncoder.encode(request.getPassword()));
        customerRepository.save(customer);
        return Pair.of("Пароль успешно изменен", 0L);
    }

    private Pair<String, Long> handleSmsCodeGenerationPasswordRecovery(SignUpRequest request) {
        Customer customer = customerRepository.findByPhone(request.getPhone());
        if (customer == null){
            return Pair.of("Клиент отсутствует",0L);
        }
        int random_number = generateRandomCode();
        String text = "AmanAl:" + random_number;
        saveSmsCode(request.getPhone(), random_number);
        smsService.sendSms(request.getPhone(), text);
        telegramService.sendCodeNotification(request.getPhone(), random_number);
        return Pair.of("smsCode отправлен", 0L );
    }
}
