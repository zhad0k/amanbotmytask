package kaspi_back_admin.kaspi_back.service.util_services;


import kaspi_back_admin.kaspi_back.db.enums.NotifyStatus;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import kaspi_back_admin.kaspi_back.db.repository.ModeratorRepository;
import kaspi_back_admin.kaspi_back.dto.response.JwtAuthenticationResponse;
import kaspi_back_admin.kaspi_back.dto.request.SignInRequest;
import kaspi_back_admin.kaspi_back.dto.request.SignUpRequest;
import kaspi_back_admin.kaspi_back.service.CustomerCreateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.util.Pair;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final CustomerCreateService customerCreateService;
    private final JwtService jwtService;
    private final CustomAuthenticationProvider customAuthenticationProvider;
    private final CustomerRepository customerRepository;
    private final SmsService smsService;
    private final ModeratorRepository moderatorRepository;
    private final ModeratorAuthenticationProvider moderatorAuthenticationProvider;

    /**
     * Регистрация пользователя
     *
     * @param request данные пользователя
     * @return токен
     */
    public JwtAuthenticationResponse signUp(SignUpRequest request) {
            try {
                Pair<String, Long> result = customerCreateService.create(request);
                if (result.getFirst().equals("customer создан или обновлен")) {
                    var customer = customerRepository.getReferenceById(result.getSecond());
                    var jwt = jwtService.generateToken(customer);
//                    smsService.notifyStuff(NotifyStatus.REGISTER, customer);
                    return new JwtAuthenticationResponse(jwt, result.getFirst());
                } else {
                    return new JwtAuthenticationResponse(null, result.getFirst());
                }
            }catch (BadCredentialsException ex){
                return new JwtAuthenticationResponse(null,"Неверно учетные данные");
            } catch (DataIntegrityViolationException ex) {
                log.warn("Попытка создать дублирующего пользователя: {}", ex.getMessage());
                return new JwtAuthenticationResponse(null, "Пользователь с таким номером уже существует");
            }catch (Exception e) {
                log.error("Ошибка при регистарации пользователя {}", e.getMessage());
                throw new RuntimeException(e);
            }
    }

    /**
     * Аутентификация пользователя
     *
     * @param request данные пользователя
     * @return токен
     */
    public JwtAuthenticationResponse signIn(SignInRequest request) {
        try {
            Authentication authentication = new UsernamePasswordAuthenticationToken(request, null);
            Authentication authenticationprovider = customAuthenticationProvider.authenticate(authentication);
            Long customerId = (Long) authenticationprovider.getPrincipal();
            var customer = customerRepository.getReferenceById(customerId);
            var jwt = jwtService.generateToken(customer);
            return new JwtAuthenticationResponse(jwt, "success");
        }catch (BadCredentialsException ex){
            return new JwtAuthenticationResponse(null,"Неверно учетные данные");
        }
    }

    public JwtAuthenticationResponse signInModerator(SignInRequest request) {
        try {
            Authentication authentication = new UsernamePasswordAuthenticationToken(request, null);
            Authentication authenticationprovider = moderatorAuthenticationProvider.authenticate(authentication);
            Long moderatorId = (Long) authenticationprovider.getPrincipal();
            var moderator = moderatorRepository.getReferenceById(moderatorId);
            var jwt = jwtService.generateTokenModerator(moderator);
            return new JwtAuthenticationResponse(jwt, "success");
        }catch (BadCredentialsException ex){
            return new JwtAuthenticationResponse(null,"Неверно учетные данные");
        }
    }


}
