package kaspi_back_admin.kaspi_back.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import java.time.Duration;

@Service
@Slf4j
public class KaspiLoginService {

    private final WebDriver driver;

    @Autowired
    public KaspiLoginService(@Lazy WebDriver driver) {
        this.driver = driver;
    }

    public String loginWithPhone(String phoneNumber) {
        try {
            log.info("Начинаем процесс входа для номера: {}", phoneNumber);


            driver.get("https://idmc.shop.kaspi.kz/login");
            log.debug("Страница входа загружена");


            Thread.sleep(2000);


            switchToPhoneTab();
            log.debug("Переключились на вкладку телефона");


            enterPhoneNumber(phoneNumber);
            log.debug("Номер телефона введён: {}", phoneNumber);


            clickContinueButton();
            log.debug("Кнопка 'Продолжить' нажата");


            Thread.sleep(3000);


            return getLoginResult();

        } catch (Exception e) {
            log.error("Ошибка при входе", e);
            return "Ошибка: " + e.getMessage();
        }
    }

    private void switchToPhoneTab() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement phoneTab = wait.until(ExpectedConditions
                    .elementToBeClickable(By.id("phone_tab")));
            phoneTab.click();
            Thread.sleep(1000);
        } catch (Exception e) {
            log.warn("Не удалось найти вкладку телефона, продолжаем…");
        }
    }

    private void enterPhoneNumber(String phoneNumber) {
        try {

            WebElement phoneField = findInputField();
            phoneField.clear();
            phoneField.sendKeys(phoneNumber);
        } catch (Exception e) {
            throw new RuntimeException("Не удалось найти поле для ввода телефона: " + e.getMessage());
        }
    }

    private WebElement findInputField() {

        String[] selectors = {
                "input[name='username']",
                "input[type='tel']",
                "input[inputmode='tel']",
                "#user_email_field",
                ".text-field",
                "input"
        };

        for (String selector : selectors) {
            try {
                WebElement element = driver.findElement(By.cssSelector(selector));
                if (element.isDisplayed()) {
                    return element;
                }
            } catch (Exception e) {
                // Продолжаем поиск
            }
        }
        throw new RuntimeException("Не удалось найти поле для ввода");
    }

    private void clickContinueButton() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


            String[] buttonSelectors = {
                    "button.is-primary",
                    "button[type='submit']",
                    ".button",
                    "button"
            };

            for (String selector : buttonSelectors) {
                try {
                    WebElement button = wait.until(ExpectedConditions
                            .elementToBeClickable(By.cssSelector(selector)));
                    if (button.isDisplayed() && button.isEnabled()) {
                        button.click();
                        return;
                    }
                } catch (Exception e) {
                    // Продолжаем поиск
                }
            }

            throw new RuntimeException("Не удалось найти кнопку 'Продолжить'");

        } catch (Exception e) {
            throw new RuntimeException("Ошибка при нажатии кнопки: " + e.getMessage());
        }
    }

    private String getLoginResult() {
        try {

            String currentUrl = driver.getCurrentUrl();
            log.debug("Текущий URL: {}", currentUrl);


            try {
                driver.findElement(By.cssSelector("input[type='password']"));
                return "Успешно! Перешли на страницу ввода пароля для номера: 7783485916";
            } catch (Exception e) {
                // Поле пароля не найдено
            }


            try {
                WebElement error = driver.findElement(By.cssSelector(".error, .alert, .message-error"));
                return "Ошибка: " + error.getText();
            } catch (Exception e) {
                // Ошибок не найдено
            }

            return "Неизвестный статус. Текущая страница: " + currentUrl;

        } catch (Exception e) {
            return "Ошибка при получении результата: " + e.getMessage();
        }
    }

    public void closeDriver() {
        try {
            if (driver != null) {
                driver.quit();
            }
        } catch (Exception e) {
            log.warn("Ошибка при закрытии драйвера", e);
        }
    }
}