package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.db.jdbc.CustomerJdbcRepository;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerService {
    private final CustomerRepository customerRepository;
    private final CustomerJdbcRepository customerJdbcRepository;

    public Customer findCustomerById(Long customerId) {
        return customerRepository.findById(customerId).orElseThrow(() -> new EntityNotFoundException("Customer not found"));
    }
    public Customer findCustomerByIdInstanceOrName(Long idInstance, String name) {
        return customerRepository.findByIdInstanceOrFullNameContains(idInstance, name).orElse(null);
    }
    @Transactional
    public void saveCustomer(Customer customer) {
        customerRepository.save(customer);
    }

    @Transactional
    public Customer saveCustomerAndReturn(Customer customer) {
        return customerRepository.save(customer);
    }

    @Transactional
    public void deleteCustomer(Long customerId) {
        customerRepository.deleteById(customerId);
    }

    public List<Customer> findAllWithProdTokenTariff() {
        OffsetDateTime today = OffsetDateTime.now();
        return customerRepository.findAllWithProdTokenTariff(today);
    }

    public List<Customer> findAllWithProdTokenTariffIsNotNullTokenGreenApi() {
        OffsetDateTime today = OffsetDateTime.now();
        return customerRepository.findAllWithProdTokenTariffNotTokenGreenApi(today);
    }

    public Page<Customer> getAllCustomers(String tariff, String forSearch, OffsetDateTime dateFrom, OffsetDateTime dateTo, Pageable pageable) {
        return customerJdbcRepository.searchCustomers(tariff, forSearch, dateFrom, dateTo, pageable);
    }

    public Page<Customer> getAllTrial(String forSearch, OffsetDateTime dateFrom, OffsetDateTime dateTo,
                                      Boolean active, Long managerId, Pageable pageable) {
        return customerRepository.searchTrial(forSearch, active, dateFrom, dateTo, managerId, pageable);
    }

    public List<Customer> findCustomersSpecial() {
        return customerRepository.findCustomersByIdsIn();
    }

    public Page<Customer> search(String forSearch, Boolean active, TariffType tariffType, OffsetDateTime from,
                                 OffsetDateTime to, Long managerId, Pageable pageable) {
            return customerRepository.search(forSearch, active, tariffType, from, to, managerId, pageable);
    }

    public Page<Customer> searchNotification(String forSearch, Boolean active, TariffType tariffType, OffsetDateTime from,
                                             OffsetDateTime to, Long managerId, Pageable pageable) {
        return customerRepository.searchNotification(forSearch, active, tariffType, from, to, managerId, pageable);
    }

    public Page<Customer> searchVip(String forSearch, Boolean active, TariffType tariffType, OffsetDateTime from,
                                    OffsetDateTime to, Long managerId, Pageable pageable) {
        return customerRepository.searchVip(forSearch, active, tariffType, from, to, managerId, pageable);
    }

    @Transactional
    public void deleteCustomers(Long id) {
        customerRepository.deleteById(id);
    }

    public boolean existsByPhone(String phone) {
        return customerRepository.existsByPhone(phone);
    }
}
