package kaspi_back_admin.kaspi_back.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface ModeratorDetailsService extends UserDetailsService {
    UserDetailsService userDetailsService();
}
