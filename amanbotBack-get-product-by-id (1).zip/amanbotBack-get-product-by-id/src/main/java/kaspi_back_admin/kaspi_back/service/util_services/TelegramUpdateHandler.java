package kaspi_back_admin.kaspi_back.service.util_services;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import kaspi_back_admin.kaspi_back.db.enums.TelegramNotificationType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Slf4j
@Service
@RequiredArgsConstructor
public class TelegramUpdateHandler {

    private final TelegramService telegramService;
    private final TelegramSubscriberService subscriberService;
    private final ObjectMapper objectMapper;

    private final AtomicLong offset = new AtomicLong(0);

    @Scheduled(fixedDelay = 3000)
    public void pollUpdates() {
        try {
            String response = telegramService.getUpdates(offset.get());
            if (response == null) {
                return;
            }

            JsonNode root = objectMapper.readTree(response);
            if (!root.path("ok").asBoolean()) {
                return;
            }

            for (JsonNode update : root.path("result")) {
                long updateId = update.path("update_id").asLong();
                offset.set(updateId + 1);

                try {
                    processUpdate(update);
                } catch (Exception e) {
                    log.error("Error processing Telegram update {}: {}", updateId, e.getMessage());
                }
            }
        } catch (Exception e) {
            log.error("Error polling Telegram updates: {}", e.getMessage());
        }
    }

    private void processUpdate(JsonNode update) {
        if (update.has("message")) {
            processMessage(update.path("message"));
        } else if (update.has("callback_query")) {
            processCallbackQuery(update.path("callback_query"));
        }
    }

    private void processMessage(JsonNode message) {
        String text = message.path("text").asText("").trim();
        if (text.isBlank()) {
            return;
        }

        Long chatId = message.path("chat").path("id").asLong();
        JsonNode from = message.path("from");

        if (text.startsWith("/start") || text.startsWith("/settings")) {
            subscriberService.registerOrActivate(
                    chatId,
                    from.path("username").asText(null),
                    from.path("first_name").asText(null),
                    from.path("last_name").asText(null)
            );

            sendSettingsMenu(chatId);
        }
    }

    private void processCallbackQuery(JsonNode callbackQuery) {
        String callbackId = callbackQuery.path("id").asText();
        Long chatId = callbackQuery.path("message").path("chat").path("id").asLong();
        long messageId = callbackQuery.path("message").path("message_id").asLong();
        String data = callbackQuery.path("data").asText();

        telegramService.answerCallbackQuery(callbackId);

        if (!data.startsWith("toggle:")) {
            return;
        }

        String typeName = data.substring("toggle:".length());

        try {
            TelegramNotificationType type = TelegramNotificationType.valueOf(typeName);
            subscriberService.toggle(chatId, type);

            telegramService.editMessageReplyMarkup(
                    String.valueOf(chatId),
                    messageId,
                    buildKeyboard(chatId)
            );
        } catch (IllegalArgumentException | IllegalStateException e) {
            log.warn("Could not toggle subscription for chatId={}: {}", chatId, e.getMessage());
        }
    }

    private void sendSettingsMenu(Long chatId) {
        telegramService.sendMessageWithInlineKeyboard(
                String.valueOf(chatId),
                "⚙️ Настройки уведомлений\n\nВыберите, какие уведомления вы хотите получать:",
                buildKeyboard(chatId)
        );
    }

    private List<List<Map<String, String>>> buildKeyboard(Long chatId) {
        List<List<Map<String, String>>> rows = new ArrayList<>();

        for (TelegramNotificationType type : TelegramNotificationType.values()) {
            boolean enabled = subscriberService.isEnabled(chatId, type);
            String label = (enabled ? "✅ " : "❌ ") + displayName(type);

            rows.add(List.of(Map.of(
                    "text", label,
                    "callback_data", "toggle:" + type.name()
            )));
        }

        return rows;
    }

    private String displayName(TelegramNotificationType type) {
        return switch (type) {
            case SMS_CODE -> "SMS code";
            case CONTACT_REQUESTS -> "Contact requests";
            case ORDERS -> "Orders";
            case STOCK -> "Stock";
            case ERRORS -> "Errors";
        };
    }
}