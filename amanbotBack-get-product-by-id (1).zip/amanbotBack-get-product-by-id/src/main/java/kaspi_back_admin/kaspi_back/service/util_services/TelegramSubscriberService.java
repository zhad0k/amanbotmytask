package kaspi_back_admin.kaspi_back.service.util_services;

import kaspi_back_admin.kaspi_back.db.entities.TelegramSubscriber;
import kaspi_back_admin.kaspi_back.db.entities.TelegramSubscription;
import kaspi_back_admin.kaspi_back.db.enums.TelegramNotificationType;
import kaspi_back_admin.kaspi_back.db.repository.TelegramSubscriberRepository;
import kaspi_back_admin.kaspi_back.db.repository.TelegramSubscriptionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class TelegramSubscriberService {

    private final TelegramSubscriberRepository subscriberRepository;
    private final TelegramSubscriptionRepository subscriptionRepository;

    @Transactional
    public TelegramSubscriber registerOrActivate(
            Long chatId,
            String username,
            String firstName,
            String lastName
    ) {
        return subscriberRepository.findByChatId(chatId).map(existing -> {
            existing.setActive(true);
            existing.setUsername(username);
            existing.setFirstName(firstName);
            existing.setLastName(lastName);
            return subscriberRepository.save(existing);
        }).orElseGet(() -> subscriberRepository.save(
                TelegramSubscriber.builder()
                        .chatId(chatId)
                        .username(username)
                        .firstName(firstName)
                        .lastName(lastName)
                        .isActive(true)
                        .subscribedAt(OffsetDateTime.now())
                        .build()
        ));
    }

    @Transactional
    public boolean toggle(Long chatId, TelegramNotificationType type) {
        TelegramSubscriber subscriber = subscriberRepository.findByChatId(chatId)
                .orElseThrow(() -> new IllegalStateException("Subscriber not found: " + chatId));

        TelegramSubscription subscription = subscriptionRepository
                .findBySubscriberChatIdAndType(chatId, type)
                .orElseGet(() -> TelegramSubscription.builder()
                        .subscriber(subscriber)
                        .type(type)
                        .enabled(false)
                        .build());

        subscription.setEnabled(!subscription.isEnabled());
        subscriptionRepository.save(subscription);

        return subscription.isEnabled();
    }

    public boolean isEnabled(Long chatId, TelegramNotificationType type) {
        return subscriptionRepository.findBySubscriberChatIdAndType(chatId, type)
                .map(TelegramSubscription::isEnabled)
                .orElse(false);
    }

    public List<Long> getSubscribedChatIds(TelegramNotificationType type) {
        return subscriptionRepository
                .findActiveSubscriptionsByType(type)
                .stream()
                .map(s -> s.getSubscriber().getChatId())
                .toList();
    }
}