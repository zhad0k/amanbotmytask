package kaspi_back_admin.kaspi_back.service.impl;

import kaspi_back_admin.kaspi_back.db.entities.CustomerLiteEntity;
import kaspi_back_admin.kaspi_back.db.repository.CustomerLiteEntityRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
public class CustomerLiteEntityService {
    private final CustomerLiteEntityRepository cliRepository;

    public CustomerLiteEntity findCliByPhone(String sender) {
        return cliRepository.findByCellPhone(sender);
    }

    @Transactional
    public void save(CustomerLiteEntity cli) {
        cliRepository.save(cli);
    }
}
