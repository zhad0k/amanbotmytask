package kaspi_back_admin.kaspi_back.service.util_services;


import jakarta.persistence.EntityNotFoundException;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.repository.ModeratorRepository;
import kaspi_back_admin.kaspi_back.dto.request.SignInRequest;
import lombok.AllArgsConstructor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
@AllArgsConstructor
public class ModeratorAuthenticationProvider implements AuthenticationProvider {

    private final ModeratorRepository moderatorRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        SignInRequest signInRequest = (SignInRequest) authentication.getPrincipal();
        Moderator moderator = moderatorRepository.findByPhone(signInRequest.getPhone()).orElseThrow(
                () -> new EntityNotFoundException("Модератор не найдет")
        );
        if (moderator != null && passwordEncoder.matches(signInRequest.getPassword(), moderator.getPassword())) {
            return new UsernamePasswordAuthenticationToken(moderator.getId(), signInRequest.getPassword(), new ArrayList<>());
        } else {
            throw new BadCredentialsException("Неверные учетные данные");
        }
    }


    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
