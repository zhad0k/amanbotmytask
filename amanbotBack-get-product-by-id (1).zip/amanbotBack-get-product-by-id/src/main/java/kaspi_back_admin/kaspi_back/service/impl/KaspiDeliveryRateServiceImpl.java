package kaspi_back_admin.kaspi_back.service.impl;

import kaspi_back_admin.kaspi_back.db.entities.KaspiDeliveryRate;
import kaspi_back_admin.kaspi_back.db.repository.KaspiDeliveryRateRepository;
import kaspi_back_admin.kaspi_back.service.KaspiDeliveryRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@Transactional
@RequiredArgsConstructor
public class KaspiDeliveryRateServiceImpl implements KaspiDeliveryRateService {

    private final KaspiDeliveryRateRepository repository;

    @Override
    @Transactional(readOnly = true)
    public BigDecimal getPrice(
            BigDecimal orderTotal,
            BigDecimal weightKg,
            KaspiDeliveryRate.TireType tireType,
            Zone zone
    ) {
        KaspiDeliveryRate rate;

        if (tireType != KaspiDeliveryRate.TireType.NONE) {
            rate = repository.findByTire(KaspiDeliveryRate.ConditionType.WEIGHT, tireType, weightKg)
                    .orElseThrow(() -> new RuntimeException(
                            "No tire rate for type=%s weight=%.2f".formatted(tireType, weightKg)));
        } else if (orderTotal.compareTo(BigDecimal.valueOf(10_000)) < 0) {
            rate = repository.findByAmount(orderTotal, KaspiDeliveryRate.ConditionType.AMOUNT)
                    .orElseThrow(() -> new RuntimeException(
                            "No amount rate for total=%.2f".formatted(orderTotal)));
        } else {
            rate = repository.findByWeight(
                            weightKg,
                            KaspiDeliveryRate.ConditionType.WEIGHT,
                            KaspiDeliveryRate.TireType.NONE
                    )
                    .orElseThrow(() -> new RuntimeException(
                            "No weight rate for weight=%.2f".formatted(weightKg)));
        }

        return switch (zone) {
            case CITY -> rate.getPriceCity();
            case KZ -> rate.getPriceKz();
            case EXPRESS -> rate.getPriceExpress();
        };
    }
}
