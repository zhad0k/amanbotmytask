package kaspi_back_admin.kaspi_back.service.impl;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.CustomerLiteEntity;
import kaspi_back_admin.kaspi_back.db.entities.Order;
import kaspi_back_admin.kaspi_back.db.enums.OrderState;
import kaspi_back_admin.kaspi_back.db.enums.OrderStatus;
import kaspi_back_admin.kaspi_back.db.repository.OrderRepository;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrdersResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;



    @Transactional
    public Order upsertFromKaspi(Customer customer, KaspiOrdersResponse.DataItem d) {
        var a = d.getAttributes();
        if (a == null) return null;

        Order order = orderRepository.findByKaspiId(d.getId())
                .orElseGet(() -> Order.builder().kaspiId(d.getId()).build());

        order.setCode(a.getCode());
        order.setCustomer(customer);

        order.setTotalPrice(a.getTotalPrice());
        order.setDeliveryCostForSeller(a.getDeliveryCostForSeller());
        order.setIsKaspiDelivery(a.getIsKaspiDelivery());
        order.setPreOrder(a.getPreOrder());
        order.setSignatureRequired(a.getSignatureRequired());
        order.setStatus(safeEnum(OrderStatus.class, a.getStatus()));
        order.setState(safeEnum(OrderState.class, a.getState()));
        order.setDeliveryMode(a.getDeliveryMode());
        order.setPaymentMode(a.getPaymentMode());

        order.setCreationDate(msToOdt(a.getCreationDate()));
        order.setApprovedByBankDate(msToOdt(a.getApprovedByBankDate()));
        order.setPlannedDeliveryDate(msToOdt(a.getPlannedDeliveryDate()));
        order.setReservationDate(msToOdt(a.getReservationDate()));

        if (a.getCustomer() != null) {
            var cl = a.getCustomer();
            CustomerLiteEntity customerLite = order.getCustomerLite();
            if (customerLite == null) {
                customerLite = CustomerLiteEntity.builder()
                        .kaspiCustomerId(cl.getId())
                        .isAllowedToSend(Boolean.TRUE)
                        .isPermissionAsked(Boolean.TRUE)
                        .build();
            }
            customerLite.setName(cl.getName());
            customerLite.setCellPhone(cl.getCellPhone());
            customerLite.setFirstName(cl.getFirstName());
            customerLite.setLastName(cl.getLastName());

            order.setCustomerLite(customerLite);
        }

        if (a.getDeliveryAddress() != null) {
            var da = a.getDeliveryAddress();
            order.setDeliveryStreetName(da.getStreetName());
            order.setDeliveryStreetNumber(da.getStreetNumber());
            order.setDeliveryTown(da.getTown());
            order.setDeliveryDistrict(da.getDistrict());
            order.setDeliveryBuilding(da.getBuilding());
            order.setDeliveryApartment(da.getApartment());
            order.setDeliveryFormattedAddress(da.getFormattedAddress());
            order.setDeliveryLatitude(da.getLatitude());
            order.setDeliveryLongitude(da.getLongitude());
        }

        if (a.getOriginAddress() != null) {
            var oa = a.getOriginAddress();
            order.setOriginPosId(oa.getId());
            order.setOriginPosDisplayName(oa.getDisplayName());
            if (oa.getCity() != null) {
                order.setOriginCityCode(oa.getCity().getCode());
                order.setOriginCityName(oa.getCity().getName());
            }
        }

        if (a.getKaspiDelivery() != null) {
            var kd = a.getKaspiDelivery();
            order.setWaybillUrl(kd.getWaybill());
            order.setWaybillNumber(kd.getWaybillNumber());
            order.setCourierTransmissionDate(msToOdt(kd.getCourierTransmissionDate()));
            order.setCourierTransmissionPlanDate(msToOdt(kd.getCourierTransmissionPlanningDate()));
            order.setKaspiExpress(kd.getExpress());
            order.setReturnedToWarehouse(kd.getReturnedToWarehouse());
        }

        order.setAssembled(a.getAssembled());
        return orderRepository.save(order);
    }

    @Transactional
    public Order upsertFromInoOrders( KaspiOrdersResponse.DataItem d) {
        var a = d.getAttributes();
        if (a == null) return null;

        Order order = orderRepository.findByKaspiId(d.getId())
                .orElseGet(() -> Order.builder().kaspiId(d.getId()).build());
        order.setStatus(safeEnum(OrderStatus.class, a.getStatus()));
        order.setState(safeEnum(OrderState.class, a.getState()));
        return  orderRepository.save(order);
    }

    @Transactional
    public void saveCustomer(Order order){
        orderRepository.save(order);
    }

    public Long countByCustomer(Long customerId, OffsetDateTime from, OffsetDateTime to) {
        return orderRepository.countByCustomerId(customerId, from, to);
    }

    public List<Order> findByCustomer(Customer customer) {
        return orderRepository.findByCustomerId(customer.getId());
    }

    public List<Order> findByCustomerDontDelivered(Customer customer) {
        return orderRepository.findNotArchivedByCustomerId(customer.getId());
    }

    public List<Order> findByCustomerDeliveredCompleted(Customer customer){
        return orderRepository.findArchivedByCustomerId(customer.getId());
    }

    public List<Order> findByCustomerNewOrders(Customer customer){
        return orderRepository.findNewOrdersForNotification(customer.getId());
    }

    private static OffsetDateTime msToOdt(Long ms) {
        if (ms == null) return null;
        return Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toOffsetDateTime();
    }

    private static <E extends Enum<E>> E safeEnum(Class<E> clazz, String raw) {
        if (raw == null) return null;
        try { return Enum.valueOf(clazz, raw); } catch (IllegalArgumentException ex) { return null; }
    }

    public long countAllByCustomerId(Long id) {
        return orderRepository.countAllByCustomerId(id);
    }

    public OffsetDateTime getEarliestOrderDate(Long id) {
        return orderRepository.findEarliestDate(id);
    }
}
