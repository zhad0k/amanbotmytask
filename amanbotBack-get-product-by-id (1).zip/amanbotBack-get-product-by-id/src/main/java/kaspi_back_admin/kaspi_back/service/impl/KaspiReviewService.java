package kaspi_back_admin.kaspi_back.service.impl;


import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.KaspiReview;
import kaspi_back_admin.kaspi_back.db.enums.ReviewStatus;
import kaspi_back_admin.kaspi_back.db.repository.KaspiReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class KaspiReviewService {

    private final KaspiReviewRepository kaspiReviewRepository;


    public long countAllByCustomer(Long customerId) {
        return kaspiReviewRepository.countByCustomer_Id(customerId);
    }


    public long countQueuedByCustomer(Long customerId) {

        return kaspiReviewRepository.countByCustomer_IdAndKaspiStatus(customerId, ReviewStatus.NEW);
    }


    public long countSentByCustomer(Long customerId) {
        return kaspiReviewRepository.countByCustomer_IdAndKaspiStatusIn(
                customerId,
                List.of(ReviewStatus.SENT, ReviewStatus.DELIVERED)
        );
    }

    public Page<KaspiReview> getDeliveredReviewsByCustomer(Customer customer, Pageable pageable) {
        return kaspiReviewRepository.findDeliveredReviewsByCustomer(customer.getId(), pageable);
    }


    public Long countSentByCustomerBetween(Long customerId, OffsetDateTime from, OffsetDateTime to){
        return kaspiReviewRepository.countByCustomerIdAndStatuses(customerId, from, to);
    }

    @Transactional
    public KaspiReview save(KaspiReview kaspiReview){
        return kaspiReviewRepository.save(kaspiReview);
    }


    public Long countByCustomerModeratorId(Long id) {
        return kaspiReviewRepository.countReviewsByCustomerModerator(id);
    }
}
