package kaspi_back_admin.kaspi_back.service.util_services;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class ReceiveToken {

    private final JwtTokenUtil jwtTokenUtil;
    private final JwtService jwtService;


    public Map<String,String> tokenData (){
        HttpServletRequest request = getCurrentHttpRequest();
        if (request == null) {
            return null;
        }
        String token = jwtTokenUtil.extractJwtToken(request);
        if (token == null || token.isBlank()) {
            return null;
        }
        try {
            return jwtService.extractTokenData(token);
        }catch (Exception e) {
            return null;
        }
    }

    public HttpServletRequest getCurrentHttpRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

}
