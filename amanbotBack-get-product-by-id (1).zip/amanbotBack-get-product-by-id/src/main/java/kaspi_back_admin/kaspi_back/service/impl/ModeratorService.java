package kaspi_back_admin.kaspi_back.service.impl;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.repository.ModeratorRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ModeratorService {
    private final ModeratorRepository moderatorRepository;

    public List<String> moderatorPhones(){
        return moderatorRepository.findAllManagerPhone();
    }

    public List<Moderator> findAllModerators() {
        return moderatorRepository.findAllAdmins();
    }

    public Page<Moderator> findAllModeratorsPage(Pageable pageable) {
        return moderatorRepository.findAllAdminsPage(pageable);
    }

    public Moderator findById(Long managerId) {
        return moderatorRepository.findById(managerId).orElseThrow(() ->
                new EntityNotFoundException("Нет такого модератора"));
    }

    public Optional<Moderator> existsByPhone(String phone) {
        return moderatorRepository.findByPhone(phone);
    }

    @Transactional
    public void save(Moderator moderator) {
        moderatorRepository.save(moderator);
    }

    @Transactional
    public void delete(Long moderatorId) {
        moderatorRepository.deleteById(moderatorId);
    }

    public Moderator getReferenceById(Long id) {
        return moderatorRepository.getReferenceById(id);
    }
}
