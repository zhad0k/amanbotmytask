package kaspi_back_admin.kaspi_back.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.UUID;

@Service
public class ImageStorageService {

    @Value("${app.storage.moderator-dir:moderator_images}")
    private String moderatorDir;

    public String storeImage(MultipartFile image) {
        try {
            Path uploadPath = Paths.get(moderatorDir).toAbsolutePath().normalize();
            Files.createDirectories(uploadPath);

            String original = Objects.requireNonNull(image.getOriginalFilename());
            String ext = original.contains(".") ? original.substring(original.lastIndexOf('.')) : "";
            String uniqueName = UUID.randomUUID() + ext;
            Path target = uploadPath.resolve(uniqueName);
            image.transferTo(target.toFile());
            return "/moderator_images/" + uniqueName;
        } catch (IOException e) {
            throw new RuntimeException("Ошибка при сохранении изображения", e);
        }
    }
}
