package kaspi_back_admin.kaspi_back.service.util_services;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.TelegramNotificationType;
import kaspi_back_admin.kaspi_back.dto.request.FeedbackRequest;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class FeedbackNotificationService {

    private final TelegramService telegramService;
    private final TelegramSubscriberService subscriberService;
    private final CustomerService customerService;

    public void sendFeedbackNotification(FeedbackRequest request, Long customerId) {
        List<Long> chatIds = subscriberService.getSubscribedChatIds(TelegramNotificationType.CONTACT_REQUESTS);
        if (chatIds.isEmpty()) {
            log.info("No Telegram subscribers for FEEDBACK notifications");
            return;
        }

        String message = buildMessage(request, customerId);
        for (Long chatId : chatIds) {
            try {
                telegramService.sendMessage(String.valueOf(chatId), message);
            } catch (Exception e) {
                log.error("Failed to send feedback Telegram notification to chatId={}: {}", chatId, e.getMessage());
            }
        }
    }

    private String buildMessage(FeedbackRequest request, Long customerId) {
        if (customerId != null) {
            try {
                Customer customer = customerService.findCustomerById(customerId);
                return String.format(
                        "📩 Новая заявка\n\n👤 Клиент: %s\n📞 Телефон: %s\n💼 Тариф: %s\n💬 Комментарий: %s",
                        customer.getFullName(),
                        customer.getPhone(),
                        orDash(request.getTariff()),
                        orDash(request.getComment())
                );
            } catch (Exception e) {
                log.warn("Customer not found by id={}, using request fields for feedback message", customerId);
            }
        }
        return String.format(
                "📩 Новая заявка\n\n👤 Имя: %s\n📞 Телефон: %s\n💼 Тариф: %s\n💬 Комментарий: %s",
                orDash(request.getName()),
                orDash(request.getPhone()),
                orDash(request.getTariff()),
                orDash(request.getComment())
        );
    }

    private String orDash(String value) {
        return value != null && !value.isBlank() ? value : "—";
    }
}
