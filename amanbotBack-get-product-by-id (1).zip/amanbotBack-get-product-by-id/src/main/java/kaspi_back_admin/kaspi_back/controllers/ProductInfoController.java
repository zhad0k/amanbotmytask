package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import kaspi_back_admin.kaspi_back.dto.response.ProductInfoResponse;
import kaspi_back_admin.kaspi_back.processor.CustomerProcessor;
import kaspi_back_admin.kaspi_back.service.util_services.ReceiveToken;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/products")
@Tag(name = "Product info", description = "Получение товара по id для damping / preorder / inventory")
public class ProductInfoController {

    private final CustomerProcessor customerProcessor;
    private final ReceiveToken receiveToken;

    @GetMapping("/{productId}")
    @Operation(summary = "Получить товар по id")
    public ResponseEntity<ProductInfoResponse> getProductById(
            @PathVariable Long productId
    ) {
        Map<String, String> tokenData = receiveToken.tokenData();
        Long customerId = Long.valueOf(tokenData.get("id"));

        return ResponseEntity.ok(customerProcessor.getProductById(customerId, productId));
    }
}