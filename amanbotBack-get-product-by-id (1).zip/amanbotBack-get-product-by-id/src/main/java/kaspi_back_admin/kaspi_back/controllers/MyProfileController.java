package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import kaspi_back_admin.kaspi_back.controllers.advice.BaseController;
import kaspi_back_admin.kaspi_back.dto.CustomerDto;
import kaspi_back_admin.kaspi_back.dto.request.ChangeCustomerRequest;
import kaspi_back_admin.kaspi_back.dto.request.ChangePasswordRequest;
import kaspi_back_admin.kaspi_back.dto.response.CustomerFeaturesResponse;
import kaspi_back_admin.kaspi_back.processor.MyProfileProcessor;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/profile")
@Tag(name = "Профиль беті! Страница профиля!")
public class MyProfileController extends BaseController {
    private final MyProfileProcessor myProfileProcessor;

    @GetMapping("/get-info")
    @Operation(summary = "Получить данные пользователя")
    public ResponseEntity<CustomerDto> getCustomer() {
        Long id = Long.valueOf(data.get("id"));
        CustomerDto response = myProfileProcessor.getCustomerById(id);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/get-features-info")
    @Operation(summary = "Получить данные доп. функций")
    public ResponseEntity<CustomerFeaturesResponse> getCustomerFeaturesInfo() {
        Long id = Long.valueOf(data.get("id"));
        return ResponseEntity.ok(myProfileProcessor.getCustomerFeatures(id));
    }

    @PostMapping("/change-password")
    @Operation(summary = "Меняeм пароль пользователя на новый")
    public ResponseEntity<Map<String, String>> changePassword(@RequestBody @Valid ChangePasswordRequest request) {
        try {
            Long id = Long.valueOf(data.get("id"));
            var response = myProfileProcessor.changePassword(id, request);
            return ResponseEntity.ok().body(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "неверные данные пользователя"));
        }
    }

    @PutMapping("/update-info")
    @Operation(summary = "Обновить название ИП и привязанного менеджера") // <-- Обновили текст
    public ResponseEntity<Map<String, String>> updateCustomerInfo(@RequestBody @Valid ChangeCustomerRequest changeCustomerRequest) {
        try {
            Long id = Long.valueOf(data.get("id"));
            return ResponseEntity.ok().body(myProfileProcessor.updateCustomer(changeCustomerRequest, id));
        } catch (Exception e) {
            throw new RuntimeException("Не удалось обновить Customer: " + e.getMessage());
        }
    }
}
