package kaspi_back_admin.kaspi_back.controllers;

import kaspi_back_admin.kaspi_back.dto.PeriodDto;
import kaspi_back_admin.kaspi_back.processor.PeriodsProcessor;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/periods")
@AllArgsConstructor
public class PeriodsController {
    private final PeriodsProcessor periodsProcessor;

    @GetMapping("/all")
    public ResponseEntity<List<PeriodDto>> getAllPeriods() {
        return ResponseEntity.ok(periodsProcessor.getPeriods());
    }

}
