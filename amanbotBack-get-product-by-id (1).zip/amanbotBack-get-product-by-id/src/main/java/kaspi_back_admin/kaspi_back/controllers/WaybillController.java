package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.OrderStatus;
import kaspi_back_admin.kaspi_back.dto.WaybillDto;
import kaspi_back_admin.kaspi_back.dto.request.MergeWaybillsRequest;
import kaspi_back_admin.kaspi_back.dto.response.EnumOption;
import kaspi_back_admin.kaspi_back.processor.WaybillProcessor;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/waybills")
public class WaybillController {

    private final WaybillProcessor waybillProcessor;

    @PostMapping
    @Operation(summary = "Обновить заказы")
    public ResponseEntity<String> syncOrders(
            @AuthenticationPrincipal Customer customer) {
        return ResponseEntity.ok(waybillProcessor.syncOrders(customer));
    }

    @GetMapping
    @Operation(summary = "Накладные")
    public ResponseEntity<Page<WaybillDto>> getInvoices(
            @AuthenticationPrincipal Customer customer,
            @RequestParam(required = false) String forSearch,
            @ParameterObject @PageableDefault(sort = "creationDate", direction = Sort.Direction.DESC) Pageable pageable
    ){
        Page<WaybillDto> invoices = waybillProcessor.getAllByCustomerId(customer.getId(), forSearch, pageable);
        return ResponseEntity.ok(invoices);
    }

    @Hidden
    @GetMapping("/{customerId}")
    @Operation(summary = "Накладные")
    public ResponseEntity<Page<WaybillDto>> getInvoices(
            @PathVariable Long customerId,
            @RequestParam(required = false) String forSearch,
            @ParameterObject @PageableDefault(sort = "creationDate", direction = Sort.Direction.DESC) Pageable pageable
    ){
        Page<WaybillDto> invoices = waybillProcessor.getAllByCustomerId(customerId, forSearch, pageable);
        return ResponseEntity.ok(invoices);
    }

    @PostMapping(value = "/merge", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> merge(@AuthenticationPrincipal Customer customer,
                                        @RequestParam(required = false) String forSearch,
                                        @RequestBody(required = false) MergeWaybillsRequest req) {

        long customerId = customer.getId();
        boolean hasSelected =
                req != null && req.orderCodes() != null && !req.orderCodes().isEmpty();
        Integer numberOfSpace = req == null ? null : req.numberOfSpace();

        byte[] pdf = hasSelected
                ? waybillProcessor.mergeWaybillsSelected(customerId, req.orderCodes(), numberOfSpace)
                : waybillProcessor.mergeWaybills(customerId, forSearch, numberOfSpace);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"waybills.pdf\"")
                .header(HttpHeaders.CACHE_CONTROL, "no-store")
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(pdf.length)
                .body(pdf);
    }

    @Hidden
    @PostMapping(value = "/merge/{customerId}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> merge(@PathVariable Long customerId,
                                        @RequestParam(required = false) String forSearch,
                                        @RequestBody(required = false) MergeWaybillsRequest req) {

        boolean hasSelected =
                req != null && req.orderCodes() != null && !req.orderCodes().isEmpty();
        Integer numberOfSpace = req == null ? null : req.numberOfSpace();

        byte[] pdf = hasSelected
                ? waybillProcessor.mergeWaybillsSelected(customerId, req.orderCodes(), numberOfSpace)
                : waybillProcessor.mergeWaybills(customerId, forSearch, numberOfSpace);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"waybills.pdf\"")
                .header(HttpHeaders.CACHE_CONTROL, "no-store")
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(pdf.length)
                .body(pdf);
    }

    @GetMapping("/meta")
    @Operation(summary = "Получить доступные статусы для накладных")
    public ResponseEntity<Map<String, List<EnumOption>>> getWaybillMeta() {

        List<OrderStatus> waybillStatuses = List.of(
                OrderStatus.ASSEMBLE_REQUESTED,
                OrderStatus.WAYBILL_PENDING,
                OrderStatus.WAYBILL_READY,
                OrderStatus.ACCEPTED_BY_MERCHANT
        );

        List<EnumOption> statuses = waybillStatuses.stream()
                .map(s -> new EnumOption(s.name(), s.getName(), s.getNameKz()))
                .toList();

        return ResponseEntity.ok(
                Map.of("statuses", statuses)
        );
    }
}