package kaspi_back_admin.kaspi_back.controllers;


import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import kaspi_back_admin.kaspi_back.dto.request.FeedbackRequest;
import kaspi_back_admin.kaspi_back.processor.FeedbackProcessor;
import kaspi_back_admin.kaspi_back.service.util_services.ReceiveToken;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/feedback")
public class FeedbackController  {
    private final FeedbackProcessor feedbackProcessor;
    private final ReceiveToken receiveToken;

    @Operation(summary = "Отправка информаций клиентов по менеджерам")
    @PostMapping("/send")
    public ResponseEntity<String> sendContactForm(@RequestBody FeedbackRequest request) {
        HttpServletRequest httpServletRequest = receiveToken.getCurrentHttpRequest();
        Long id = null;
        if (httpServletRequest != null && request.getTariff() != null) {
            try {
                Map<String, String> tokenData = receiveToken.tokenData();
                if (tokenData != null && tokenData.get("id") != null) {
                    id = Long.valueOf(tokenData.get("id"));
                }
            } catch (Exception e) {
                id = null;
            }
        }
        feedbackProcessor.sendFeedback(request, id);
        return ResponseEntity.ok("Сообщение успешно отправлено менеджерам");
    }
}
