package kaspi_back_admin.kaspi_back.controllers;

import kaspi_back_admin.kaspi_back.controllers.advice.BaseController;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.dto.KindDto;
import kaspi_back_admin.kaspi_back.dto.TariffDto;
import kaspi_back_admin.kaspi_back.processor.OrderProcessor;
import kaspi_back_admin.kaspi_back.processor.TariffProcessor;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tariffs")
@AllArgsConstructor
public class TariffController extends BaseController {
    private final OrderProcessor orderProcessor;
    private final TariffProcessor tariffProcessor;


    @GetMapping
    public List<TariffDto> getAllTariffs() {
       return Arrays.stream(TariffType.values())
               .map(tariff -> new TariffDto(
                       tariff.name(),
                       tariff.getKind(),
                       tariff.getTier(),
                       tariff.getDisplayName(),
                       tariff.getMonthlyPriceKzt(),
                       null

               ))
               .collect(Collectors.toList());
    }

    @GetMapping("/by-kind")
    public List<TariffDto> getAllTariffsByKind(@RequestParam String kind) {
        String normalized = kind.toUpperCase();
        return Arrays.stream(TariffType.values())
                .filter(tariff -> tariff.getKind().name().equals(normalized))
                .filter(tariff -> tariff != TariffType.NOTIFICATION_FREE)
                .map(tariff -> new TariffDto(
                        tariff.name(),
                        tariff.getKind(),
                        tariff.getTier(),
                        tariff.getDisplayName(),
                        tariff.getMonthlyPriceKzt(),
                        null
                )).collect(Collectors.toList());
    }

    @GetMapping("/kinds")
    public ResponseEntity<List<KindDto>> getAllTariffKinds() {
        String role = data.get("role");
        if (role.equals("ROLE_ADMIN") || role.equals("ROLE_LEAD_ADMIN")) {
            return ResponseEntity.ok().body(Arrays.stream(TariffType.Kind.values())
                    .map(kind -> new KindDto(
                            kind.name(),
                            kind.getDisplayName(),
                            kind.getDescription()
                    ))
                    .toList());
        } else if (role.equals("ROLE_CLIENT")) {
            return ResponseEntity.ok().body(Arrays.stream(TariffType.Kind.values())
                    .filter(kind ->
                            kind != TariffType.Kind.NOTIFICATION_DAMPING &&
                                    kind != TariffType.Kind.DAMPING_NOTIFICATION
                    )
                    .map(kind -> new KindDto(
                            kind.name(),
                            kind.getDisplayName(),
                            kind.getDescription()
                    ))
                    .toList());
        } else{
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
    }

    @GetMapping("/tiers")
    public List<TariffType.ProductTier> getAllProductTiers() {
        return Arrays.asList(TariffType.ProductTier.values());
    }

    @GetMapping("/billing-plans")
    public List<TariffType.BillingPlan> getAllBillingPlans() {
        return Arrays.asList(TariffType.BillingPlan.values());
    }

    @GetMapping("/active/orders")
    public void getActivesyncTodayForAllCustomersPremium() {
        orderProcessor.syncTodayForAllCustomersPremium();
    }

    @GetMapping("/active/status")
    public void getActivesyncForAllCustomersInfoOrders() {
        orderProcessor.syncForAllCustomersInfoOrders();
    }

    @GetMapping("/active/sms-send")
    public void getActivesyncForAllCustomersOrdersDeliveredSend() {
        orderProcessor.syncForAllCustomersOrdersDeliveredSend();
    }

    @GetMapping("/kinds/{kind}/info")
    public ResponseEntity<List<TariffDto>> getTariffsByKind(@PathVariable String kind) {
        return ResponseEntity.ok(tariffProcessor.getTariffsByKind(kind));
    }
}