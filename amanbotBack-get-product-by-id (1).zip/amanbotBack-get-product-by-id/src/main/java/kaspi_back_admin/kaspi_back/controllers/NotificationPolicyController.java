package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import kaspi_back_admin.kaspi_back.db.entities.NotificationPolicy;
import kaspi_back_admin.kaspi_back.dto.request.NotificationPolicyRequest;
import kaspi_back_admin.kaspi_back.processor.NotificationProcessor;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notification-policy")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN', 'LEAD_ADMIN')")
class NotificationPolicyController {
    private final NotificationProcessor processor;

    @Operation(summary = "Список политик")
    @GetMapping
    public Page<NotificationPolicy> get(@ParameterObject @PageableDefault Pageable pageable) {
        return processor.getAll(pageable);
    }

    @Operation(summary = "Получить политику по клиенту")
    @GetMapping("{customerId}")
    public NotificationPolicy getById(@PathVariable Long customerId) {
        return processor.getByCustomerId(customerId);
    }

    @Operation(summary = "Создать политику")
    @PostMapping
    public NotificationPolicy create(@Valid @RequestBody NotificationPolicyRequest request) {
        return processor.create(request);
    }

    @Operation(summary = "Обновить политику")
    @PatchMapping
    public NotificationPolicy update(@Valid @RequestBody NotificationPolicyRequest request) {
        return processor.update(request);
    }

    @Operation(summary = "Включить/выключить политику")
    @PutMapping("{customerId}")
    public void enableOrDisable(@PathVariable Long customerId) {
        processor.toggleEnabled(customerId);
    }

    @Operation(summary = "Удалить политику")
    @DeleteMapping("{customerId}")
    public void delete(@PathVariable Long customerId) {
        processor.delete(customerId);
    }



}