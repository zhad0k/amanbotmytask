package kaspi_back_admin.kaspi_back.controllers.advice;

import jakarta.servlet.http.HttpServletRequest;
import kaspi_back_admin.kaspi_back.service.util_services.JwtService;
import kaspi_back_admin.kaspi_back.service.util_services.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Map;
import java.util.Objects;

public abstract class BaseController {

    @Autowired
    protected JwtService jwtService;

    @Autowired
    protected JwtTokenUtil jwtTokenUtil;

    protected Map<String, String> data;

    private HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
    }

    @ModelAttribute
    public void initData() {
        HttpServletRequest request = getRequest();
        String token = jwtTokenUtil.extractJwtToken(request);
        this.data = jwtService.extractTokenData(token);
    }
}


