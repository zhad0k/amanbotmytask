package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import kaspi_back_admin.kaspi_back.controllers.advice.BaseController;
import kaspi_back_admin.kaspi_back.dto.ReviewDto;
import kaspi_back_admin.kaspi_back.dto.request.ReviewRequest;
import kaspi_back_admin.kaspi_back.processor.ReviewProcessor;
import kaspi_back_admin.kaspi_back.service.impl.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController extends BaseController {
    private final ReviewProcessor reviewProcessor;

    @Operation(summary = "Создание отзыва")
    @PostMapping(value = "/add")
    public ResponseEntity<ReviewDto> addReview(@ModelAttribute @Valid ReviewRequest review) {
        Long id = Long.valueOf(data.get("id"));
        return ResponseEntity.ok(reviewProcessor.addReview(review, id));
    }

    @Operation(summary = "Обновление отзыва")
    @PutMapping(value = "/update" )
    public ResponseEntity<ReviewDto> updateReview(@ModelAttribute @Valid ReviewRequest review) {
        Long id = Long.valueOf(data.get("id"));
        return ResponseEntity.ok(reviewProcessor.updateReview(review, id));
    }

    @Operation(summary = "Получить все отзывы клиента")
    @GetMapping("/my-reviews")
    public ResponseEntity<List<ReviewDto>> getReviewsByCustomerId() {
        Long id = Long.valueOf(data.get("id"));
        return ResponseEntity.ok(reviewProcessor.getReviewsByCustomerId(id));
    }

    @Operation(summary = "Получить все отзывы")
    @GetMapping("/all")
    public ResponseEntity<List<ReviewDto>> getAllReviews() {
        return ResponseEntity.ok(reviewProcessor.getReviews());
    }

    @Operation(summary = "Удалить отзыв")
    @DeleteMapping("/delete/{id}")
    public void deleteReview(@PathVariable Long id) {
        Long customerId = Long.valueOf(data.get("id"));
        reviewProcessor.deleteReview(id, customerId);
    }
}
