package kaspi_back_admin.kaspi_back.controllers;

import jakarta.annotation.PreDestroy;
import kaspi_back_admin.kaspi_back.service.impl.KaspiLoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/kaspi")
@Slf4j
public class KaspiLoginController {

    private final KaspiLoginService loginService;

    public KaspiLoginController(KaspiLoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/login")
    public String login(@RequestParam(defaultValue = "7783485916") String phoneNumber) {
        log.info("Получен запрос на вход для номера: {}", phoneNumber);

        String result = loginService.loginWithPhone(phoneNumber);
        log.info("Результат входа: {}", result);

        return result;
    }

    @GetMapping("/login")
    public String loginWithDefaultNumber() {
        return login("7783485916");
    }

    @PreDestroy
    public void onShutdown() {
        loginService.closeDriver();
        log.debug("WebDriver закрыт");
    }
}

