package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kaspi_back_admin.kaspi_back.dto.response.DeleteInstanceResponse;
import kaspi_back_admin.kaspi_back.dto.response.TariffExpiredCustomerResponse;
import kaspi_back_admin.kaspi_back.processor.GreenApiProcessor;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api")
@PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
@AllArgsConstructor
public class GreenApiController {
    private final GreenApiProcessor greenApiProcessor;
/*
    @PostMapping("/receive-incoming-msg")
    public ResponseEntity<String> receiveMessage(@RequestBody IncomingMessageRequest request) {
        log.info("Receive request from webhook {}",request);
        return ResponseEntity.ok(greenApiProcessor.proceedRequest(request));
    }*/

    @Operation(summary = "Очистить очередь")
    @PostMapping("/clear-queue")
    public ResponseEntity<Void> clearQueue(@RequestParam Long customerId) {
        greenApiProcessor.clearQueue(customerId);

        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Список пользователей")
    @GetMapping("/tariff-expired-customers")
    public ResponseEntity<Page<TariffExpiredCustomerResponse>> getAllCustomers(
            @PageableDefault() Pageable pageable
    ) {
        return ResponseEntity.ok().body(greenApiProcessor.getTariffExpiredCustomers(pageable));
    }

    @Operation(summary = "Убрать пользователя из грин апи")
    @PostMapping("/remove-customer")
    public ResponseEntity<DeleteInstanceResponse> removeCustomerByIdInstance(@RequestParam Long idInstance) {
        return ResponseEntity.ok().body(greenApiProcessor.removeCustomerByIdInstance(idInstance));
    }
}
