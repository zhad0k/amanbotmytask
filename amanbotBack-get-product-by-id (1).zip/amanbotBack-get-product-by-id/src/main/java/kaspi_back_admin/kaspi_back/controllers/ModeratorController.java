package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.enums.CustomerFilter;
import kaspi_back_admin.kaspi_back.dto.CustomerDto;
import kaspi_back_admin.kaspi_back.dto.CustomerDetailsDto;
import kaspi_back_admin.kaspi_back.dto.ModeratorDto;
import kaspi_back_admin.kaspi_back.dto.request.ChangeSubscriptionRequest;
import kaspi_back_admin.kaspi_back.dto.request.CreateCustomerRequest;
import kaspi_back_admin.kaspi_back.dto.request.CustomerUpdateRequest;
import kaspi_back_admin.kaspi_back.dto.request.ModeratorRequest;
import kaspi_back_admin.kaspi_back.processor.ModeratorProcessor;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/moderators")
public class ModeratorController {
    private final ModeratorProcessor moderatorProcessor;

    @Operation(summary = "Получить список клиентов")
    @GetMapping("/customers/get-all")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
    public ResponseEntity<Page<CustomerDto>> getAllCustomers(@RequestParam(required = false) String forSearch,
                                                             @RequestParam(required = false) String tariff,
                                                             @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate dateFrom,
                                                             @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate dateTo,
                                                             @PageableDefault Pageable pageable) {
        return ResponseEntity.ok(
                moderatorProcessor.getAllCustomers(forSearch, tariff, dateFrom, dateTo, pageable)
        );
    }

    @Operation(summary = "Создать клиента")
    @PostMapping("/customers/create")
    @PreAuthorize("hasAnyRole('LEAD_ADMIN','ADMIN')")
    public ResponseEntity<Map<String, String>> createNewCustomer(@AuthenticationPrincipal Moderator moderator,
                                                                 @RequestBody CreateCustomerRequest request) {
            return ResponseEntity.ok().body(moderatorProcessor.createCustomer(moderator.getId(), request));
    }

    @DeleteMapping("/customer/delete")
    @Operation(summary = "Удалить клиента")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN')")
    public ResponseEntity<Map<String, String>> deleteCustomer(@RequestParam Long id) {
        Map<String, String> response = moderatorProcessor.deleteCustomer(id);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Изменить подписку клиента")
    @PostMapping("/customers/edit-subscription")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
    public ResponseEntity<Map<String, String>> changeSubscription(@Valid @RequestBody ChangeSubscriptionRequest request) {
        return ResponseEntity.ok().body(moderatorProcessor.changeSubscription(request));
    }

    @Operation(summary = "Получить менеджеров")
    @GetMapping("/get-managers")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
    public ResponseEntity<List<ModeratorDto>> getAllManagers() {
        return ResponseEntity.ok().body(moderatorProcessor.getAllManagers());
    }

    @Operation(summary = "Получить менеджеров (страница)")
    @GetMapping("/get-managers-page")
    @PreAuthorize("hasAuthority('ROLE_LEAD_ADMIN')")
    public ResponseEntity<Page<ModeratorDto>> getAllManagersPage(@PageableDefault() Pageable pageable) {
        return ResponseEntity.ok().body(moderatorProcessor.getAllManagersPage(pageable));
    }

    @PostMapping("/add-manager")
    @Operation(summary = "Создать менеджера")
    @PreAuthorize("hasAuthority('ROLE_LEAD_ADMIN')")
    public ResponseEntity<Map<String, String>>addManager(@ModelAttribute @Valid ModeratorRequest request) {
        return ResponseEntity.ok(moderatorProcessor.createManager(request));
    }

    @PostMapping("/update")
    @Operation(summary = "Обновить модератора")
    @PreAuthorize("hasAuthority('ROLE_LEAD_ADMIN')")
    public ResponseEntity<Map<String,String>> updateModerator(@ModelAttribute @Valid ModeratorRequest request) {
        Map<String,String> response = moderatorProcessor.updateModerator(request);;
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "Удалить модератора")
    @PreAuthorize("hasAuthority('ROLE_LEAD_ADMIN')")
    public ResponseEntity<Map<String,String>> deleteModerator(@RequestParam Long moderatorId) {
        Map<String,String> response = moderatorProcessor.deleteModerator(moderatorId);
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/set-balance")
    @Operation(summary = "Установить баланс клиенту")
    @PreAuthorize("hasAuthority('ROLE_LEAD_ADMIN')")
    public ResponseEntity<CustomerDto> setBalance (@RequestParam(required = false) Long customerId,
                                                   @RequestParam(required = false) BigDecimal balance) {
        return ResponseEntity.ok().body(moderatorProcessor.setBalance(balance, customerId));
    }

    @Operation(description = "Получение списка клиентов")
    @GetMapping("/clients/{type}")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
    public ResponseEntity<Page<CustomerDetailsDto>> getClientsByTariff(@PathVariable String type,
                                                            @RequestParam(required = false) String forSearch,
                                                            @RequestParam(required = false) Boolean active,
                                                            @RequestParam(required = false) String tariffName,
                                                            @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate endDateFrom,
                                                            @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy")  LocalDate endDateTo, Long managerId,
                                                            @PageableDefault() Pageable pageable) {

        return ResponseEntity.ok().body(moderatorProcessor.getClientsByTariff(type, forSearch,active,tariffName,endDateFrom,endDateTo,managerId,pageable));
    }

    @Operation(description = "Обновление дат у клиента")
    @PostMapping("/clients/{type}/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
    public ResponseEntity<Map<String,String>> updateCustomer(@PathVariable String type,
                                                             @PathVariable Long id,
                                                             @RequestBody CustomerUpdateRequest request) {
        return ResponseEntity.ok().body(moderatorProcessor.updateCustomerByTariff(id, request));
    }

    @Operation(description = "Удаление клиента")
    @DeleteMapping("/clients/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_LEAD_ADMIN','ROLE_ADMIN')")
    public ResponseEntity<Map<String,String>> deleteClient(@PathVariable Long id) {
        return ResponseEntity.ok().body(moderatorProcessor.deleteClient(id));
    }
    @Operation(summary = "Получить список клиентов по статусу с сортировкой")
    @GetMapping({"/filter", "/customers/filter"})
    public ResponseEntity<Page<CustomerDto>> getCustomersByFilter(
            @RequestParam(required = false, defaultValue = "ACTIVE") CustomerFilter filter,
            @RequestParam(required = false) String forSearch,
            @RequestParam(required = false) String dateFrom,
            @RequestParam(required = false) String dateTo,
            @PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable
    ) {
        return ResponseEntity.ok(
                moderatorProcessor.getCustomersByFilter(
                        filter,
                        forSearch,
                        dateFrom,
                        dateTo,
                        pageable
                )
        );
    }

    @Operation(summary = "Получить список клиентов по статусу без query-параметра filter")
    @GetMapping({"/filter/{filter}", "/customers/filter/{filter}"})
    public ResponseEntity<Page<CustomerDto>> getCustomersByPathFilter(
            @PathVariable CustomerFilter filter,
            @RequestParam(required = false) String forSearch,
            @RequestParam(required = false) String dateFrom,
            @RequestParam(required = false) String dateTo,
            @PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable
    ) {
        return ResponseEntity.ok(
                moderatorProcessor.getCustomersByFilter(
                        filter,
                        forSearch,
                        dateFrom,
                        dateTo,
                        pageable
                )
        );
    }
}
