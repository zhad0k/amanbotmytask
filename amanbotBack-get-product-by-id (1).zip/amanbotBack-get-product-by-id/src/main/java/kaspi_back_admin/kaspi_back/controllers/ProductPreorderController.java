package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction;
import kaspi_back_admin.kaspi_back.db.enums.PreorderFilterType;
import kaspi_back_admin.kaspi_back.db.enums.PreorderSortType;
import kaspi_back_admin.kaspi_back.dto.PointDto;
import kaspi_back_admin.kaspi_back.dto.PreorderDto;
import kaspi_back_admin.kaspi_back.dto.response.EnumOption;
import kaspi_back_admin.kaspi_back.processor.ProductPreorderProcessor;
import kaspi_back_admin.kaspi_back.service.util_services.ReceiveToken;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/preorders")
@Tag(name = "Product Preorder", description = "CRUD и операции над предзаказами товаров")
public class ProductPreorderController {

    private final ProductPreorderProcessor preorderProcessor;
    private final ReceiveToken receiveToken;

    @GetMapping
    @Operation(summary = "Получить все записи предзаказов")
    public ResponseEntity<List<PreorderDto>> findAll() {
        return ResponseEntity.ok(preorderProcessor.findAll());
    }

    @GetMapping("/product/{productId}")
    @Operation(summary = "Получить предзаказ по productId")
    public ResponseEntity<List<PreorderDto>> getByProduct(@PathVariable Long productId) {
        return ResponseEntity.ok(preorderProcessor.getByProduct(productId));
    }

    @GetMapping("/customer")
    @Operation(summary = "Получить список предзаказов текущего клиента")
    public ResponseEntity<Page<PreorderDto>> getByCustomer(
            @RequestParam(required = false) String forSearch,
            @RequestParam(required = false) PreorderSortType sortType,
            @RequestParam(required = false) PreorderFilterType filterType,
            @ParameterObject @PageableDefault Pageable pageable
    ) {
        Map<String, String> tokenData = receiveToken.tokenData();
        Long id = Long.valueOf(tokenData.get("id"));
        return ResponseEntity.ok(preorderProcessor.findByCustomer(id, forSearch, pageable, sortType, filterType));
    }

    @Hidden
    @GetMapping("/customer/{customerId}")
    @Operation(summary = "Получить список предзаказов текущего клиента по id")
    public ResponseEntity<Page<PreorderDto>> getByCustomerId(
            @PathVariable Long customerId,
            @RequestParam(required = false) String forSearch,
            @RequestParam(required = false) PreorderSortType sortType,
            @RequestParam(required = false) PreorderFilterType filterType,
            @ParameterObject @PageableDefault Pageable pageable
    ) {
        return ResponseEntity.ok(preorderProcessor.findByCustomer(customerId, forSearch, pageable, sortType, filterType));
    }

    @PostMapping
    @Operation(summary = "Создать запись предзаказа")
    public ResponseEntity<PreorderDto> create(
            @RequestParam Long productId,
            @Valid @RequestBody List<PointDto> points
    ) {
        return ResponseEntity.ok(preorderProcessor.create(productId, points));
    }

    @PutMapping
    @Operation(summary = "Обновить запись предзаказа")
    public ResponseEntity<PreorderDto> update(
            @RequestParam Long productId,
            @RequestBody List<PointDto> points
    ) {
        return ResponseEntity.ok(preorderProcessor.update(productId, points));
    }

    @DeleteMapping
    @Operation(summary = "Удалить запись предзаказа")
    public ResponseEntity<Map<String, String>> delete(
            @RequestParam Long productId
    ) {
        return ResponseEntity.ok().body(preorderProcessor.delete(productId));
    }

    @PostMapping("/customer/sync-external")
    @Operation(summary = "Инициировать запрос обновления для текущего клиента")
    public ResponseEntity<String> syncExternalForCurrentCustomer() {
        Map<String, String> tokenData = receiveToken.tokenData();
        Long customerId = Long.valueOf(tokenData.get("id"));
        String result = preorderProcessor.syncWithExternalService(customerId);

        return ResponseEntity.ok(result);
    }

    @GetMapping("/meta/filters")
    @Operation(summary = "Получить доступные фильтры и сортировки для предзаказов")
    public ResponseEntity<Map<String, List<EnumOption>>> getPreorderMeta() {
        List<EnumOption> filters = Arrays.stream(PreorderFilterType.values())
                .map(e -> new EnumOption(e.name(), e.getName(), e.getNameKz()))
                .toList();

        List<EnumOption> sorts = Arrays.stream(PreorderSortType.values())
                .map(e -> new EnumOption(e.name(), e.getName(), e.getNameKz()))
                .toList();

        Map<String, List<EnumOption>> body = Map.of(
                "filters", filters,
                "sorts", sorts
        );

        return ResponseEntity.ok(body);
    }

    @GetMapping("/meta")
    @Operation(summary = "Получить список действий при минимальном остатке")
    public ResponseEntity<List<EnumOption>> getMinimalStockActions() {

        List<EnumOption> actions = Arrays.stream(MinimalStockAction.values())
                .map(a -> new EnumOption(a.name(), a.getTitle(), a.getTitleKz()))
                .toList();

        return ResponseEntity.ok(actions);
    }
}