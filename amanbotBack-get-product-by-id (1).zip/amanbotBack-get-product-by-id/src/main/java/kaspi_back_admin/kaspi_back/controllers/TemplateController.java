package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import kaspi_back_admin.kaspi_back.dto.ModeratorTemplateDto;
import kaspi_back_admin.kaspi_back.dto.TemplateDto;
import kaspi_back_admin.kaspi_back.dto.TemplateVarDto;
import kaspi_back_admin.kaspi_back.dto.TypeDto;
import kaspi_back_admin.kaspi_back.dto.request.AddTemplateRequest;
import kaspi_back_admin.kaspi_back.processor.TemplateProcessor;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/template")
@AllArgsConstructor
public class TemplateController {
    private final TemplateProcessor templateProcessor;

    @GetMapping("/message-types")
    @Operation(summary = "Получения типов отправляемых сообщений")
    public ResponseEntity<List<TypeDto>> getTemplateVars() {
        List<TypeDto> types = Arrays.stream(SyncType.values())
                .map(x -> new TypeDto(x.ordinal(), x.name()))
                .toList();

        return ResponseEntity.ok(types);
    }

    @GetMapping("/message-types/variables")
    @Operation(summary = "Получения переменных для вставки в шаблон сообщения")
    public List<TemplateVarDto> getTemplateVars(@RequestParam String type) {
        return templateProcessor.getTemplateVars(type);
    }

    @PostMapping()
    @Operation(summary = "Добавление шаблона с перемнными")
    @PreAuthorize("hasRole('CLIENT')")
    public ResponseEntity<Map<String,String>> addTemplate(
            @AuthenticationPrincipal Customer customer,
            @RequestBody AddTemplateRequest request
    ) {
        Map<String,String> data = templateProcessor.addTemplate(customer.getId(), request);
        return ResponseEntity.ok(data);
    }

    @GetMapping
    @Operation(summary = "Получение шаблонов")
    @PreAuthorize("hasRole('CLIENT')")
    public ResponseEntity<List<TemplateDto>> getTemplates(
            @AuthenticationPrincipal Customer customer
    ) {
        return ResponseEntity.ok(templateProcessor.getTemplates(customer.getId()));
    }

    @GetMapping("/moderator")
    @Operation(
            summary = "Получение шаблонов для текущего модератора",
            description = "Возвращает шаблоны для событий NEW_ORDER и DELIVERED_COMPLETED," +
                    " а также информацию по модератору."
    )
    @PreAuthorize("hasAnyRole('ADMIN','LEAD_ADMIN')")
    public ResponseEntity<ModeratorTemplateDto> getTemplatesFoModerators(
            @AuthenticationPrincipal Moderator moderator
    ) {
        return ResponseEntity.ok(templateProcessor.getTemplatesForModerators(moderator.getId()));
    }

    @DeleteMapping("/moderator/{id}")
    @Operation(
            summary = "Удаление общих шаблонов",
            description = "Удаляет шаблоны которые отпраляются рандомно"
    )
    @PreAuthorize("hasAnyRole('ADMIN','LEAD_ADMIN')")
    public ResponseEntity<Map<String,String>> deleteTemplate(
            @PathVariable(value = "id") Long templateId
    ) {
        return ResponseEntity.ok(templateProcessor.deleteTemplate(templateId));
    }

    @PostMapping("/moderator/{id}")
    @Operation(summary = "Редактирование шаблона с перемнными")
    @PreAuthorize("hasAnyRole('ADMIN','LEAD_ADMIN')")
    public ResponseEntity<Map<String,String>> updateTemplateModerator(
            @PathVariable(value = "id") Long templateId,
            @RequestBody AddTemplateRequest request
    ) {
        Map<String,String> data = templateProcessor.updateTemplateModerator(templateId,request);
        return ResponseEntity.ok(data);
    }

    @PostMapping("/moderator")
    @Operation(summary = "Добавление шаблона с перемнными")
    @PreAuthorize("hasAnyRole('ADMIN','LEAD_ADMIN')")
    public ResponseEntity<Map<String,String>> addTemplateModerator(
            @RequestBody AddTemplateRequest request
    ) {
        Map<String,String> data = templateProcessor.addTemplateModerator(request);
        return ResponseEntity.ok(data);
    }

    @Operation(summary = "Отключить один вид сообщения")
    @PostMapping("/disable")
    public ResponseEntity<?> disableMessageTemplate(
            @AuthenticationPrincipal Customer customer,
            @RequestParam String type,
            @RequestParam boolean disable
    ) {
        templateProcessor.changeMode(customer,type,disable);
        return ResponseEntity.ok().build();
    }

}
