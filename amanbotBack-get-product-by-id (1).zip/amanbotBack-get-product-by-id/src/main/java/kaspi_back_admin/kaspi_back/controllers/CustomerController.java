package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.dto.ProductDto;
import kaspi_back_admin.kaspi_back.dto.ProductInfoDto;
import kaspi_back_admin.kaspi_back.dto.StatisticsDto;
import kaspi_back_admin.kaspi_back.dto.request.ProductRevenueRequest;
import kaspi_back_admin.kaspi_back.dto.request.UpdatePriceGlobalCustomerRequest;
import kaspi_back_admin.kaspi_back.dto.request.UpdateProductRequest;
import kaspi_back_admin.kaspi_back.dto.response.CustomerProductInfoResponse;
import kaspi_back_admin.kaspi_back.dto.response.CustomerProductStatistics;
import kaspi_back_admin.kaspi_back.dto.response.ProductRevenueResponse;
import kaspi_back_admin.kaspi_back.processor.CustomerProcessor;
import kaspi_back_admin.kaspi_back.processor.ProductRevenueProcessor;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/customer")
@AllArgsConstructor
public class CustomerController {
    private final CustomerProcessor customerProcessor;
    private final ProductRevenueProcessor productRevenueProcessor;

    @GetMapping("/products/stat")
    @Operation(summary = "Общая информация по damping боту")
    public ResponseEntity<ProductInfoDto> getCustomerProductsInfo(
            @AuthenticationPrincipal Customer customer
    ) {
        return ResponseEntity.ok(customerProcessor.getCustomerProductsInfo(customer));
    }

    @GetMapping("/products")
    @Operation(summary = "Список продуктов для damping page")
    public ResponseEntity<Page<ProductDto>> getCustomerProducts(
            @AuthenticationPrincipal Customer customer,
            @RequestParam(required = false) String forSearch,
            @RequestParam(required = false) Boolean active,
            @RequestParam(required = false) Boolean dampingActive,
            @PageableDefault() Pageable pageable
    )
    {
        Sort sort = pageable.getSort().isUnsorted()
                ? Sort.by(Sort.Direction.ASC, "title")
                : pageable.getSort();
        Pageable pageable1 = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
        return ResponseEntity.ok(customerProcessor.getCustomerProducts(customer, forSearch, active, dampingActive, pageable1));
    }

    @PutMapping("/products/{productId:\\d+}/availability")
    @Operation(summary = "Поменять статус damping товара")
    public ResponseEntity<Map<String,String>> changeAvailability(
            @AuthenticationPrincipal Customer customer,
            @PathVariable Long productId,
            @RequestParam Boolean isAvailable
    ) {
        Map<String,String> response = customerProcessor.changeAvailability(customer, productId, isAvailable);
        return ResponseEntity.ok(response);
    }
    @PutMapping("/products/mass-availability")
    @Operation(summary = "Массовое переключение доступности (priceAutoChange) всех товаров клиента")
    public ResponseEntity<Map<String, String>> toggleMassAvailability(
            @AuthenticationPrincipal Customer customer
    ) {
        Map<String, String> response = customerProcessor.toggleMassAvailability(customer);
        return ResponseEntity.ok(response);
    }
    @GetMapping("/products/availability")
    @Operation(summary = "Получить статус массового управления автоизменением цен")
    public ResponseEntity<Boolean> getMassAvailability(
            @AuthenticationPrincipal Customer customer
    ) {
        boolean isEnabled = customerProcessor.isMassAvailabilityEnabled(customer);

        return ResponseEntity.ok(isEnabled);
    }
    @PatchMapping("/products/update-price")
    @Operation(summary = "Массовое изменение цен для выбранных товаров")
    public ResponseEntity<Map<String, Object>> updatePrice(
            @AuthenticationPrincipal Customer customer,
            @RequestBody @NotNull @Valid UpdatePriceGlobalCustomerRequest request
    ) {
        long updated = customerProcessor.updatePriceGlobal(customer, request);
        return ResponseEntity.ok(Map.of("updatedCount", updated));
    }

    @PutMapping("/products/{productId:\\d+}/update")
    @Operation(summary = "Обновление товара (пока только цена)")
    public ResponseEntity<Void> updatePrice(
            @AuthenticationPrincipal Customer customer,
            @PathVariable Long productId,
            @RequestBody @NotNull UpdateProductRequest request
    ) {
        customerProcessor.updatePrice(customer, productId, request);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/products/{productId:\\d+}")
    @Operation(summary = "Удаление товара со страницы damping")
    public ResponseEntity<Void> deleteProduct(
            @AuthenticationPrincipal Customer customer,
            @PathVariable Long productId
    ) {
        customerProcessor.deleteProduct(customer, productId);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/statistics")
    @Operation(summary = "Статистика продуктов клиента")
    public ResponseEntity<Page<StatisticsDto>> getStatistics(
            @AuthenticationPrincipal Customer customer,
            @RequestParam(required = false, defaultValue = "") String forSearch,
            @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate toDate,
            @RequestParam(defaultValue = "true") boolean available,
            @ParameterObject @PageableDefault() Pageable pageable
    ) {
        log.info(customer.toString());
        Page<StatisticsDto> response = customerProcessor.getStatistics(customer, fromDate,
                toDate, forSearch, available, pageable);
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("{id:\\d+}")
    @Operation(summary = "Удалить аккаунт клиента")
    public ResponseEntity<Void> deleteCustomerAccount(@PathVariable Long id) {
        customerProcessor.deleteCustomerAccount(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/products/{id:\\d+}")
    @Operation(summary = "Получить товар по id")
    public ResponseEntity<CustomerProductInfoResponse> getProduct(
            @AuthenticationPrincipal Customer customer,
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(customerProcessor.getCustomerProductInfo(customer, id));
    }

    @GetMapping("/products/{id:\\d+}/statistics")
    @Operation(summary = "Получить статистику для товара по id")
    public ResponseEntity<CustomerProductStatistics> getProductStatistics(@AuthenticationPrincipal Customer customer,
                                                                                @PathVariable Long id,
                                                                                @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate fromDate,
                                                                                @RequestParam(required = false) @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate toDate,
                                                                          @RequestParam String type) {
        return ResponseEntity.ok(customerProcessor.getCustomerProductStatistics(customer, id, fromDate, toDate, type));
    }

    @PostMapping("/products/calculator")
    @Operation(summary = "Посчитать прибыль по параметрам товара")
    public ResponseEntity<ProductRevenueResponse> calculateRevenue(@RequestBody ProductRevenueRequest request) {
        return ResponseEntity.ok(productRevenueProcessor.calculate(request));
    }

}
