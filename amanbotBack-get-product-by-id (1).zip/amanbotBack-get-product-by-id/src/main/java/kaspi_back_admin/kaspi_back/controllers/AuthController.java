package kaspi_back_admin.kaspi_back.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import kaspi_back_admin.kaspi_back.dto.response.JwtAuthenticationResponse;
import kaspi_back_admin.kaspi_back.dto.request.SignInRequest;
import kaspi_back_admin.kaspi_back.dto.request.SignUpRequest;
import kaspi_back_admin.kaspi_back.service.CustomerCreateService;
import kaspi_back_admin.kaspi_back.service.util_services.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.util.Pair;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/amanbot")
@RequiredArgsConstructor
@Tag(name = "Аутентификация")
public class AuthController {
    private final AuthenticationService authenticationService;
    private final CustomerCreateService customerCreateServices;

    @Operation(summary = "Регистрация пользователя")
    @PostMapping("/sign-up")
    public JwtAuthenticationResponse signUp(@RequestBody @Valid SignUpRequest request) {
        return authenticationService.signUp(request);
    }

    @Operation(summary = "Авторизация пользователя")
    @PostMapping("/sign-in")
    public JwtAuthenticationResponse signIn(@RequestBody @Valid SignInRequest request) {
        return authenticationService.signIn(request);
    }


    @Operation(summary = "Забыли пароль")
    @PostMapping("/forgot-password")
    public ResponseEntity<Pair<String, Long>> forgotYourPassword(@RequestBody @Valid SignUpRequest request) throws Exception {
        return ResponseEntity.ok(customerCreateServices.passwordRecovery(request));
    }

    @Operation(summary = "Авторизация модератор")
    @PostMapping("/moderator/sign-in")
    public JwtAuthenticationResponse signInModerator(@RequestBody @Valid SignInRequest request) {
        return authenticationService.signInModerator(request);
    }

}
