package kaspi_back_admin.kaspi_back.controllers;


import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.constraints.Pattern;
import kaspi_back_admin.kaspi_back.dto.CompanyTemplatesSummaryDto;
import kaspi_back_admin.kaspi_back.dto.KaspiReviewDto;
import kaspi_back_admin.kaspi_back.dto.KaspiReviewStaticticsDto;
import kaspi_back_admin.kaspi_back.dto.TemplatesExampleDto;
import kaspi_back_admin.kaspi_back.processor.CustomReviewProcessor;
import kaspi_back_admin.kaspi_back.processor.CustomerCardProcessor;
import kaspi_back_admin.kaspi_back.service.util_services.ReceiveToken;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/kaspi/reviews")
@RequiredArgsConstructor
public class KaspiReviewsController  {

    private final CustomerCardProcessor customerCardProcessor;
    private final ReceiveToken receiveToken;
    private final CustomReviewProcessor customReviewProcessor;

    @Operation(summary = "Общая информация по клиенту по боту ")
    @GetMapping("/templates/summary")
    public ResponseEntity<CompanyTemplatesSummaryDto> getSummary() {
        Map<String,String> data = receiveToken.tokenData();
        Long id = Long.valueOf(data.get("id"));
        CompanyTemplatesSummaryDto dto = customerCardProcessor.buildCard(id);
        return ResponseEntity.ok(dto);
    }

    @Operation(summary = "Получить список по отзыву")
    @GetMapping("/history")
    public Page<KaspiReviewDto> getDeliveredReviews(Pageable pageable) {
        Map<String,String> data = receiveToken.tokenData();
        Long id = Long.valueOf(data.get("id"));
        return customerCardProcessor.getDeliveredReviewsByCustomer(id, pageable);
    }

    @Operation(summary = "Шаблон смс сообщений")
    @GetMapping("/templates")
    public TemplatesExampleDto getTemplates() {
        return customerCardProcessor.buildTemplates();
    }

    @PostMapping("/custom/add")
    public Map<String, String> addCustomReviewMessage(@RequestParam String message) {
        Map<String,String> data = receiveToken.tokenData();
        Long id = Long.valueOf(data.get("id"));
        return customReviewProcessor.addKaspiMessageReview(id, message);
    }

    @GetMapping("/custom")
    public Map<String, String> getCustomReviewMessage() {
        Map<String,String> data = receiveToken.tokenData();
        Long id = Long.valueOf(data.get("id"));
        return customReviewProcessor.getKaspiMessageReview(id);
    }

    @DeleteMapping("/custom/remove")
    public Map<String, String> removeCustomReviewMessage() {
        Map<String,String> data = receiveToken.tokenData();
        Long id = Long.valueOf(data.get("id"));
        return customReviewProcessor.removeKaspiMessageReview(id);
    }


    @Operation(summary = "Статистика по отзывам")
    @GetMapping("/statistics")
    public ResponseEntity<List<KaspiReviewStaticticsDto>> getStatistics(
            @Pattern(regexp = "^(0[1-9]|1[0-2])$",
                    message = "month должен быть в формате MM")
            @RequestParam(required = false) String month,
            @Pattern(regexp = "^(0[1-9]|[12][0-9]|3[01])\\.(0[1-9]|1[0-2])\\.\\d{4}-(0[1-9]|[12][0-9]|3[01])\\.(0[1-9]|1[0-2])\\.\\d{4}$",
                    message = "range должен быть в формате dd.MM.yyyy-dd.MM.yyyy")
            @RequestParam(required = false) String range) {
        Map<String,String> data = receiveToken.tokenData();
        Long id = Long.valueOf(data.get("id"));
        return ResponseEntity.ok(customerCardProcessor.buildStatistics(id, month, range));
    }
}
