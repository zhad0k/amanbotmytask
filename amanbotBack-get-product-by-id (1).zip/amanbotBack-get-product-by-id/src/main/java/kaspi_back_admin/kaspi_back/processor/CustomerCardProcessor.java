package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.KaspiReview;
import kaspi_back_admin.kaspi_back.db.enums.ReviewTemplate;
import kaspi_back_admin.kaspi_back.dto.CompanyTemplatesSummaryDto;
import kaspi_back_admin.kaspi_back.dto.KaspiReviewDto;
import kaspi_back_admin.kaspi_back.dto.KaspiReviewStaticticsDto;
import kaspi_back_admin.kaspi_back.dto.TemplatesExampleDto;
import kaspi_back_admin.kaspi_back.mapper.KaspiRewiesMapper;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.KaspiReviewService;
import kaspi_back_admin.kaspi_back.service.impl.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerCardProcessor {

    private final CustomerService customerService;
    private final KaspiReviewService kaspiReviewService;
    private final KaspiRewiesMapper kaspiRewiesMapper;

    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");
    private static final DateTimeFormatter DMY_FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private final OrderService orderService;


    public CompanyTemplatesSummaryDto buildCard(Long customerId) {

        Customer customer = customerService.findCustomerById(customerId);


        List<String> statusText = isTariffActive(customer) ? List.of("Активный", "Белсенді") : List.of("Неактивный", "Белсенді емес");


        long sent = kaspiReviewService.countSentByCustomer(customer.getId());
        long queued = kaspiReviewService.countQueuedByCustomer(customer.getId());
        long orderCount = orderService.countAllByCustomerId(customer.getId());


        return CompanyTemplatesSummaryDto.builder()
                .companyName(pickCompanyName(customer))
                .addedAt(getAddedAt(customer))
                .status(statusText)
                .sentCount(sent)
                .queuedCount(queued)
                .orderCount(orderCount)
                .build();
    }

    public Page<KaspiReviewDto> getDeliveredReviewsByCustomer(Long customerId, Pageable pageable) {
        Customer customer = customerService.findCustomerById(customerId);
        Page<KaspiReview> kaspiReviews = kaspiReviewService.getDeliveredReviewsByCustomer(customer,pageable);
        return kaspiReviews.map(kaspiReview -> kaspiRewiesMapper.fromEntity(kaspiReview, kaspiReview.getOrder().getCustomerLite().getCellPhone()));
    }

    public TemplatesExampleDto buildTemplates(){
        String templateRu = ReviewTemplate.START_RU.getText() + " " +
                "{Имя клиента} " + " " +
                ReviewTemplate.ORDER_INFO_RU.getText() + " " +
                "{XXXXXXX} " + " " +
                ReviewTemplate.CONTACT_RU.getText();
        String templateKz = ReviewTemplate.START_KZ.getText() + " " +
                "{Клиенттің аты} " + " " +
                ReviewTemplate.PRODUCT_LINK_RU.getText() + " " +
                "{XXXXXXX} " + " " +
                ReviewTemplate.CONTACT_KZ.getText();
        TemplatesExampleDto templatesExampleDto = new TemplatesExampleDto();
        templatesExampleDto.setTemplateRu(templateRu);
        templatesExampleDto.setTemplateKz(templateKz);
        return templatesExampleDto;
    }

    public List<KaspiReviewStaticticsDto> buildStatistics(Long customerId,
                                                          String month,
                                                          String range) {
        if (month != null && !month.isBlank()) {
            return buildMonthlyStatistics(customerId, month);
        }
        return buildRangeStatistics(customerId, range);
    }

    private List<KaspiReviewStaticticsDto> buildMonthlyStatistics(Long customerId, String month) {
        YearMonth ym = YearMonth.of(Year.now(KZ).getValue(), Integer.parseInt(month));
        LocalDate start = ym.atDay(1);
        LocalDate end = ym.atEndOfMonth();

        LocalDate firstMonday = start.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));

        List<KaspiReviewStaticticsDto> rows = new ArrayList<>();
        for (LocalDate ws = firstMonday; !ws.isAfter(end); ws = ws.plusWeeks(1)) {
            LocalDate we = ws.plusDays(6);
            LocalDate ds = ws.isBefore(start) ? start : ws;
            LocalDate de = we.isAfter(end) ? end : we;

            rows.add(buildStatisticsDto(customerId, ds, de));
        }
        return rows;
    }

    private List<KaspiReviewStaticticsDto> buildRangeStatistics(Long customerId, String range) {
        final LocalDate start;
        final LocalDate end;

        if (range != null && !range.isBlank()) {
            String[] parts = range.split("-", 2);
            start = LocalDate.parse(parts[0].trim(), DMY_FMT);
            end = LocalDate.parse(parts[1].trim(), DMY_FMT);
        } else {
            start = customerService.findCustomerById(customerId)
                    .getCreatedDate()
                    .atZoneSameInstant(KZ)
                    .toLocalDate();
            end = LocalDate.now(KZ);
        }

        return List.of(buildStatisticsDto(customerId, start, end));
    }

    private KaspiReviewStaticticsDto buildStatisticsDto(Long customerId, LocalDate startDate, LocalDate endDate) {
        OffsetDateTime from = startOfDayKZ(startDate);
        OffsetDateTime to = endOfDayKZ(endDate);

        return KaspiReviewStaticticsDto.builder()
                .dateStart(startDate)
                .dateFinish(endDate)
                .countOrders(orderService.countByCustomer(customerId, from, to))
                .countSmsSent(kaspiReviewService.countSentByCustomerBetween(customerId, from, to))
                .countClicks(0L)
                .conversion(BigDecimal.ZERO)
                .build();
    }

    private boolean isTariffActive(Customer c) {
        OffsetDateTime end = getTariffEnd(c);
        if (end == null) return false;
        LocalDate todayKz = LocalDate.now(KZ);
        LocalDate endDateKz = end.atZoneSameInstant(KZ).toLocalDate();
        return !endDateKz.isBefore(todayKz); // endDate >= today
    }

    private OffsetDateTime getTariffEnd(Customer c) {
        return c.getTariffEndAt();
    }

    private OffsetDateTime getAddedAt(Customer c) {
        return c.getTariffStartAt();
    }

    private String pickCompanyName(Customer c) {
        if (c.getIpName() != null && !c.getIpName().isBlank()) return c.getIpName();
        if (c.getFullName() != null && !c.getFullName().isBlank()) return c.getFullName();
        return c.getUsername();
    }

    private static OffsetDateTime startOfDayKZ(LocalDate d) {
        return d.atStartOfDay(KZ).toOffsetDateTime();
    }

    private static OffsetDateTime endOfDayKZ(LocalDate d) {
        return d.atTime(LocalTime.MAX).atZone(KZ).toOffsetDateTime();
    }
}
