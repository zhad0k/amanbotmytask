package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Period;
import kaspi_back_admin.kaspi_back.dto.PeriodDto;
import kaspi_back_admin.kaspi_back.service.impl.PeriodService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@AllArgsConstructor
public class PeriodsProcessor {
    private final PeriodService periodService;

    public List<PeriodDto> getPeriods() {
        List<Period> all = periodService.getAll();
        return all.stream().map(period -> {
            PeriodDto periodDto = new PeriodDto();
            periodDto.setId(period.getId());
            periodDto.setName(period.getName());
            return periodDto;
        }).toList();
    }

}
