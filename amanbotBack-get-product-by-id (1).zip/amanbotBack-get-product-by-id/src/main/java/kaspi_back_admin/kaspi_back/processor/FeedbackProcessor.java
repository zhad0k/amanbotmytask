package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.dto.request.FeedbackRequest;
import kaspi_back_admin.kaspi_back.service.util_services.FeedbackNotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class FeedbackProcessor {

    private final FeedbackNotificationService feedbackNotificationService;

    public void sendFeedback(FeedbackRequest request, Long customerId) {
        try {
            feedbackNotificationService.sendFeedbackNotification(request, customerId);
        } catch (Exception e) {
            log.error("Failed to send feedback Telegram notification: {}", e.getMessage());
        }
    }
}
