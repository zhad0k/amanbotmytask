package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.api.GreenApi;
import kaspi_back_admin.kaspi_back.api.KaspiClient;
import kaspi_back_admin.kaspi_back.db.entities.*;
import kaspi_back_admin.kaspi_back.db.enums.ReviewStatus;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import kaspi_back_admin.kaspi_back.dto.response.GreenApiInstanceResponse;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrderEntriesResponse;
import kaspi_back_admin.kaspi_back.dto.response.KaspiOrdersResponse;
import kaspi_back_admin.kaspi_back.service.impl.*;
import kaspi_back_admin.kaspi_back.service.impl.NotificationService;
import kaspi_back_admin.kaspi_back.service.util_services.SmsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static kaspi_back_admin.kaspi_back.service.util_services.DefaultMessagesUtil.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class KaspiReviewsApiProcessor {

    private final KaspiClient kaspiClient;
    private final OrderService orderService;
    private final OrderEntryService orderEntryService;
    private final SmsService smsService;
    private final KaspiReviewService kaspiReviewService;
    private final GreenApi greenApi;
    private final CustomerService customerService;
    private final TemplateService templateService;
    private final CustomerLiteEntityService cliService;

    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");
    private final NotificationService notificationWindowService;

    @Value("${app.kaspi.reviewBaseUrl}")
    private String reviewBaseUrl;

    public void syncForCustomerForPeriod(Customer customer){
        String token = customer.getTokenProd();
        LocalDate date = LocalDate.now(KZ);
        long ge = date.atStartOfDay(KZ).toInstant().toEpochMilli();
        long le = date.atTime(23, 59, 59, 999_000_000)
                .atZone(KZ)
                .toInstant()
                .toEpochMilli();

        int page = 0;
        int pageSize = 50;
        boolean keep = true;

        while (keep) {
            String query = buildQuery(ge, le, pageSize);
            KaspiOrdersResponse resp = null;
            try {
                resp = kaspiClient.getOrders(token, query);
            } catch (Exception e) {
                log.warn("Kaspi getOrders failed: {}", e.getMessage());
            }

            if (resp == null || resp.getData() == null || resp.getData().isEmpty()) {
                keep = false;
                continue;
            }

            for (var d : resp.getData()) {
                Order order = orderService.upsertFromKaspi(customer, d);
                KaspiOrderEntriesResponse entries = null;
                try {
                    entries = kaspiClient.getOrderEntries(token, d.getId());
                } catch (Exception e) {
                    log.warn("Kaspi getOrderEntries failed for {}: {}", d.getId(), e.getMessage());
                }

                orderEntryService.upsertEntries(order, entries);

                if (entries != null && entries.getData() != null) {
                    for (var item : entries.getData()) {
                        try {
                            var rel = item.getRelationships();
                            if (rel == null || rel.getProduct() == null || rel.getProduct().getData() == null) {
                                continue;
                            }
                            String masterProductId = rel.getProduct().getData().getId();
                            var mp = kaspiClient.getMasterProduct(token, masterProductId);

                            String productCode = (mp != null && mp.getData() != null && mp.getData().getAttributes() != null)
                                    ? mp.getData().getAttributes().getCode()
                                    : null;

                            if (productCode != null && !productCode.isBlank()) {
                                orderEntryService.updateProductCodeByKaspiEntryId(
                                        item.getId(),
                                        productCode
                                );
                            }
                        } catch (Exception e) {
                            log.warn("Kaspi getMasterProduct failed for orderEntry {}: {}", item.getId(), e.getMessage());
                        }
                    }
                }
            }

            if (resp.getMeta() != null && page + 1 >= resp.getMeta().getPageCount()) {
                keep = false;
            } else {
                page++;
            }
        }
    }

    public void syncForCustomerInfoOrders(Customer customer){
        List<Order> orders = orderService.findByCustomerDontDelivered(customer);
        for (Order o : orders){
            String query;
            query = buildQueryStatus(o.getCode());
            KaspiOrdersResponse resp = null;
            try {
                resp = kaspiClient.getOrders(customer.getTokenProd(), query);
            }catch (Exception e) {
                log.warn("Kaspi getOrders failed: {}", e.getMessage());
            }
            if (resp == null || resp.getData() == null || resp.getData().isEmpty()) {
                break;
            }
            for (var d : resp.getData()) {
                orderService.upsertFromInoOrders(d);
            }
        }

    }

    public void syncForAllGreenApi(){
        List<GreenApiInstanceResponse> responses = greenApi.getOrders();
        List<Customer> customers = customerService.findAllWithProdTokenTariffIsNotNullTokenGreenApi();
        for (Customer customer : customers) {
            for (GreenApiInstanceResponse g: responses){
                if (customer.getIdInstance() != null
                        && customer.getIdInstance().equals(g.getIdInstance()) && !g.isDeleted()){
                    customer.setTokenGreenApi(g.getApiTokenInstance());
                    customerService.saveCustomer(customer);
                }
            }
        }
    }

    public void syncForAllCustomersOrders(Customer customer, SyncType type) {
        if (!notificationWindowService.decide(customer.getId(), OffsetDateTime.now(ZoneOffset.UTC)).allowed()) {
            log.info("Тихие часы: пропускаем customerId={} для типа {}", customer.getId(), type);
            return;
        }

        List<Order> orders;
        if (type == SyncType.NEW_ORDER) {
            orders = orderService.findByCustomerNewOrders(customer);
        } else if (type == SyncType.DELIVERED_COMPLETED) {
            orders = orderService.findByCustomerDeliveredCompleted(customer);
        } else {
            throw new IllegalArgumentException("Неизвестный тип синхронизации: " + type);
        }
        if (orders.isEmpty()) return;

        for (Order order : orders) {
            List<OrderEntry> entries = order.getEntries();
            if (entries == null) {
                continue;
            }

            CustomerLiteEntity cli = order.getCustomerLite();
            String phone = (cli != null ? cli.getCellPhone() : null);
            if (phone == null) {
                continue;
            }

            boolean allSentOk = true;
            List<ReviewToPersist> sent = new ArrayList<>();

            for (OrderEntry entry : entries) {
                String productCode = entry.getOfferCode();
                if (productCode == null || productCode.isBlank()) continue;

                String text;
                if (type == SyncType.DELIVERED_COMPLETED) {
                    String orderCode = order.getCode();
                    String url = buildReviewUrl(reviewBaseUrl, productCode, orderCode);
                    text = buildMessage(customer, cli, order, entry, url);
                } else {
                    text = buildMessageForNewOrder(customer, cli, order, entry);
                }

                try {
                    Thread.sleep(5000); // Пауза между сообщениями
                    smsService.sendWhatsapp(phone, text, customer.getIdInstance(), customer.getTokenGreenApi());
                    sent.add(new ReviewToPersist(entry, text));
                } catch (Exception ex) {
                    allSentOk = false;
                }
            }
            if (allSentOk) {
                OffsetDateTime sentAt = OffsetDateTime.now();
                for (ReviewToPersist it : sent) {
                    KaspiReview r = KaspiReview.builder()
                            .order(order)
                            .orderEntry(it.entry)
                            .customer(customer)
                            .sentAt(sentAt)
                            .kaspiMessageText(it.text)
                            .kaspiClicked(Boolean.FALSE)
                            .kaspiStatus(ReviewStatus.SENT)
                            .build();
                    kaspiReviewService.save(r);
                }

                if (type == SyncType.DELIVERED_COMPLETED) {
                    order.setReviewSent(true);
                } else {
                    order.setButNotification(true);
                }

                orderService.saveCustomer(order);
            }
        }
    }

    public void syncForAllSpecialCustomersOrders(Customer customer, SyncType type) {
        if (!notificationWindowService.decide(customer.getId(), OffsetDateTime.now(ZoneOffset.UTC)).allowed()) {
            log.info("Тихие часы: пропускаем customerId={} для типа {}", customer.getId(), type);
            return;
        }

        List<Order> orders;
        if (type == SyncType.NEW_ORDER) {
            orders = orderService.findByCustomerNewOrders(customer);
        } else if (type == SyncType.DELIVERED_COMPLETED) {
            orders = orderService.findByCustomerDeliveredCompleted(customer);
        } else {
            throw new IllegalArgumentException("Неизвестный тип синхронизации: " + type);
        }
        if (orders.isEmpty()) return;

        for (Order order : orders) {
            List<OrderEntry> entries = order.getEntries();
            if (entries == null) {
                continue;
            }

            CustomerLiteEntity cli = order.getCustomerLite();
            String phone = (cli != null ? cli.getCellPhone() : null);
            if (phone == null) {
                continue;
            }

            boolean allSentOk = true;
            List<ReviewToPersist> sent = new ArrayList<>();

            for (OrderEntry entry : entries) {
                String productCode = entry.getOfferCode();
                if (productCode == null || productCode.isBlank()) continue;

                String text;
                String url = "";
                if (type == SyncType.DELIVERED_COMPLETED) {
                    String orderCode = order.getCode();
                    url = buildReviewUrl(reviewBaseUrl, productCode, orderCode);
                    text = buildMessage(customer, cli, order, entry, url);
                } else {
                    text = buildMessageForNewOrder(customer, cli, order, entry);
                }

                try {
                    Thread.sleep(5000);
                    String shopPhone = customer.getWhatsappPhone() != null ?  customer.getWhatsappPhone() : customer.getPhone();
                    smsService.sendWhatsappWithButtons(phone, text, customer.getIdInstance(),
                            customer.getTokenGreenApi(), url, shopPhone);
                    sent.add(new ReviewToPersist(entry, text));
                } catch (Exception ex) {
                    allSentOk = false;
                }
            }

            if (allSentOk) {
                OffsetDateTime sentAt = OffsetDateTime.now();
                for (ReviewToPersist it : sent) {
                    KaspiReview r = KaspiReview.builder()
                            .order(order)
                            .orderEntry(it.entry)
                            .customer(customer)
                            .sentAt(sentAt)
                            .kaspiMessageText(it.text)
                            .kaspiClicked(Boolean.FALSE)
                            .kaspiStatus(ReviewStatus.SENT)
                            .build();
                    kaspiReviewService.save(r);
                }

                if (type == SyncType.DELIVERED_COMPLETED) {
                    order.setReviewSent(true);
                } else {
                    order.setButNotification(true);
                }

                orderService.saveCustomer(order);
            }
        }
    }

    public void syncForAllCustomersOrdersPermission(Customer customer, SyncType syncType) {
        List<Order> orders;
        if (syncType == SyncType.NEW_ORDER) {
            orders = orderService.findByCustomerNewOrders(customer);
        } else if (syncType == SyncType.DELIVERED_COMPLETED) {
            orders = orderService.findByCustomerDeliveredCompleted(customer);
        } else {
            throw new IllegalArgumentException("Неизвестный тип синхронизации: " + syncType);
        }
        if (orders.isEmpty()) return;

        for (Order order : orders) {
            List<OrderEntry> entries = order.getEntries();
            if (entries == null) {
                continue;
            }

            CustomerLiteEntity cli = order.getCustomerLite();
            String phone = (cli != null ? cli.getCellPhone() : null);
            if (phone == null) {
                continue;
            }

            String text;
            if (syncType == SyncType.DELIVERED_COMPLETED) {
                text = buildMessagePermission(customer, cli, SyncType.DELIVERED_COMPLETED);
            } else {
                text = buildMessagePermission(customer, cli, SyncType.NEW_ORDER);
            }

            try {
                Thread.sleep(5000);
                smsService.sendWhatsapp(phone, text, customer.getIdInstance(), customer.getTokenGreenApi());
                cli.setIsPermissionAsked(true);
                orderService.saveCustomer(order);
                cliService.save(cli);
            } catch (Exception ex) {
                log.error("Ошибка при отправке сообщения");
            }
        }
    }

    private String buildMessagePermission(Customer customer, CustomerLiteEntity cli, SyncType syncType) {
        String name = nvl(cli != null ? cli.getName() : "Клиент");
        String shop = nvl(customer.getFullName());
        if (syncType == SyncType.DELIVERED_COMPLETED) {
            String ru = buildDefaultDeliveredCompletedRuPermission(name, shop);
            String kz = buildDefaultDeliveredCompletedKzPermission(name, shop);
            return ru + "\n\n---\n\n" + kz;
        } else {
            String ru = buildDefaultNewOrderRuPermission(name, shop);
            String kz = buildDefaultNewOrderKzPermission(name, shop);
            return ru + "\n\n---\n\n" + kz;
        }
    }


    private record ReviewToPersist(OrderEntry entry, String text) {
    }

    private String buildQuery(long ge, long le, int pageSize) {
        return "?page[number]=" + 0 +
                "&page[size]=" + pageSize +
                "&filter[orders][creationDate][$ge]=" + ge +
                "&filter[orders][creationDate][$le]=" + le +
                "&include[orders]=user";
    }

    private String buildQueryStatus(String code) {
        return "?filter[orders][code]=" + code;
    }

    private String buildReviewUrl(String baseUrl, String productCode, String orderCode) {
        return String.format("%s?productCode=%s&orderCode=%s&rating=%d",
                baseUrl, urlEncode(productCode), urlEncode(orderCode), 5);
    }

    private String urlEncode(String s) {
        return java.net.URLEncoder.encode(s == null ? "" : s, java.nio.charset.StandardCharsets.UTF_8);
    }

    private String buildMessage(Customer customer, CustomerLiteEntity cli, Order order, OrderEntry entry, String reviewUrl) {
        String name = nvl(cli != null ? cli.getName() : "Клиент");
        String shop = nvl(customer.getFullName());
        String offer = nvl(entry != null ? entry.getOfferName() : "Товар");
        String price = nvl(order != null ? order.getTotalPrice().toString() : "0");
        String orderNum = nvl(order != null ? order.getCode() : "-");

        Template template = templateService.findTemplateByCustomerId(customer.getId(), SyncType.DELIVERED_COMPLETED);

        Map<String, String> variables = Map.of(
                "customerName", name,
                "shopName", shop,
                "productName", offer,
                "price", price,
                "orderId", orderNum,
                "link", reviewUrl
        );

        Template randTemplate = templateService.findRandomTemplate(SyncType.DELIVERED_COMPLETED);
        String defaultRu = processTemplate(randTemplate.getValue(), variables);
        String defaultKz = processTemplate(randTemplate.getValueKz(), variables);

        String msg = nvl(customer.getKaspiReviewMessage());

        if (template == null) {
            return defaultRu + "\n\n---\n\n" + defaultKz  + "\n\n---\n\n" + msg;
        }

        boolean ruEmpty = isEmpty(template.getValue());
        boolean kzEmpty = isEmpty(template.getValueKz());

        if (kzEmpty && ruEmpty) {
            return defaultRu + "\n\n---\n\n" + defaultKz  + "\n\n---\n\n" + msg;
        }

        defaultRu = ruEmpty ? defaultRu : processTemplate(template.getValue(), variables);
        defaultKz = kzEmpty ? defaultKz : processTemplate(template.getValueKz(), variables);

        return defaultRu + "\n\n---\n\n" + defaultKz + "\n\n---\n\n" + msg;
    }

    private String nvl(String s) { return s == null ? "" : s; }


    private String buildMessageForNewOrder(Customer customer, CustomerLiteEntity cli, Order order, OrderEntry entry) {
        String name = nvl( cli != null ? cli.getName() : "Клиент");
        String shop = nvl(customer.getFullName());
        String offer = nvl(entry != null ? entry.getOfferName() : "Товар");
        String quantity = nvl(entry != null ? String.valueOf(entry.getQuantity().intValue()) : "1");
        String orderNum = nvl(order != null ? order.getCode() : "-");
        String deliveryAddress = nvl(order != null ? order.getDeliveryFormattedAddress() : "Адрес не указан");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        String deliveryDate = nvl(order != null ? order.getPlannedDeliveryDate().atZoneSameInstant(KZ).format(formatter) : "Уточняется");

        Template template = templateService.findTemplateByCustomerId(customer.getId(), SyncType.NEW_ORDER);

        Map<String, String> variables = Map.of(
                "customerName", name,
                "shopName", shop,
                "productName", offer,
                "amount", quantity,
                "orderId", orderNum,
                "deliveryAddress", deliveryAddress,
                "expectedArrivalDate", deliveryDate
        );

        Template randTemplate =templateService.findRandomTemplate(SyncType.NEW_ORDER);

        String defaultRu = processTemplate(randTemplate.getValue(), variables);
        String defaultKz = processTemplate(randTemplate.getValueKz(), variables);

        String msg = nvl(customer.getKaspiReviewMessage());
        if (template == null) {
            return defaultRu + "\n\n---\n\n" + defaultKz  + "\n\n---\n\n" + msg;
        }

        boolean ruEmpty = isEmpty(template.getValue());
        boolean kzEmpty = isEmpty(template.getValueKz());

        if (kzEmpty && ruEmpty) {
            return defaultRu + "\n\n---\n\n" + defaultKz  + "\n\n---\n\n" + msg;
        }

        defaultRu = ruEmpty ? defaultRu : processTemplate(template.getValue(), variables);
        defaultKz = kzEmpty ? defaultKz : processTemplate(template.getValueKz(), variables);

        return defaultRu + "\n\n---\n\n" + defaultKz + "\n\n---\n\n" + msg;
    }

    private String processTemplate(String template, Map<String, String> variables) {
        StringSubstitutor substitutor = new StringSubstitutor(variables, "{{", "}}");
        return substitutor.replace(template);
    }

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

}
