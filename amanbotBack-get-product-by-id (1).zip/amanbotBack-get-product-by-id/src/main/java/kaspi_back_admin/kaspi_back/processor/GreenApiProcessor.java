package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.api.GreenApi;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.CustomerLiteEntity;
import kaspi_back_admin.kaspi_back.dto.request.IncomingMessageRequest;
import kaspi_back_admin.kaspi_back.dto.response.DeleteInstanceResponse;
import kaspi_back_admin.kaspi_back.dto.response.TariffExpiredCustomerResponse;
import kaspi_back_admin.kaspi_back.service.impl.CustomerLiteEntityService;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.util_services.SmsService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@AllArgsConstructor
public class GreenApiProcessor {
    private final GreenApi greenApi;
    private final CustomerLiteEntityService cliService;
    private final SmsService smsService;
    private final CustomerService customerService;
    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");

    public String proceedRequest(IncomingMessageRequest request) {
        if (!"textMessage".equalsIgnoreCase(request.getMessageData().getTypeMessage())) {
            return "WRONG TYPE OF MESSAGE " + request.getMessageData().getTypeMessage();
        }
        IncomingMessageRequest.MessageData.TextMessageData textMessageData = request.getMessageData().getTextMessageData();
        if (textMessageData == null) {
            return "NULL MESSAGE";
        }
        String message = request.getMessageData().getTextMessageData().getTextMessage();
        String shopNumber = request.getInstanceData().getWid().replaceFirst("7","").replace("@c.us","");
        String userNumber = request.getSenderData().getSender().replaceFirst("7","").replace("@c.us","");

        if (!shopNumber.equals(userNumber)) {
            log.info("MESSAGE {}", message);
            log.info("SENDER {}", userNumber);

            CustomerLiteEntity cli = cliService.findCliByPhone(userNumber);
            if (cli == null) {
                return "Пользователь не относится к системе";
            }
            if (StringUtils.hasText(message)) {
                cli.setIsAllowedToSend(true);
                cliService.save(cli);
            }
        }
        return "RECiVIED";
    }

    public void clearQueue(Long customerId) {
        smsService.clearQueue(customerId);
    }

    public DeleteInstanceResponse removeCustomerByIdInstance(Long idInstance) {
        return greenApi.deleteInstance(idInstance);
    }

    public Page<TariffExpiredCustomerResponse> getTariffExpiredCustomers(Pageable pageable) {
        List<TariffExpiredCustomerResponse> filteredResponses = greenApi.getOrders().stream()
                .filter(instance -> !instance.isDeleted())
                .map(instance -> {
                        Customer customer = customerService.findCustomerByIdInstanceOrName(instance.getIdInstance(), instance.getName());
                        if (customer == null) return null;

                        return TariffExpiredCustomerResponse.builder()
                                .idInstance(instance.getIdInstance())
                                .fullName(customer.getFullName())
                                .tariffStartAt(customer.getTariffStartAt())
                                .tariffEndAt(customer.getTariffEndAt())
                                .tariffName(customer.getTariffType().getDisplayName())
                                .whatsappPhone(customer.getWhatsappPhone())
                                .build();
                    }
                )
                .filter(customer -> customer != null && customer.getTariffEndAt().isBefore(OffsetDateTime.now(KZ)))
                .toList();
        int size = filteredResponses.size();

        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), size);

        if (start > size || start > end) {
            return new PageImpl<>(new ArrayList<>(), pageable, size);
        }

        List<TariffExpiredCustomerResponse> subList = filteredResponses.subList(start, end);

        return new PageImpl<>(subList, pageable, size);
    }
}
