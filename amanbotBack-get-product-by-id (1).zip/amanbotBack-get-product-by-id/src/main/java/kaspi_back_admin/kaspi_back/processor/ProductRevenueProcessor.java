package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.KaspiDeliveryRate;
import kaspi_back_admin.kaspi_back.db.entities.ProductCategory;
import kaspi_back_admin.kaspi_back.dto.request.ProductRevenueRequest;
import kaspi_back_admin.kaspi_back.dto.response.ProductRevenueResponse;
import kaspi_back_admin.kaspi_back.service.KaspiDeliveryRateService;
import kaspi_back_admin.kaspi_back.service.impl.ProductCategoryServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class ProductRevenueProcessor {
    private final KaspiDeliveryRateService kaspiDeliveryRateService;
    private final ProductCategoryServiceImpl productCategoryService;

    private static final double TAX_RATE = 0.03;
    private static final double KASPI_PAY_TAX_RATE = 0.0095;
    private static final double DELIVERY_TAX_RATE = 1.16;

    private static final Set<Long> TIRE_CATEGORY_IDS = Set.of(225L, 226L, 227L, 228L, 229L);
    private static final double HEAVY_TIRE_WEIGHT_THRESHOLD = 25.0;

    public ProductRevenueResponse calculate(ProductRevenueRequest request) {
        if (request == null || request.getPrice() == null || request.getCost() == null || request.getPrice() == 0 || request.getCost() == 0) {
            return null;
        }

        double price = request.getPrice();
        double cost = request.getCost();
        double kaspiCommission = price * request.getKaspiCommissionRate() / 100 * (1 + request.getKaspiCommissionRate() / 100);
        double defectRate = 0.0;
        double defect = 0.0;

        if (request.getDefectRate() != null) {
            defectRate = request.getDefectRate();
            defect = defectRate / 100 * price;
        }

        Optional<ProductCategory> category = productCategoryService.getByTitle(request.getCategoryTitle());
        KaspiDeliveryRate.TireType tireType = KaspiDeliveryRate.TireType.NONE;

        if (category.isPresent()) {
            if (TIRE_CATEGORY_IDS.contains(category.get().getId())) {
                if (request.getWeight() > HEAVY_TIRE_WEIGHT_THRESHOLD) {
                    tireType = KaspiDeliveryRate.TireType.TRUCK;
                } else {
                    tireType = KaspiDeliveryRate.TireType.CAR;
                }
            }
        }

        KaspiDeliveryRateService.Zone zone = KaspiDeliveryRateService.Zone.valueOf(request.getDeliveryType().toUpperCase());
        double deliveryBase = kaspiDeliveryRateService.getPrice(BigDecimal.valueOf(price), BigDecimal.valueOf(request.getWeight()), tireType, zone).doubleValue();
        double delivery = deliveryBase * DELIVERY_TAX_RATE;

        double tax = price * TAX_RATE;
        double kaspiPay = price * KASPI_PAY_TAX_RATE;

        double expenses = request.getExpenses() == null ? 0 : request.getExpenses();
        double investmentPerUnit = cost + defect + expenses;

        double marginalProfitPerUnit = price - cost - defect
                - expenses - kaspiCommission - tax - kaspiPay - delivery;
        double profitabilityPerUnit = 0;
        double marginalityPerUnit = 0;
        if (marginalProfitPerUnit < 0) {
            marginalProfitPerUnit = 0;
        } else {
            profitabilityPerUnit = marginalProfitPerUnit / investmentPerUnit * 100;
            marginalityPerUnit = marginalProfitPerUnit / price * 100;
        }

        double minimalPricePerUnit = cost / (1 - defectRate/100 - TAX_RATE - KASPI_PAY_TAX_RATE) + delivery + kaspiCommission + expenses;

        double investment = request.getInvestment() == null ? 0 : request.getInvestment();
        double productCount = Math.floor((investment - defectRate/100 * investment) / cost);

        double revenue = productCount * price;

        double marginalProfit = revenue
                - productCount * cost
                - productCount * delivery
                - productCount * tax
                - productCount * kaspiPay
                - productCount * kaspiCommission
                - productCount * expenses;

        double minimalCount = investment / (price - delivery - defect - kaspiCommission - kaspiPay - expenses);

        ProductRevenueResponse.CalculationPerUnit unitCalculation = new ProductRevenueResponse.CalculationPerUnit(
                doubleToLong(investmentPerUnit),
                doubleToLong(profitabilityPerUnit),
                doubleToLong(marginalityPerUnit),
                doubleToLong(marginalProfitPerUnit),
                doubleToLong(minimalPricePerUnit)
        );

        ProductRevenueResponse.PartyCalculation partyCalculation = new ProductRevenueResponse.PartyCalculation(
                doubleToLong(productCount),
                doubleToLong(revenue),
                doubleToLong(marginalProfit),
                (long) Math.ceil(Math.max(minimalCount, 0))
        );

        return new ProductRevenueResponse(
                doubleToLong(kaspiCommission),
                doubleToLong(defect),
                doubleToLong(delivery),
                doubleToLong(tax),
                doubleToLong(kaspiPay),
                unitCalculation,
                partyCalculation
        );
    }

    private Long doubleToLong(double value) {
        return (long) Math.floor(Math.max(value, 0));
    }
}
