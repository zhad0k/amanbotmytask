package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.dto.TariffDto;
import kaspi_back_admin.kaspi_back.mapper.TariffMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
@AllArgsConstructor
@Slf4j
public class TariffProcessor {
    private final TariffMapper tariffMapper;

    public List<TariffDto> getTariffsByKind(String kind) {
        TariffType.Kind requestedKind = parseKind(kind);
        if (requestedKind == null) return Collections.emptyList();

        return Arrays.stream(TariffType.values())
                .filter(t -> t.getKind() == requestedKind)
                .filter(t -> t != TariffType.NOTIFICATION_FREE)
                .map(tariffMapper::toTariffDto)
                .toList();
    }

    private TariffType.Kind parseKind(String kind) {
        try { return TariffType.Kind.valueOf(kind.trim().toUpperCase()); }
        catch (IllegalArgumentException e) { return null; }
    }
}
