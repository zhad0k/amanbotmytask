package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.entities.ProductCategory;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import kaspi_back_admin.kaspi_back.db.repository.ProductRepository;
import kaspi_back_admin.kaspi_back.db.repository.projections.StatisticsRow;
import kaspi_back_admin.kaspi_back.dto.ProductDto;
import kaspi_back_admin.kaspi_back.dto.ProductInfoDto;
import kaspi_back_admin.kaspi_back.dto.StatisticsDto;
import kaspi_back_admin.kaspi_back.dto.request.StatisticsType;
import kaspi_back_admin.kaspi_back.dto.request.UpdatePriceGlobalCustomerRequest;
import kaspi_back_admin.kaspi_back.dto.request.UpdateProductRequest;
import kaspi_back_admin.kaspi_back.dto.response.CustomerProductInfoResponse;
import kaspi_back_admin.kaspi_back.dto.response.CustomerProductStatistics;
import kaspi_back_admin.kaspi_back.mapper.ProductMapper;
import kaspi_back_admin.kaspi_back.service.ProductCategoryService;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.OrderEntryService;
import kaspi_back_admin.kaspi_back.service.impl.OrderService;
import kaspi_back_admin.kaspi_back.service.impl.ProductService;
import kaspi_back_admin.kaspi_back.service.util_services.DateConverterUtil;
import kaspi_back_admin.kaspi_back.service.util_services.EntityUpdateUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import kaspi_back_admin.kaspi_back.dto.response.ProductInfoResponse;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Component
@AllArgsConstructor
public class CustomerProcessor {

    private final ProductService productService;
    private final ProductMapper productMapper;
    private final OrderService orderService;
    private final CustomerService customerService;
    private final OrderEntryService orderEntryService;
    private final ProductCategoryService productCategoryService;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    public ProductInfoDto getCustomerProductsInfo(Customer customer) {
        TariffType tariff = customer.getTariffType();
        long maxInclusive = Optional.ofNullable(tariff)
                .map(TariffType::getTier)
                .map(TariffType.ProductTier::getMaxInclusive)
                .orElse(0);

        Object[] stats = productService.aggregateCountForCustomer(customer.getId()).get(0);
        long totalCount = ((Number) stats[0]).longValue();
        long activeCount = ((Number) stats[1]).longValue();
        long inActiveCount = ((Number) stats[2]).longValue();
        long archiveCount = ((Number) stats[3]).longValue();

        return ProductInfoDto.builder()
                .maxProductCount(maxInclusive)
                .totalCount(totalCount)
                .activeCount(activeCount)
                .inActiveCount(inActiveCount)
                .archiveCount(archiveCount)
                .build();
    }

    public Page<ProductDto> getCustomerProducts(Customer customer, String forSearch, Boolean active, Boolean dampingActive, Pageable pageable) {
        Page<Product> productPage = productService.getProductsForCustomer(customer.getId(), forSearch, active, dampingActive, pageable);
        return productMapper.toProductDtoPage(productPage);
    }

    @Transactional
    public Map<String, String> changeAvailability(Customer customer, Long productId, Boolean isAvailable) {
        Product product = productService.findByProductIdAndCustomerId(customer.getId(), productId);

        product.setPriceAutoChange(isAvailable);
        product.setDeactivatedByMassToggle(null);

        productService.save(product);

        if (Boolean.TRUE.equals(isAvailable)) {
            return Map.of("success", "Товар активирован");
        }

        return Map.of("success", "Товар деактивирован");
    }

    @Transactional
    public Map<String, String> toggleMassAvailability(Customer customer) {
        Long customerId = customer.getId();

        Long activeCount = productService.getActiveCountOfProductsForCustomer(customerId);

        if (activeCount != null && activeCount > 0) {
            List<Product> activeProducts = productService.findAllActiveByCustomerId(customerId);

            if (activeProducts.isEmpty()) {
                return Map.of("success", "Нет активных товаров для деактивации");
            }

            for (Product product : activeProducts) {
                product.setPriceAutoChange(false);

                product.setDeactivatedByMassToggle(true);
            }

            productService.saveAll(activeProducts);

            return Map.of("success", "Активные товары массово деактивированы");
        }

        List<Product> productsToReactivate =
                productService.findAllMassDeactivatedByCustomerId(customerId);

        if (productsToReactivate.isEmpty()) {
            return Map.of("success", "Нет товаров для массовой активации");
        }

        TariffType tariff = customer.getTariffType();

        long maxInclusive = Optional.ofNullable(tariff)
                .map(TariffType::getTier)
                .map(TariffType.ProductTier::getMaxInclusive)
                .map(Integer::longValue)
                .orElse(0L);

        if (TariffType.NOTIFICATION_FREE.equals(tariff)) {
            maxInclusive = 20_000L;
        }

        if (productsToReactivate.size() > maxInclusive) {
            throw new DataIntegrityViolationException(String.valueOf(maxInclusive));
        }

        for (Product product : productsToReactivate) {
            product.setPriceAutoChange(true);
            product.setDeactivatedByMassToggle(null);
        }

        productService.saveAll(productsToReactivate);

        return Map.of("success", "Товары, выключенные массовым переключателем, снова активны");
    }

    public boolean isMassAvailabilityEnabled(Customer customer) {
        Optional<Customer> freshCustomer = customerRepository.findByIdWithProducts(customer.getId());

        return freshCustomer
                .map(c -> c.getProducts().stream().anyMatch(Product::isPriceAutoChange))
                .orElse(false);
    }

    @Transactional
    public void updatePrice(Customer customer, Long productId, UpdateProductRequest request) {
        Product product = productService.findByProductIdAndCustomerId(customer.getId(), productId);

        EntityUpdateUtil.setIfPresent(product::setMinPrice, request.getNewMinPrice());
        EntityUpdateUtil.setIfPresent(product::setMaxPrice, request.getNewMaxPrice());
        productService.save(product);
    }

    @Transactional
    public long updatePriceGlobal(Customer customer, UpdatePriceGlobalCustomerRequest request) {
        List<Product> products = productService.findAllByIdsAndCustomerId(
                request.productIds(),
                customer.getId()
        );
        if (products.size() != request.productIds().size()) {
            throw new DataIntegrityViolationException("Некоторые товары не найдены или не принадлежат клиенту");
        }
        if (request.minPrice() != null || request.maxPrice() != null) {
            return updatePriceLimits(products, request);
        }
        if (request.value() == null || request.value() <= 0) {
            throw new DataIntegrityViolationException(
                    "Значение должно быть больше 0"
            );
        }
        if (request.type() == UpdatePriceGlobalCustomerRequest.ChangeType.PERCENT) {
            if (request.value() > 100) {
                throw new DataIntegrityViolationException("Процент должен быть меньше или равен 100");
            }
        }
        long updated = 0;

        for (Product p : products) {
            Long priceObj = p.getPrice();
            if (priceObj == null) {
                priceObj = Optional.ofNullable(p.getMinPrice())
                        .orElse(Optional.ofNullable(p.getMaxPrice()).orElse(0L));
            }
            long price = priceObj;
            long delta = calcDeltaFromPrice(price, request);

            switch (request.direction()){
                case INCREASE -> {
                    long newMax = price + delta;
                    if (newMax < 0) newMax = 0;
                    p.setMaxPrice(newMax);
                    p.setPriceAutoChange(true);
                }
                case DECREASE -> {
                    long newMin = price - delta;
                    if (newMin < 0) newMin = 0;
                    p.setMinPrice(newMin);
                    p.setPriceAutoChange(true);
                }
            }
            if (p.getMinPrice() != null && p.getMaxPrice() != null && p.getMinPrice() > p.getMaxPrice()) {
                p.setMaxPrice(p.getMinPrice());
            }

            updated++;
        }

        productService.saveAll(products);
        return updated;
    }

    private long updatePriceLimits(List<Product> products, UpdatePriceGlobalCustomerRequest request) {
        long updated = 0;

        for (Product p : products) {
            EntityUpdateUtil.setIfPresent(p::setMinPrice, request.minPrice());
            EntityUpdateUtil.setIfPresent(p::setMaxPrice, request.maxPrice());
            p.setPriceAutoChange(true);
            updated++;
        }

        productService.saveAll(products);
        return updated;
    }

    private long calcDeltaFromPrice(long price, UpdatePriceGlobalCustomerRequest request) {
        if (request.type() == UpdatePriceGlobalCustomerRequest.ChangeType.PERCENT) {
            return price * request.value() / 100;
        }
        return request.value();
    }

    public void deleteProduct(Customer customer, Long productId) {
        Product product = productService.findByProductIdAndCustomerId(customer.getId(), productId);
        productService.delete(product);
    }

    public Page<StatisticsDto> getStatistics(Customer customer, LocalDate fromDate, LocalDate toDate, String forSearch,
                                             boolean available, Pageable pageable) {

        OffsetDateTime start = DateConverterUtil.toStartOfDay(fromDate);
        OffsetDateTime end = DateConverterUtil.toEndOfDay(toDate);
        OffsetDateTime earliest = orderService.getEarliestOrderDate(customer.getId());

        if (earliest != null && fromDate.isBefore(earliest.toLocalDate())) {
            throw new DataIntegrityViolationException(
                    earliest.toLocalDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            );
        }

        Page<StatisticsRow> statisticsRows = productService.findAllWithFullStats(
                customer.getId(),
                forSearch != null ? forSearch : "",
                available,
                start,
                end,
                pageable
        );

        if (statisticsRows.isEmpty()) {
            return Page.empty(pageable);
        }

        List<StatisticsDto> response = statisticsRows.getContent().stream().map(row -> {
            long sellsCount = row.getSellsCount();
            double sellsSum = row.getSellsSum();
            long returnedCount = row.getReturnedCount();
            long cancelledCount = row.getCancelledCount();

            StatisticsDto dto = new StatisticsDto();
            dto.setId(row.getId());
            dto.setName(row.getTitle());
            dto.setCode(row.getCode());
            dto.setActive(row.getActive());
            dto.setAvailable(row.getAvailable());
            dto.setUrl(row.getUrl());
            dto.setImageUrl(row.getImageUrl() != null ? row.getImageUrl() : "");
            dto.setRating(row.getRating() != null ? row.getRating() : 0.0);
            dto.setSellsCount(sellsCount);
            dto.setSellsSum(BigDecimal.valueOf(sellsSum));
            dto.setReturnedCount(returnedCount);
            dto.setCancelledCount(cancelledCount);

            return dto;
        }).toList();

        return new PageImpl<>(response, pageable, statisticsRows.getTotalElements());
    }

    public void deleteCustomerAccount(Long id) {
        customerService.deleteCustomers(id);
    }

    public CustomerProductInfoResponse getCustomerProductInfo(Customer customer, Long productId) {
        Product product = productService.findByProductIdAndCustomerId(customer.getId(), productId);
        Double weight = orderEntryService.getWeightByProductCode(product.getCode());
        ProductCategory category = productCategoryService.getCommissionByCode(product.getCategoryCode());

        return productMapper.toCustomerProductInfoResponse(product, weight, category);
    }

    public CustomerProductStatistics getCustomerProductStatistics(Customer customer, Long productId, LocalDate fromDate, LocalDate toDate, String type) {
        OffsetDateTime earliest = orderService.getEarliestOrderDate(customer.getId());
        OffsetDateTime start;
        OffsetDateTime end;

        if (fromDate == null) {
            start = earliest;
        }
        else {
            start = DateConverterUtil.toStartOfDay(fromDate);

            if (earliest != null && fromDate.isBefore(earliest.toLocalDate())) {
                throw new DataIntegrityViolationException(
                        earliest.toLocalDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                );
            }
        }

        end = toDate == null ? OffsetDateTime.now() : DateConverterUtil.toEndOfDay(toDate);

        Long customerId = customer.getId();
        Object[] salesStatistics = productService.getCustomerProductSalesStatistics(customerId, productId, start, end).get(0);
        Long salesCount = ((Number) salesStatistics[0]).longValue();
        BigDecimal salesPrice = salesStatistics[1] != null ? BigDecimal.valueOf(((Number) salesStatistics[1]).doubleValue()) : BigDecimal.ZERO;

        StatisticsType statisticsType = StatisticsType.valueOf(type.toUpperCase());

        List<Object[]> list;

        switch (statisticsType) {
            case DAILY -> {
                list = productService.getCustomerProductDailyStatistics(customerId, productId, start, end);
            }
            case MONTHLY -> {
                list = productService.getCustomerProductMonthlyStatistics(customerId, productId, start, end);
            }
            default -> throw new IllegalStateException("Unexpected value: " + type);
        }

        List<CustomerProductStatistics.CustomerProductStatisticsByPeriod> stats = new ArrayList<>();

        for (Object[] row : list) {

            LocalDate period = ((java.sql.Date) row[0]).toLocalDate();
            Long count = ((Number) row[1]).longValue();
            BigDecimal price = BigDecimal.valueOf(((Number) row[2]).doubleValue());

            stats.add(new CustomerProductStatistics.CustomerProductStatisticsByPeriod(period, count, price));
        }

        return new CustomerProductStatistics(
                salesCount, salesPrice,
                stats
        );
    }
    @Transactional(readOnly = true)
    public ProductInfoResponse getProductById(Long customerId, Long productId) {
        Product product = productRepository.findByIdAndCustomerId(customerId, productId) //Zh
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        return productMapper.toProductInfoResponse(product);
    }
}
