package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.City;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.entities.ProductPreorder;
import kaspi_back_admin.kaspi_back.db.entities.ProductStock;
import kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction;
import kaspi_back_admin.kaspi_back.db.enums.PreorderFilterType;
import kaspi_back_admin.kaspi_back.db.enums.PreorderSortType;
import kaspi_back_admin.kaspi_back.db.repository.CityRepository;
import kaspi_back_admin.kaspi_back.db.repository.ProductPreorderRepository;
import kaspi_back_admin.kaspi_back.db.repository.ProductRepository;
import kaspi_back_admin.kaspi_back.db.repository.ProductStockRepository;
import kaspi_back_admin.kaspi_back.dto.PointDto;
import kaspi_back_admin.kaspi_back.dto.PreorderDto;
import kaspi_back_admin.kaspi_back.mapper.ProductPreorderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ProductPreorderProcessor {

    private final ProductPreorderRepository repository;
    private final ProductRepository productRepository;
    private final ProductPreorderMapper mapper;
    private final CityRepository cityRepository;
    private final ProductStockRepository productStockRepository;

    @Transactional(readOnly = true)
    public List<PreorderDto> getByProduct(Long productId) {
        List<ProductPreorder> preorders = repository.findActiveByProduct(productId);

        Product product = productRepository.findById(productId)
                .orElse(null);

        assert product != null;
        Map<Long, Product> productMap = Map.of(productId, product);
        return mapper.toDtoList(
                extractAndMapProductPreorders(preorders).values().stream().toList(),
                productMap
        );
    }

    public PreorderDto create(Long productId, List<PointDto> points) {
        Product product = getProductOrThrow(productId);
        List<ProductPreorder> preorders = new ArrayList<>();

        for (PointDto pointDto : points) {
            validatePreorderDoesNotExist(productId, pointDto);

            ProductPreorder preorder = createPreorderProduct(productId, pointDto);
            applyPointSettings(preorder, pointDto);

            ProductPreorder saved = repository.save(preorder);
            preorders.add(saved);
        }

        return buildPreorderDto(product, preorders);
    }

    public PreorderDto update(Long productId, List<PointDto> points) {
        Product product = getProductOrThrow(productId);
        List<ProductPreorder> preorders = new ArrayList<>();

        for (PointDto pointDto : points) {
            ProductPreorder preorder = findExistingPreorder(productId, pointDto.getPoint(), pointDto.getCityId())
                    .orElseGet(() -> createPreorderProduct(productId, pointDto));

            preorder.setProcessed(false);
            applyPointSettings(preorder, pointDto);

            preorders.add(preorder);
        }

        product.setAvailable(true);
        List<ProductPreorder> savedPreorders = repository.saveAll(preorders);

        return buildPreorderDto(product, savedPreorders);
    }

    public Map<String, String> delete(Long productId) {
        List<ProductPreorder> preorders = repository.findByProductIdAndDeletedFalse(productId);
        if (preorders.isEmpty()) {
            throw new DataIntegrityViolationException(
                    "Настройка предзаказа не существует для продукта: " + productId
            );
        }

        for (ProductPreorder preorder : preorders) {
            resetAndMarkDeleted(preorder);
        }

        repository.saveAll(preorders);
        return Map.of("success", "Предзаказы для продукта удалены");
    }

    private Product getProductOrThrow(Long productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Продукт не найден: " + productId));
    }

    private void validatePreorderDoesNotExist(Long productId, PointDto pointDto) {
        findExistingPreorder(productId, pointDto.getPoint(), pointDto.getCityId())
                .ifPresent(existing -> {
                    throw new IllegalStateException(
                            "Настройка предзаказа уже существует для продукта: " + productId +
                                    " и склада: " + pointDto.getPoint() +
                                    " города: " + pointDto.getCityId()
                    );
                });
    }

    private void applyPointSettings(ProductPreorder preorder, PointDto pointDto) {
        ProductStock stock = preorder.getProductStock();
        if (stock == null) {
            throw new IllegalStateException("Не найден ProductStock для настройки предзаказа");
        }

        applyStockSettings(stock, pointDto);
        applyPreorderSettings(preorder, pointDto);

        productStockRepository.save(stock);
    }

    private void applyStockSettings(ProductStock stock, PointDto pointDto) {
        if (pointDto.getMinimalStock() != null) {
            stock.setMinimalStock(pointDto.getMinimalStock());
        }
        if (pointDto.getQuantity() != null) {
            stock.setStock(Long.valueOf(pointDto.getQuantity()));
        }
        if (pointDto.getStockByCustomer() != null) {
            int stockByCustomer = pointDto.getStockByCustomer();

            if (stock.getStock() == null || stock.getStock() != stockByCustomer) {
                stock.setStockByCustomer(stockByCustomer);
            }
            else {
                stock.setStockByCustomer(null);
            }
        }

        MinimalStockAction action = pointDto.getAction() != null
                ? pointDto.getAction()
                : MinimalStockAction.NONE;

        stock.setAction(action);
    }

    private void applyPreorderSettings(ProductPreorder preorder, PointDto pointDto) {
        MinimalStockAction action = pointDto.getAction();

        if (MinimalStockAction.SET_PREORDER.equals(action)) {
            validateSetPreorderFields(pointDto);
            preorder.setPreorderDays(pointDto.getPreorderDays());
            preorder.setPreorderCount(pointDto.getPreorderCount());
        } else if (MinimalStockAction.RESET_STOCK.equals(action)) {
            validateResetStockFields(pointDto);
            preorder.setPreorderDays(0);
            preorder.setPreorderCount(pointDto.getPreorderCount());
        } else {
            preorder.setPreorderDays(0);
            preorder.setPreorderCount(0);
        }
    }

    private void validateSetPreorderFields(PointDto pointDto) {
        if (pointDto.getPreorderDays() == null) {
            throw new IllegalArgumentException("Для действия SET_PREORDER необходимо указать количество дней");
        }
        if (pointDto.getPreorderCount() == null) {
            throw new IllegalArgumentException("Для действия SET_PREORDER необходимо указать количество планируемых продаж");
        }
    }

    private void validateResetStockFields(PointDto pointDto) {
        if (pointDto.getPreorderCount() == null || pointDto.getPreorderCount() <= 0) {
            throw new IllegalArgumentException("Для действия RESET_STOCK необходимо указать целевой остаток (больше 0)");
        }
    }

    private void resetAndMarkDeleted(ProductPreorder preorder) {
        preorder.setDeleted(true);
        preorder.setProcessed(false);
        preorder.setPreorderDays(0);
        preorder.setPreorderCount(0);

        ProductStock stock = preorder.getProductStock();
        if (stock != null) {
            stock.setMinimalStock(null);
            stock.setAction(MinimalStockAction.NONE);
            productStockRepository.save(stock);
        }
    }

    private PreorderDto buildPreorderDto(Product product, List<ProductPreorder> preorders) {
        return mapper.toDto(
                extractAndMapProductPreorders(preorders).get(product.getId()),
                product
        );
    }

    @Transactional(readOnly = true)
    public List<PreorderDto> findAll() {
        List<ProductPreorder> preorders = repository.findAll();

        Set<Long> productIds = preorders.stream()
                .map(ProductPreorder::getProductId)
                .collect(Collectors.toSet());

        Map<Long, Product> productMap = productRepository.findAllById(productIds).stream()
                .collect(Collectors.toMap(Product::getId, p -> p));

        return mapper.toDtoList(extractAndMapProductPreorders(preorders).values().stream().toList(), productMap);
    }

    @Transactional(readOnly = true)
    public Page<PreorderDto> findByCustomer(
            Long customerId,
            String forSearch,
            Pageable pageable,
            PreorderSortType sortType,
            PreorderFilterType filterType
    ) {
        // сортировки
        boolean availableOnly = false;
        boolean preorderOnly  = false;
        boolean lowStockSort  = false;
        boolean triggeredSort = false;
        Pageable effectivePageable = pageable;

        if (sortType != null) {
            switch (sortType) {
                case AVAILABLE -> availableOnly = true;
                case PREORDER  -> preorderOnly = true;
                case NEW -> effectivePageable = PageRequest.of(
                        pageable.getPageNumber(),
                        pageable.getPageSize(),
                        Sort.by(
                            new Sort.Order(Sort.Direction.DESC, "updateDate").nullsLast(),
                            Sort.Order.desc("createdDate")
                        )
                );
                case CHEAP -> effectivePageable = PageRequest.of(
                        pageable.getPageNumber(),
                        pageable.getPageSize(),
                        Sort.by(Sort.Direction.ASC, "price")
                );
                case EXPENSIVE -> effectivePageable = PageRequest.of(
                        pageable.getPageNumber(),
                        pageable.getPageSize(),
                        Sort.by(Sort.Direction.DESC, "price")
                );
                case LOW_STOCK -> {
                    lowStockSort = true;
                    effectivePageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize());
                }
                case TRIGGERED -> {
                    triggeredSort = true;
                    effectivePageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize());
                }
            }
        }

        // фильтры
        boolean dampingFilter = filterType == PreorderFilterType.DAMPING_ENABLED;
        boolean reviewsFilter = filterType == PreorderFilterType.REVIEWS_ENABLED;
        boolean noBotsFilter  = filterType == PreorderFilterType.NO_BOTS;
        // ALL -> все false

        String search = (forSearch == null || forSearch.isBlank())
                ? null
                : forSearch.trim();

        Page<Product> productPage = productRepository.findPreorderProducts(
                customerId,
                availableOnly,
                preorderOnly,
                dampingFilter,
                reviewsFilter,
                noBotsFilter,
                search,
                lowStockSort,
                triggeredSort,
                effectivePageable
        );

        if (productPage.isEmpty()) {
            return Page.empty(effectivePageable);
        }

        List<Product> products = productPage.getContent();

        // 1. Загружаем stocks для всех продуктов страницы одним запросом
        productRepository.fetchStocks(products);

        // 2. Собираем все cityId из stocks всех продуктов страницы
        Set<String> allCityIds = products.stream()
                .flatMap(p -> p.getStocks().stream())
                .map(ProductStock::getCityId)
                .filter(id -> id != null && !id.isBlank())
                .collect(Collectors.toSet());

        // 3. Загружаем названия городов одним запросом на всю страницу
        Map<String, String> cityNamesById = cityRepository.findAllById(allCityIds).stream()
                .collect(Collectors.toMap(City::getId, City::getName));

        List<Long> productIds = products.stream()
                .map(Product::getId)
                .toList();

        // 4. Загружаем предзаказы для всех продуктов страницы одним запросом
        Map<Long, Map<String, ProductPreorder>> preorderMap =
                extractAndMapProductPreorders(repository
                        .findByCustomerIdAndProductIdIn(customerId, productIds));

        // 5. Маппим с заранее загруженными городами — без доп. запросов в БД
        List<PreorderDto> items = products.stream()
                .map(pr -> mapper.toDto(preorderMap.get(pr.getId()), pr, cityNamesById))
                .toList();

        return new PageImpl<>(items, effectivePageable, productPage.getTotalElements());
    }

    public String syncWithExternalService(Long customerId) {

        return "Обновлено успешно для customerId=" + customerId;
    }

    // Ищет существующий предзаказ: сначала по point+cityId, потом по point (fallback)
    private Optional<ProductPreorder> findExistingPreorder(Long productId, String point, String cityId) {
        if (cityId != null && !cityId.isBlank()) {
            return repository.findByProductIdAndPointAndCityIdAndDeletedFalse(productId, point, cityId);
        }
        return repository.findByProductIdAndPointAndDeletedFalse(productId, point);
    }

    private ProductPreorder createPreorderProduct(Long productId, PointDto pointDto) {
        String point = pointDto.getPoint();
        String cityId = pointDto.getCityId();

        ProductStock productStock = (cityId != null && !cityId.isBlank())
                ? productStockRepository.findByProductIdAndPointAndCityId(point, cityId, productId)
                        .orElseThrow(() -> new DataIntegrityViolationException(
                                "Склад не существует: point=" + point + ", cityId=" + cityId))
                : productStockRepository.findStoreIdContainsForProduct(point, productId)
                        .orElseThrow(() -> new DataIntegrityViolationException(
                                "Склад не существует: " + point));

        String cityName = resolveCityNameFromStock(productStock);
        ProductPreorder preorder = new ProductPreorder();
        preorder.setId(null);
        preorder.setProductId(productId);
        preorder.setCity(cityName);
        preorder.setProductStock(productStock);
        preorder.setDeleted(false);
        preorder.setProcessed(false);
        preorder.setDeletedDate(null);
        return preorder;
    }

    private String resolveCityNameFromStock(ProductStock stock) {
        if (stock.getCityId() == null) return null;
        return cityRepository.findById(stock.getCityId())
                .map(City::getName)
                .orElse(null);
    }

    private Map<Long, Map<String, ProductPreorder>> extractAndMapProductPreorders(List<ProductPreorder> preorders) {
        return preorders.stream()
                .collect(Collectors.groupingBy(
                        ProductPreorder::getProductId,
                        Collectors.toMap(
                                p -> p.getProductStock().getStoreId(),
                                Function.identity(),
                                (existing, duplicate) -> duplicate
                        )
                ));
    }
}