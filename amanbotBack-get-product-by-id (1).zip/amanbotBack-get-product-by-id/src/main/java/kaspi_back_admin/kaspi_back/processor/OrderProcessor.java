package kaspi_back_admin.kaspi_back.processor;


import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.ZoneId;

@Slf4j
@Component
@RequiredArgsConstructor
public class OrderProcessor {

    private final CustomerService customerService;
    private final KaspiReviewsApiProcessor kaspiReviewsApiProcessor;
    private final OrderService orderService;


    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");


    public void syncTodayForAllCustomersPremium() {
        for (Customer c : customerService.findAllWithProdTokenTariff()) {
            log.info("Sync Kaspi orders for customer id={} username={}", c.getId(), c.getUsername());
            kaspiReviewsApiProcessor.syncForCustomerForPeriod(c);
        }
    }

    public void syncForAllCustomersInfoOrders(){
        for (Customer c : customerService.findAllWithProdTokenTariff()) {
            log.info("Sync Kaspi StatusOrders for customer id={} username={}", c.getId(), c.getUsername());
            kaspiReviewsApiProcessor.syncForCustomerInfoOrders(c);
        }
    }

    public void syncForAllCustomersOrdersDeliveredSend(){
        for (Customer c : customerService.findAllWithProdTokenTariff()) {
//            Customer c = customerService.findCustomerById(292L);
            log.info("Sync Kaspi smsSend orders for customer id={} username={}", c.getId(), c.getUsername());
            kaspiReviewsApiProcessor.syncForAllCustomersOrders(c, SyncType.DELIVERED_COMPLETED);
        }
    }

    public void syncForAllGreenApi(){
        log.info("Sync start greenAPi Information" );
        kaspiReviewsApiProcessor.syncForAllGreenApi();
    }

    public void syncForAllCustomersNewOrders(){
        for (Customer c : customerService.findAllWithProdTokenTariff()) {
            log.info("Sync Kaspi smsSend new orders for customer id={} username={}", c.getId(), c.getUsername());
            kaspiReviewsApiProcessor.syncForAllCustomersOrders(c, SyncType.NEW_ORDER);
        }
    }

    public void syncForAllCustomersOrdersDeliveredSendToTakePermission(){
        for (Customer c : customerService.findAllWithProdTokenTariff()) {
            log.info("Sync Kaspi smsSend orders for customer id={} username={}", c.getId(), c.getUsername());
//            kaspiReviewsApiProcessor.syncForAllCustomersOrdersPermission(c, SyncType.DELIVERED_COMPLETED);
        }
    }

    public void syncForAllCustomersNewOrdersToTakePermission(){
        for (Customer c : customerService.findAllWithProdTokenTariff()) {
            log.info("Sync Kaspi smsSend new orders for customer id={} username={}", c.getId(), c.getUsername());
//            kaspiReviewsApiProcessor.syncForAllCustomersOrdersPermission(c, SyncType.NEW_ORDER);
        }
    }

    public void syncForAllCustomersOrdersDeliveredSendSpecial() {
        for (Customer c : customerService.findCustomersSpecial()) {
            log.info("Sync Kaspi smsSend new orders for customer id={} username={}", c.getId(), c.getUsername());
            kaspiReviewsApiProcessor.syncForAllSpecialCustomersOrders(c, SyncType.DELIVERED_COMPLETED);
        }
    }

    public void syncForAllCustomersInfoOrdersSpecial() {
        for (Customer c : customerService.findCustomersSpecial()) {
            log.info("Sync Kaspi StatusOrders for customer id={} username={}", c.getId(), c.getUsername());
            kaspiReviewsApiProcessor.syncForCustomerInfoOrders(c);
        }
    }

}
