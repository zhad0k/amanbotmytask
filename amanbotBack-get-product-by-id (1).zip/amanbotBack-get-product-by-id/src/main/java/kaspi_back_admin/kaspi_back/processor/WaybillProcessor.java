package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.api.ApiKaspiBackClient;
import kaspi_back_admin.kaspi_back.api.KaspiClient;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Order;
import kaspi_back_admin.kaspi_back.db.entities.OrderEntry;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import kaspi_back_admin.kaspi_back.db.repository.OrderRepository;
import kaspi_back_admin.kaspi_back.db.repository.ProductRepository;
import kaspi_back_admin.kaspi_back.dto.WaybillDto;
import kaspi_back_admin.kaspi_back.dto.request.AssembleAndRefreshRequest;
import kaspi_back_admin.kaspi_back.dto.response.AssembleAndRefreshResponse;
import kaspi_back_admin.kaspi_back.mapper.WaybillMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StreamUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static kaspi_back_admin.kaspi_back.db.enums.OrderStatus.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class WaybillProcessor {
    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;
    private final KaspiClient kaspiClient;
    private final ApiKaspiBackClient apiKaspiBackClient;

    // ====== label detection ======
    private static final float LABEL_MAX_WIDTH = 400f;
    private static final float LABEL_MAX_HEIGHT = 600f;

    // ====== A4 detection ======
    private static final float EPS = 3f;
    private static final float A4_W = 595f;
    private static final float A4_H = 842f;


    public enum WaybillDocType {
        LABEL(0),
        A4(1),
        OTHER(2);

        public final int priority;
        WaybillDocType(int priority) { this.priority = priority; }
    }

    @Transactional
    public byte[] mergeWaybills(Long customerId, String forSearch, Integer numberOfSpace) {
        List<String> orderCodes = orderRepository.findToAssembleWithoutWaybill(customerId, forSearch);
        return mergeWaybillsInternal(customerId, orderCodes, false, numberOfSpace);
    }

    @Transactional
    public byte[] mergeWaybillsSelected(Long customerId, List<String> orderCodes, Integer numberOfSpace) {
        if (orderCodes == null || orderCodes.isEmpty()) {
            throw new IllegalArgumentException("Список выбранных заказов пуст");
        }
        validateAllCodesBelongToCustomer(customerId, orderCodes);
        return mergeWaybillsInternal(customerId, orderCodes, true, numberOfSpace);
    }

    private byte[] mergeWaybillsInternal(Long customerId, List<String> orderCodes, boolean selected, Integer numberOfSpace) {
        if (orderCodes == null || orderCodes.isEmpty()) {
            throw new IllegalStateException(selected
                    ? "Нет выбранных заказов для формирования накладных"
                    : "Нет заказов в PACKING без накладной");
        }


//       byte[] stubPdf = loadStubPdf();
//        Map<String, byte[]> pdfs = new LinkedHashMap<>();
//        for (String code : orderCodes) {
//            pdfs.put(code, stubPdf);
//        }
//        return mergeLabels(pdfs);

        AssembleAndRefreshResponse resp = apiKaspiBackClient.assembleAndRefresh(
                customerId,
                new AssembleAndRefreshRequest(orderCodes, 1)
        );

        if (resp == null || !resp.isAllReady() || resp.getWaybills() == null || resp.getWaybills().isEmpty()) {
            throw new IllegalStateException("Накладные не готовы. Попробуйте ещё раз позже.");
        }

        Customer customer = customerRepository.findById(customerId).orElseThrow();

        Map<String, byte[]> pdfs = downloadWaybills(customer.getTokenProd(), resp.getWaybills());
        if (pdfs.isEmpty()) {
            throw new IllegalStateException("Ни одна накладная не скачалась.");
        }

        return mergeLabels(pdfs);
    }

    private byte[] loadStubPdf() {
        String stubPath = "waybill.pdf";
        try {
            ClassPathResource res = new ClassPathResource(stubPath);
            if (!res.exists()) {
                throw new IllegalStateException("Stub PDF not found in classpath: " + stubPath);
            }
            byte[] bytes = StreamUtils.copyToByteArray(res.getInputStream());
            if (!isPdf(bytes)) {
                throw new IllegalStateException("Stub file is not a PDF: " + stubPath);
            }
            return bytes;
        } catch (IOException e) {
            throw new RuntimeException("Failed to load stub pdf: " + stubPath, e);
        }
    }

    private Map<String, byte[]> downloadWaybills(String tokenProd, List<? extends AssembleAndRefreshResponse.WaybillItem> waybills) {
        Map<String, byte[]> pdfs = new LinkedHashMap<>();

        for (var w : waybills) {
            if (w == null || w.getWaybillUrl() == null || w.getWaybillUrl().isBlank()) continue;

            try {
                byte[] pdf = kaspiClient.downloadWaybillPdf(tokenProd, w.getWaybillUrl());
                if (isPdf(pdf)) {
                    pdfs.put(w.getOrderCode(), pdf);
                } else {
                    log.warn("Waybill skipped: code={} reason=NOT_PDF", w.getOrderCode());
                }
            } catch (Exception ex) {
                log.warn("Waybill download failed code={} kaspiId={} msg={}",
                        w.getOrderCode(), w.getKaspiId(), ex.getMessage());
            }
        }

        return pdfs;
    }


    /**
     * Merge ALL received PDFs and sort them as: LABEL -> A4 -> OTHER
     */
    public byte[] mergeLabels(Map<String, byte[]> orderIdToPdfBytes) {

        record Doc(String orderId, WaybillDocType type, byte[] bytes, int pages) {}

        List<Doc> docs = new ArrayList<>();

        for (var e : orderIdToPdfBytes.entrySet()) {
            String orderId = e.getKey();
            byte[] bytes = e.getValue();

            if (bytes == null || bytes.length == 0) {
                log.warn("Waybill skipped: orderId={} reason=EMPTY_BODY", orderId);
                continue;
            }
            if (!isPdf(bytes)) {
                log.warn("Waybill skipped: orderId={} reason=NOT_PDF", orderId);
                continue;
            }

            try (PDDocument src = PDDocument.load(bytes, String.valueOf(MemoryUsageSetting.setupMainMemoryOnly()))) {
                if (src.getNumberOfPages() == 0) {
                    log.warn("Waybill skipped: orderId={} reason=NO_PAGES", orderId);
                    continue;
                }

                WaybillDocType type = detectType(src);
                docs.add(new Doc(orderId, type, bytes, src.getNumberOfPages()));

                PDRectangle box = src.getPage(0).getMediaBox();
                float w = box.getWidth();
                float h = box.getHeight();
                int rot = src.getPage(0).getRotation();
                if (rot == 90 || rot == 270) {
                    float tmp = w; w = h; h = tmp;
                }

                log.info("Waybill detected: orderId={} type={} pages={} firstPageSize={}x{} rotation={}",
                        orderId, type, src.getNumberOfPages(), Math.round(w), Math.round(h), rot);

            } catch (Exception ex) {
                log.warn("Waybill skipped: orderId={} reason=PDF_PARSE_ERROR msg={}", orderId, ex.getMessage());
            }
        }

        if (docs.isEmpty()) {
            throw new IllegalStateException("No PDFs found to merge");
        }

        docs.sort(Comparator.comparingInt(d -> d.type().priority));

        PDFMergerUtility merger = new PDFMergerUtility();

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            merger.setDestinationStream(out);

            for (Doc d : docs) {
                merger.addSource(new ByteArrayInputStream(d.bytes()));
                log.info("Waybill included: orderId={} type={} pages={}", d.orderId(), d.type(), d.pages());
            }

            merger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());
            return out.toByteArray();

        } catch (IOException ex) {
            throw new RuntimeException("Failed to merge waybills pdf", ex);
        }
    }

    @Transactional(readOnly = true)
    public Page<WaybillDto> getAllByCustomerId(
            Long customerId,
            String forSearch,
            Pageable pageable
    ) {
        Page<Order> orders = orderRepository.findKaspiDeliveryHandoverByCustomerId(
                customerId,
                List.of(
                        ACCEPTED_BY_MERCHANT,
                        ASSEMBLE_REQUESTED,
                        WAYBILL_PENDING,
                        WAYBILL_READY
                ),
                forSearch,
                pageable
        );

        // Батч-подтягиваем карточки товаров по offerCode для фото/названия (без N+1).
        Set<String> offerCodes = orders.getContent().stream()
                .filter(o -> o.getEntries() != null)
                .flatMap(o -> o.getEntries().stream())
                .map(OrderEntry::getOfferCode)
                .filter(c -> c != null && !c.isBlank())
                .collect(Collectors.toSet());

        Map<String, Product> productByOfferCode = offerCodes.isEmpty()
                ? Map.of()
                : productRepository.findByCustomerIdAndCodeIn(customerId, offerCodes).stream()
                        .filter(p -> p.getCode() != null)
                        .collect(Collectors.toMap(Product::getCode, p -> p, (a, b) -> a));

        return orders.map(o -> WaybillMapper.toWaybillDto(o, productByOfferCode));
    }

    public String syncOrders(Customer customer) {
        return apiKaspiBackClient.syncOrders(customer.getId());
    }

    private WaybillDocType detectType(PDDocument doc) {
        if (doc.getNumberOfPages() == 0) return WaybillDocType.OTHER;

        var page = doc.getPage(0);
        PDRectangle box = page.getMediaBox();

        float w = box.getWidth();
        float h = box.getHeight();

        int rot = page.getRotation();
        if (rot == 90 || rot == 270) {
            float tmp = w; w = h; h = tmp;
        }

        boolean isLabel = w <= LABEL_MAX_WIDTH && h <= LABEL_MAX_HEIGHT;

        boolean isA4 =
                (Math.abs(w - A4_W) <= EPS && Math.abs(h - A4_H) <= EPS) ||
                        (Math.abs(w - A4_H) <= EPS && Math.abs(h - A4_W) <= EPS);

        if (isLabel) return WaybillDocType.LABEL;
        if (isA4) return WaybillDocType.A4;
        return WaybillDocType.OTHER;
    }

    private boolean isPdf(byte[] bytes) {
        return bytes.length >= 4
                && bytes[0] == 0x25 && bytes[1] == 0x50 && bytes[2] == 0x44 && bytes[3] == 0x46;
    }

    private void validateAllCodesBelongToCustomer(Long customerId, List<String> codes) {
        long count = orderRepository.countByCustomerIdAndCodeIn(customerId, codes);
        if (count != codes.size()) {
            throw new IllegalArgumentException("Некоторые заказы не принадлежат пользователю или не найдены");
        }
    }

}
