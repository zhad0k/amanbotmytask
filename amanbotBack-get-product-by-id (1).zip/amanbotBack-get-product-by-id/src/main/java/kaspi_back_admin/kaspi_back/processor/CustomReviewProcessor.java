package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@AllArgsConstructor
public class CustomReviewProcessor {
    private final CustomerService customerService;

    public Map<String,String> addKaspiMessageReview(Long id, String reviewMessage) {
        Customer customer = customerService.findCustomerById(id);
        customer.setKaspiReviewMessage(reviewMessage);
        customerService.saveCustomer(customer);
        return Map.of("success","Шаблон сообщения обновлён и сохранён");
    }

    public Map<String, String> getKaspiMessageReview(Long id) {
        Customer customer = customerService.findCustomerById(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", customer.getKaspiReviewMessage());
        return response;
    }

    public Map<String, String> removeKaspiMessageReview(Long id) {
        Customer customer = customerService.findCustomerById(id);
        customer.setKaspiReviewMessage(null);
        customerService.saveCustomer(customer);
        return Map.of("success","Шаблон сообщения удален");
    }

}
