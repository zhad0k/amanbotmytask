package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.NotificationPolicy;
import kaspi_back_admin.kaspi_back.dto.request.NotificationPolicyRequest;
import kaspi_back_admin.kaspi_back.service.impl.NotificationService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class NotificationProcessor {
    private final NotificationService notificationService;

    public Page<NotificationPolicy> getAll(Pageable pageable) {
        return notificationService.getAll(pageable);
    }

    public NotificationPolicy getByCustomerId(Long customerId) {
        return notificationService.getByCustomerId(customerId);
    }

    public NotificationPolicy create(NotificationPolicyRequest request) {
        return notificationService.create(request);
    }

    public NotificationPolicy update(NotificationPolicyRequest request) {
        return notificationService.update(request);
    }

    public void toggleEnabled(Long customerId) {
        notificationService.toggleEnabled(customerId);
    }

    public void delete(Long customerId) {
        notificationService.delete(customerId);
    }

}
