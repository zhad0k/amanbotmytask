package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.entities.Template;
import kaspi_back_admin.kaspi_back.db.enums.NotificationMode;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import kaspi_back_admin.kaspi_back.dto.ModeratorTemplateDto;
import kaspi_back_admin.kaspi_back.dto.TemplateDto;
import kaspi_back_admin.kaspi_back.dto.TemplateVarDto;
import kaspi_back_admin.kaspi_back.dto.request.AddTemplateRequest;
import kaspi_back_admin.kaspi_back.mapper.TemplateMapper;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.KaspiReviewService;
import kaspi_back_admin.kaspi_back.service.impl.ModeratorService;
import kaspi_back_admin.kaspi_back.service.impl.TemplateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static kaspi_back_admin.kaspi_back.service.util_services.DefaultMessagesUtil.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class TemplateProcessor {
    private final CustomerService customerService;
    private final TemplateService templateService;
    private final ModeratorService moderatorService;
    private final KaspiReviewService reviewService;

    private final TemplateMapper templateMapper;

    public List<TemplateVarDto> getTemplateVars(String type) {
        SyncType syncType = parseSyncType(type).orElse(null);
        if (syncType == null) {
            log.warn("Requested template for unknown type: {}", type);
            return List.of();
        }
        List<TemplateVarDto> vars = TEMPLATE_VARS.get(syncType);
        if (vars == null || vars.isEmpty()) {
            log.warn("No template variables for type: {}", syncType);
            return List.of();
        }
        return List.copyOf(vars);
    }

    public Map<String, String> addTemplate(Long id, AddTemplateRequest request) {
        Customer customer = customerService.findCustomerById(id);
        SyncType syncType = parseSyncType(request.type())
                .orElseThrow(() -> new IllegalArgumentException("Invalid template type: " + request.type()));

        Template template = templateService.findTemplateByCustomerId(customer.getId(), syncType);
        if (template == null) {
            template = new Template();
            template.setCustomer(customer);
            template.setType(syncType);
        }
        template.setValue(request.valueRu());
        template.setValueKz(request.valueKz());
        templateService.save(template);

        log.info("Template {} for customerId={} type={} {}",
                template.getId(),
                customer.getId(),
                syncType,
                "created/updated");

        return Map.of("success", "Шаблон успешно добавлен/обновлён");
    }

    public List<TemplateDto> getTemplates(Long id) {
        Customer customer = customerService.findCustomerById(id);
        Template templateDelivered = templateService.findTemplateByCustomerId(customer.getId(), SyncType.DELIVERED_COMPLETED);
        Template templateNew = templateService.findTemplateByCustomerId(customer.getId(), SyncType.NEW_ORDER);

        List<TemplateDto> result = new ArrayList<>();

        result.add(buildTemplateDto(templateNew, SyncType.NEW_ORDER, customer.getNotificationType()));

        result.add(buildTemplateDto(templateDelivered, SyncType.DELIVERED_COMPLETED, customer.getNotificationType()));

        return result;
    }

    public ModeratorTemplateDto getTemplatesForModerators(Long id) {
        Moderator moderator = moderatorService.findById(id);
        long reviewsSent = reviewService.countByCustomerModeratorId(id);
        List<Template> templates = templateService.findAllByTypeIn(EnumSet.of(
                SyncType.NEW_ORDER,
                SyncType.DELIVERED_COMPLETED
        ));

        Map<String, List<TemplateDto>> grouped = templates.stream()
                .map(t -> templateMapper.toDto(t, true))
                .collect(Collectors.groupingBy(TemplateDto::type));


        ModeratorTemplateDto dto = new ModeratorTemplateDto();
        dto.setModeratorName(moderator.getUsername());
        dto.setActive(moderator.isActive());
        dto.setCreatedAt(moderator.getCreatedDate() == null ? OffsetDateTime.now() : moderator.getCreatedDate());
        dto.setSentCount(reviewsSent);

        dto.setTemplatesNew(grouped.getOrDefault(SyncType.NEW_ORDER.name(), List.of()));
        dto.setTemplatesDelivered(grouped.getOrDefault(SyncType.DELIVERED_COMPLETED.name(), List.of()));

        return dto;
    }

    public Map<String, String> deleteTemplate(Long templateId) {
        templateService.deleteTemplateById(templateId);
        return Map.of("success", "удален");
    }

    private TemplateDto buildTemplateDto(Template template, SyncType type, NotificationMode mode) {
        String defaultRu;
        String defaultKz;

        if (type == SyncType.NEW_ORDER) {
            defaultRu = buildDefaultNewOrderRu("{{customerName}}","{{shopName}}", "{{productName}}",
                    "{{amount}}","{{orderId}}","{{deliveryAddress}}","{{expectedArrivalDate}}");

            defaultKz = buildDefaultNewOrderKz("{{customerName}}","{{shopName}}", "{{productName}}",
                    "{{amount}}","{{orderId}}","{{deliveryAddress}}","{{expectedArrivalDate}}");

        } else {
            defaultRu = buildDefaultDeliveredCompletedRu("{{customerName}}","{{shopName}}", "{{productName}}",
                    "{{price}}","{{orderId}}","{{link}}");

            defaultKz = buildDefaultDeliveredCompletedKz("{{customerName}}","{{shopName}}", "{{productName}}",
                    "{{price}}","{{orderId}}","{{link}}");
        }

        String ru = (template == null || template.getValue() == null) ? defaultRu.trim() : template.getValue();
        String kz = (template == null || template.getValueKz() == null) ? defaultKz.trim() : template.getValueKz();

        boolean disabled;

        if (mode == null) {
            disabled = false;
        } else {
            NotificationMode requiredMode = (type == SyncType.NEW_ORDER)
                    ? NotificationMode.NEW_ORDERS
                    : NotificationMode.DELIVERED_ORDERS;

            disabled = !mode.has(requiredMode);
        }

        return new TemplateDto(0L, ru, kz, type.name(), disabled);
    }

    private Optional<SyncType> parseSyncType(String raw) {
        if (raw == null || raw.isBlank()) return Optional.empty();
        try {
            return Optional.of(SyncType.valueOf(raw.trim().toUpperCase()));
        } catch (IllegalArgumentException ex) {
            log.warn("Unknown SyncType: '{}'", raw);
            return Optional.empty();
        }
    }

    public Map<String, String> updateTemplateModerator(Long templateId, AddTemplateRequest request) {
        Template template = templateService.findTemplateById(templateId);
        SyncType syncType = parseSyncType(request.type())
                .orElseThrow(() -> new IllegalArgumentException("Invalid template type: " + request.type()));
        Customer customer = customerService.findCustomerById(0L);

        if (template == null) {
            template = new Template();
            template.setCustomer(customer);
            template.setType(syncType);
        }
        template.setValue(request.valueRu());
        template.setValueKz(request.valueKz());
        templateService.save(template);

        log.info("Template for moderator type={} {}",
                syncType,
                "updated");

        return Map.of("success", "Шаблон успешно обновлён");
    }

    public Map<String, String> addTemplateModerator(AddTemplateRequest request) {
        SyncType syncType = parseSyncType(request.type())
                .orElseThrow(() -> new IllegalArgumentException("Invalid template type: " + request.type()));
        Customer customer = customerService.findCustomerById(0L);
        Template template = new Template();
        template.setCustomer(customer);
        template.setType(syncType);
        template.setValue(request.valueRu());
        template.setValueKz(request.valueKz());
        templateService.save(template);

        log.info("Template for moderator type={} {}",
                syncType,
                "created");

        return Map.of("success", "Шаблон успешно добавлен");
    }

    public void changeMode(Customer customer, String type, boolean disable) {
        SyncType syncType = parseSyncType(type).orElseThrow();
        NotificationMode current =
                Optional.ofNullable(customer.getNotificationType())
                        .orElse(NotificationMode.ALL);

        NotificationMode target = SyncType.NEW_ORDER.equals(syncType)
                ? NotificationMode.NEW_ORDERS
                : NotificationMode.DELIVERED_ORDERS;

        NotificationMode next = disable
                ? current.disable(target)
                : current.enable(target);

        if (next != current) {
            customer.setNotificationType(next);
            customerService.saveCustomer(customer);
        }
    }
}
