package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.BaseEntity;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.enums.CustomerFilter;
import kaspi_back_admin.kaspi_back.db.enums.Role;
import kaspi_back_admin.kaspi_back.db.enums.SearchType;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.db.repository.CustomerRepository;
import kaspi_back_admin.kaspi_back.dto.CustomerDetailsDto;
import kaspi_back_admin.kaspi_back.dto.CustomerDto;
import kaspi_back_admin.kaspi_back.dto.ModeratorDto;
import kaspi_back_admin.kaspi_back.dto.request.*;
import kaspi_back_admin.kaspi_back.mapper.CustomerMapper;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.ImageStorageService;
import kaspi_back_admin.kaspi_back.service.impl.ModeratorService;
import kaspi_back_admin.kaspi_back.service.impl.ProductService;
import kaspi_back_admin.kaspi_back.service.util_services.AppConstants;
import kaspi_back_admin.kaspi_back.service.util_services.DateConverterUtil;
import kaspi_back_admin.kaspi_back.service.util_services.EntityUpdateUtil;
import kaspi_back_admin.kaspi_back.validation.KaspiMerchantValidator;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
@AllArgsConstructor
@Slf4j
public class ModeratorProcessor extends BaseEntity {
    private final CustomerService customerService;
    private final CustomerMapper customerMapper;
    private final PasswordEncoder passwordEncoder;
    private final ModeratorService moderatorService;
    private final KaspiMerchantValidator validator;
    private final ImageStorageService imageStorageService;
    private final ProductService productService;
    private final CustomerRepository customerRepository;
    private static final ZoneId KZ = ZoneId.of("Asia/Almaty");

    public Page<CustomerDto> getAllCustomers(String search, String tariff, LocalDate dateFrom,
                                             LocalDate dateTo, Pageable pageable) {
        OffsetDateTime from = Optional.ofNullable(dateFrom)
                .map(d -> d.atStartOfDay(KZ).toOffsetDateTime())
                .orElse(OffsetDateTime.now().minusYears(10));

        OffsetDateTime to = Optional.ofNullable(dateTo)
                .map(d -> d.atTime(LocalTime.MAX).atZone(KZ).toOffsetDateTime())
                .orElse(OffsetDateTime.now().plusYears(10));

        Page<Customer> customers = customerService.getAllCustomers(tariff, search, from, to, pageable);
        return customers.map(customerMapper::toDtoTrial);
    }

    public void setPeriod(Customer customer, CreateCustomerRequest request) {
        if ("FREE".equals(request.getTariff()) || "NOTIFICATION_FREE".equals(request.getTariff())) {
            setTrialTariffPeriod(customer, request.getTariffKind());
        } else {
            TariffType tariff = parseTariffType(request.getTariff());
            customer.setTariffType(tariff);

            applyTariffPeriod(
                    customer,
                    tariff,
                    request.getDateFrom(),
                    request.getDateTo(),
                    request.getDateFromDumping(),
                    request.getDateToDumping()
            );
        }
    }

    public Map<String, String> createCustomer(Long id, CreateCustomerRequest request) {
        String phone = request.getPhone();
        if (customerService.existsByPhone(phone)) {
            throw new DataIntegrityViolationException("Пользователь с таким номером уже существует");
        }

        Customer customer = new Customer();
        setPeriod(customer, request);
        customer.setFullName(request.getIpName());
        customer.setPhone(request.getPhone());
        customer.setPassword(passwordEncoder.encode(request.getPassword()));
        customer.setRole(Role.ROLE_CLIENT);
        customer.setTokenProd(request.getKaspiToken());
        customer.setIpName(request.getIpName());
        customer.setWhatsappPhone(request.getPhoneWhatsApp());
        if (request.getManagerId() != null) {
            Moderator moderator = moderatorService.findById(request.getManagerId());
            customer.setModerator(moderator);
        } else {
            Moderator moderator = moderatorService.getReferenceById(id);
            customer.setModerator(moderator);
        }
        customer.setIdInstance(request.getIdInstance());
        customer.setMerchantId(request.getMerchantId());
        customer.setHasKaspiMerchantPassword(false);
        customer.setActive(true);
        customer.setKaspiEmailMerchant(request.getEmail());
        customer.setKaspiPasswordMerchant(request.getEmailPassword());
        customer.setPreorderEnabled(request.isPreorderEnabled());
        customer.setInventoryEnabled(request.isInventoryEnabled());
        customer.setWaybillEnabled(request.isWaybillEnabled());
        customer.setIsTrial(request.getIsTrial());
        customerService.saveCustomer(customer);
        return Map.of("success", "Пользователь успешно создан");
    }

    public void setTrialTariffPeriod(Customer customer, String tariffKindStr) {
        TariffType.Kind tariffKind = TariffType.Kind.valueOf(tariffKindStr);
        OffsetDateTime time = OffsetDateTime.now();
        try {
            if (TariffType.Kind.NOTIFICATION.equals(tariffKind) ) {
                customer.setTariffStartAt(time);
                customer.setTariffEndAt(time.plusDays(7));
                customer.setTariffType(TariffType.NOTIFICATION_FREE);
            } else if (TariffType.Kind.DAMPING.equals(tariffKind)) {
                customer.setTariffStartAtDumping(time);
                customer.setTariffEndAtDumping(time.plusDays(7));
                customer.setTariffType(TariffType.DAMPING_PRO_UNLIMITED);
            } else if (TariffType.Kind.VIP.equals(tariffKind)) {
                customer.setTariffStartAt(time);
                customer.setTariffEndAt(time.plusDays(7));
                customer.setTariffStartAtDumping(time);
                customer.setTariffEndAtDumping(time.plusDays(7));
                customer.setTariffType(TariffType.VIP_UNLIMITED);
            }
        } catch (Exception e) {
            log.error("Ошибка при установке даты пробного периода");
            throw new RuntimeException("Не удалось установить дату пробного тарифа");
        }
    }

    public Map<String,String> deleteCustomer (Long id) {
        try{
            Customer customer = customerService.findCustomerById(id);
            customerService.deleteCustomer(customer.getId());
            return Map.of("success","Клиент удален");
        }
        catch (Exception e) {
            log.error("Ошибка при удалений ", e);
            throw new RuntimeException("Не удалось удалить клиента" + e.getMessage());
        }
    }

    @Transactional
    public Map<String, String> changeSubscription(ChangeSubscriptionRequest request) {
        Customer customer = customerService.findCustomerById(request.getCustomerId());
        TariffType tariff = request.getTariff();
        applyTariffPeriod(
                customer,
                tariff,
                request.getDateFrom(), request.getDateTo(),
                request.getDateFromDumping(), request.getDateToDumping()
        );

        customer.setTariffType(tariff);
        customer.setIdInstance(request.getIdInstance());
        customer.setPreorderEnabled(request.getPreorderEnabled());
        customer.setInventoryEnabled(request.getInventoryEnabled());
        customer.setWaybillEnabled(request.getWaybillEnabled());

        if (request.getManagerId() != null) {
            Moderator moderator = moderatorService.findById(request.getManagerId());
            customer.setModerator(moderator);
        }
        customer.setTariffType(tariff);
        if (request.getIdInstance() != null) {
            customer.setIdInstance(request.getIdInstance());
        }
        if (request.getUpdatePriceGlobalModeratorRequest() != null) {
            updateAllProductPriceForCustomer(customer.getId(), request.getUpdatePriceGlobalModeratorRequest());
        }
        EntityUpdateUtil.setIfHasText(customer::setIpName, request::getIpName);
        updateKaspiMerchantIfNeeded(customer, request);
        customerService.saveCustomer(customer);
        return Map.of("success", "Пользователь обновлён");
    }

    public List<ModeratorDto> getAllManagers() {
        List<Moderator> moderators = moderatorService.findAllModerators();
        return moderators.stream().map(moderator ->
                ModeratorDto.builder()
                        .id(moderator.getId())
                        .name(moderator.getUsername())
                        .phone(moderator.getPhone())
                        .email(moderator.getEmail())
                        .imageName(moderator.getImageName() != null ? moderator.getImageName() : null)
                        .build()
        ).toList();
    }

    private void updateKaspiMerchantIfNeeded(Customer customer, ChangeSubscriptionRequest request) {
        if (request.hasKaspiCredentials()) {
            validator.validateKaspiMerchantUpdate(customer, request);
            updateKaspiCredentials(customer, request);
        }
    }

    private void updateKaspiCredentials(Customer customer, ChangeSubscriptionRequest request) {
        if (StringUtils.hasText(request.getKaspiMerchantEmail())) {
            customer.changeKaspiEmail(request.getKaspiMerchantEmail().trim());
        }
        if (StringUtils.hasText(request.getKaspiMerchantPassword())) {
            customer.changeKaspiPassword(request.getKaspiMerchantPassword());
        }
        customer.setHasKaspiMerchantPassword(true);
    }


    public Map<String, String> createManager(ModeratorRequest request) {
        if (moderatorService.existsByPhone(request.getPhone()).isPresent()) {
            throw new DataIntegrityViolationException("Пользователь с таким номером уже существует");
        }
        try {
            Moderator moderator = new Moderator();
            moderator.setActive(true);
            moderator.setUsername(request.getName());
            moderator.setPhone(request.getPhone());
            moderator.setRole(Role.ROLE_ADMIN.toString());
            moderator.setPassword(passwordEncoder.encode(AppConstants.DEFAULT_PASSWORD));
            moderator.setCreatedDate(OffsetDateTime.now());
            applyFileIfModerator(request.getImage(), moderator);
            moderatorService.save(moderator);
            return Map.of("success", "Менеджер успешно создан!");
        } catch (Exception e) {
            log.error("Ошибка при создании менеджера", e);
            throw new RuntimeException("Не удалось создать менеджера" + e.getMessage());
        }
    }


    public Map<String,String> updateModerator(ModeratorRequest request) {
        try{
            Optional.ofNullable(request.getId()).orElseThrow(RuntimeException::new);

            Moderator moderator = moderatorService.findById(request.getId());
            Optional.ofNullable(request.getName())
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .ifPresent(moderator::setUsername);

            Optional.ofNullable(request.getPhone())
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .ifPresent(moderator::setPhone);

            Optional.of(request.getImage())
                    .filter(file -> !file.isEmpty())
                    .ifPresent(file -> applyFileIfModerator(file, moderator));
            moderator.setUpdateDate(OffsetDateTime.now());
            moderatorService.save(moderator);
            return Map.of("success","Модератор обнавлен");
        }
        catch (Exception e){
            log.error("Ошибка при обновлений менеджера", e);
            throw new RuntimeException("Не удалось обновить менеджера" + e.getMessage());
        }
    }

    public Map<String,String> deleteModerator(Long id) {
        try{
            Moderator moderator = moderatorService.findById(id);
            moderator.setActive(false);
            moderatorService.save(moderator);
            return Map.of("success","Модератор удален");
        }
        catch (Exception e) {
            log.error("Ошибка при удалений ", e);
            throw new RuntimeException("Не удалось удалить менеджера" + e.getMessage());
        }
    }


    public CustomerDto setBalance(BigDecimal balance, Long customerId) {
        Customer customer = customerService.findCustomerById(customerId);
        customer.setBalance(balance);
        customerService.saveCustomer(customer);
        return customerMapper.toDto(customer);
    }

    public Page<ModeratorDto> getAllManagersPage(Pageable pageable) {
        Page<Moderator> moderators = moderatorService.findAllModeratorsPage(pageable);
        return moderators.map(moderator ->
                ModeratorDto.builder()
                        .id(moderator.getId())
                        .name(moderator.getUsername())
                        .phone(moderator.getPhone())
                        .imageName(moderator.getImageName())
                        .build()
        );
    }

    private TariffType parseTariffType(String tariff) {
        if (tariff == null || tariff.isBlank()) return null;
        return TariffType.valueOf(tariff);
    }

    public Page<CustomerDetailsDto> getClientsByTariff(String type, String forSearch, Boolean active, String tariffName,
                                            LocalDate endDateFrom, LocalDate endDateTo,
                                            Long managerId, Pageable pageable) {
        OffsetDateTime from = DateConverterUtil.toStartOfDay(endDateFrom);
        OffsetDateTime to = DateConverterUtil.toEndOfDay(endDateTo);
        TariffType tariffType = parseTariffType(tariffName);

        SearchType searchType = SearchType.valueOf(type.toUpperCase());
        Page<Customer> response = searchType.search(customerService, forSearch,active, tariffType, from, to,managerId,pageable);

        return response.map(c -> customerMapper.toSearchDto(c,searchType));
    }

    private void updateAllProductPriceForCustomer(Long customerId, UpdatePriceGlobalModeratorRequest req) {

        Customer customer = customerService.findCustomerById(customerId);
        TariffType tariff = customer.getTariffType();

        if (tariff == null || tariff.getKind() == null) {
            throw new DataIntegrityViolationException("У клиента не задан тариф");
        }

        TariffType.Kind kind = tariff.getKind();
        if (kind == TariffType.Kind.NOTIFICATION || kind == TariffType.Kind.NOTIFICATION_DAMPING) {
            throw new DataIntegrityViolationException("У клиента тариф без демпинга. Массовое изменение недоступно.");
        }
        if (req.value() == null || req.value() < 1) {
            throw new DataIntegrityViolationException("Значение должно быть больше 0");
        }
        if (req.type() == UpdatePriceGlobalModeratorRequest.ChangeType.PERCENT) {
            if (req.value() > 100) {
                throw new DataIntegrityViolationException("Процент должен быть меньше или равен 100");
            }
        }

        List<Product> products = productService.findAllByCustomerId(customerId);

        for (Product p : products) {
            Long priceObj = p.getPrice();
            if (priceObj == null || priceObj <= 0) {
                continue;
            }
            long price = priceObj;
            long delta = (req.type() == UpdatePriceGlobalModeratorRequest.ChangeType.PERCENT)
                    ? price * req.value() / 100
                    : req.value();

            if (req.direction() == UpdatePriceGlobalModeratorRequest.Direction.INCREASE) {
                long newMax = price + delta;
                p.setMaxPrice(Math.max(0, newMax));
            } else {
                long newMin = price - delta;
                p.setMinPrice(Math.max(0, newMin));
            }

            if (p.getMinPrice() != null && p.getMaxPrice() != null && p.getMinPrice() > p.getMaxPrice()) {
                p.setMaxPrice(p.getMinPrice());
            }
        }

        productService.saveAll(products);
    }

    public Map<String, String> updateCustomerByTariff(Long id, CustomerUpdateRequest request) {
        validateDates(request.getStart(), request.getEnd());
        validateDates(request.getStartDumping(), request.getEndDumping());

        Customer customer = customerService.findCustomerById(id);

        TariffType newTariff = parseTariffType(request.getTariffName());
        if (newTariff != null) {
            customer.setTariffType(newTariff);
        }
        if (request.getUpdatePriceGlobalModeratorRequest() != null) {
            updateAllProductPriceForCustomer(id, request.getUpdatePriceGlobalModeratorRequest());
        }

        TariffType effectiveTariff = customer.getTariffType();

        applyTariffPeriod(
                customer,
                effectiveTariff,
                request.getStart(),
                request.getEnd(),
                request.getStartDumping(),
                request.getEndDumping()
        );

        customer.setIdInstance(request.getInstanceId());

        customer.setPreorderEnabled(request.getPreorderEnabled());
        customer.setInventoryEnabled(request.getInventoryEnabled());
        customer.setWaybillEnabled(request.getWaybillEnabled());
        customer.setIsTrial(request.getIsTrial());
        EntityUpdateUtil.setIfHasText(customer::setIpName, request::getIpName);

        updateKaspiMerchantIfNeeded(customer, request);
        customerService.saveCustomer(customer);

        return Map.of("success", "Успешно обновлены даты тарифа");
    }

    private void validateDates(LocalDate start, LocalDate end) {
        if (start != null && end != null && end.isBefore(start)) {
            throw new IllegalArgumentException("Период некорректен: дата окончания раньше даты начала");
        }
    }

    public Map<String, String> deleteClient(Long id) {
        try {
            Customer customer = customerService.findCustomerById(id);

            if (customer.isActive()) {
                customer.setActive(Boolean.FALSE);
                customerService.saveCustomer(customer);

                return Map.of("success", "Пользователь деактивирован");
            } else {
                customer.setActive(Boolean.TRUE);
                customerService.saveCustomer(customer);

                return Map.of("success", "Пользователь активирован");
            }

        } catch (Exception e) {
            log.error("Ошибка при изменении статуса пользователя", e);
            throw new RuntimeException("Не удалось изменить статус пользователя: " + e.getMessage());
        }
    }


    private void updateKaspiMerchantIfNeeded(Customer customer, CustomerUpdateRequest request) {
        if (request.hasKaspiCredentials()) {
            validator.validateKaspiMerchantUpdate(customer, request);
            updateKaspiCredentials(customer, request);
        }
    }

    private void updateKaspiCredentials(Customer customer, CustomerUpdateRequest request) {
        if (StringUtils.hasText(request.getKaspiMerchantEmail())) {
            customer.changeKaspiEmail(request.getKaspiMerchantEmail().trim());
        }
        if (StringUtils.hasText(request.getKaspiMerchantPassword())) {
            customer.changeKaspiPassword(request.getKaspiMerchantPassword());
        }
        if (StringUtils.hasText(request.getKaspiMerchantId())) {
            customer.changeKaspiMerchantId(request.getKaspiMerchantId());
        }
        customer.setHasKaspiMerchantPassword(true);
    }


    private void applyFileIfModerator(MultipartFile file, Moderator moderator) {
        if (file != null && !file.isEmpty()) {
            String imageUrl = imageStorageService.storeImage(file);
            moderator.setImageName(file.getOriginalFilename());
            moderator.setImageUrl(imageUrl);
        }
    }

    private void applyTariffPeriod(
            Customer customer,
            TariffType tariff,
            LocalDate mainFrom,
            LocalDate mainTo,
            LocalDate dumpingFrom,
            LocalDate dumpingTo
    ) {
        if (tariff == null) return;

        TariffType.Kind kind = tariff.getKind();

        switch (kind) {
            case NOTIFICATION -> setMainPeriod(customer, mainFrom, mainTo);
            case DAMPING -> setDumpingPeriod(customer, dumpingFrom, dumpingTo);
            case VIP -> {
                setMainPeriod(customer, mainFrom, mainTo);
                setDumpingPeriod(customer, mainFrom, mainTo);
            }
            case NOTIFICATION_DAMPING, DAMPING_NOTIFICATION -> {
                setMainPeriod(customer, mainFrom, mainTo);
                setDumpingPeriod(customer, dumpingFrom, dumpingTo);
            }
        }
    }

    private void setMainPeriod(Customer customer, LocalDate from, LocalDate to) {
        if (from == null || to == null) return;

        OffsetDateTime start = from.atTime(12, 0)
                .atZone(KZ)
                .toOffsetDateTime();

        OffsetDateTime end = to.atTime(LocalTime.MAX)
                .atZone(KZ)
                .toOffsetDateTime()
                .minusSeconds(1);

        customer.setTariffStartAt(start);
        customer.setTariffEndAt(end);
    }

    private void setDumpingPeriod(Customer customer, LocalDate from, LocalDate to) {
        if (from == null || to == null) return;

        OffsetDateTime start = from.atTime(12, 0)
                .atZone(KZ)
                .toOffsetDateTime();

        OffsetDateTime end = to.atTime(LocalTime.MAX)
                .atZone(KZ)
                .toOffsetDateTime()
                .minusSeconds(1);

        customer.setTariffStartAtDumping(start);
        customer.setTariffEndAtDumping(end);
    }
    public Page<CustomerDto> getCustomersByFilter(
            CustomerFilter filter,
            String forSearch,
            String dateFrom,
            String dateTo,
            Pageable pageable
    ) {
        OffsetDateTime from = parseFilterDate(dateFrom, true);
        OffsetDateTime to = parseFilterDate(dateTo, false);
        return getCustomersByFilter(filter, forSearch, from, to, pageable);
    }

    public Page<CustomerDto> getCustomersByFilter(
            CustomerFilter filter,
            String forSearch,
            OffsetDateTime dateFrom,
            OffsetDateTime dateTo,
            Pageable pageable
    ) {
        CustomerFilter safeFilter = filter == null ? CustomerFilter.ALL : filter;

        String search = forSearch == null || forSearch.isBlank()
                ? null
                : forSearch.trim();

        Page<Customer> customerPage = customerRepository.findAllByFilter(
                safeFilter.name(),
                search,
                dateFrom,
                dateTo,
                pageable
        );

        return customerPage.map(customerMapper::toDtoTrial);
    }

    private OffsetDateTime parseFilterDate(String value, boolean startOfDay) {
        if (value == null || value.isBlank()) {
            return null;
        }

        String normalized = value.trim();
        try {
            return OffsetDateTime.parse(normalized);
        } catch (DateTimeParseException ignored) {
        }

        try {
            LocalDate localDate = LocalDate.parse(normalized);
            return startOfDay
                    ? DateConverterUtil.toStartOfDay(localDate)
                    : DateConverterUtil.toEndOfDay(localDate);
        } catch (DateTimeParseException ignored) {
        }

        try {
            LocalDate localDate = LocalDate.parse(normalized, DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            return startOfDay
                    ? DateConverterUtil.toStartOfDay(localDate)
                    : DateConverterUtil.toEndOfDay(localDate);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Некорректный формат даты: " + value);
        }
    }

    }
