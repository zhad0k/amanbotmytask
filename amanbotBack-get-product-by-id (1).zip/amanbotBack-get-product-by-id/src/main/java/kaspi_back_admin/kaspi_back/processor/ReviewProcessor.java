package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Review;
import kaspi_back_admin.kaspi_back.dto.ReviewDto;
import kaspi_back_admin.kaspi_back.dto.request.ReviewRequest;
import kaspi_back_admin.kaspi_back.mapper.ReviewMapper;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.impl.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class ReviewProcessor {
    private final CustomerService customerService;
    private final ReviewService reviewService;
    private final ReviewMapper reviewMapper;


    public ReviewDto addReview(ReviewRequest request, Long id) {
        try {
            Customer customer = customerService.findCustomerById(id);
            Review review = new Review();
            review.setContent(request.getContent());
            review.setScore(request.getRating());
            review.setCustomer(customer);
            reviewService.save(review);
            return reviewMapper.toReviewDto(review);
        }
        catch (Exception e) {
            log.error("Ошибка при созданий отзыва", e);
            throw new RuntimeException("Не удалось создать отзыв" + e.getMessage());
        }
    }

    public ReviewDto updateReview(ReviewRequest request, Long customerId) {
        try {
            Review review = reviewService.findReviewByIdAndCustomerId(request.getId(), customerId);
            if (request.getContent() != null) review.setContent(request.getContent());
            if (request.getRating() != null) review.setScore(request.getRating());
            review.setUpdateDate(OffsetDateTime.now());
            reviewService.save(review);
            return reviewMapper.toReviewDto(review);
        }
        catch (Exception e) {
            log.error("Ошибка при обновлений отзыва", e);
            throw new RuntimeException("Не удалось обновить отзыв" + e.getMessage());
        }
    }

    public void deleteReview(Long id,  Long customerId) {
        try {
            Review review = reviewService.findReviewByIdAndCustomerId(id, customerId);
            reviewService.deleteById(review.getId());
        } catch (Exception e) {
            log.error("Ошибка при удалений отзыва", e);
            throw new RuntimeException("Не удалось удалить отзыва" + e.getMessage());
        }
    }

    public List<ReviewDto> getReviewsByCustomerId(Long id) {
        List<Review> reviews = reviewService.getReviewsByCustomerId(id);
        return reviews.stream().map(reviewMapper::toReviewDto).collect(Collectors.toList());
    }


    public List<ReviewDto> getReviews() {
        List<Review> reviews = reviewService.getReviews();
        return reviews.stream().map(reviewMapper::toReviewDto).collect(Collectors.toList());
    }

}
