package kaspi_back_admin.kaspi_back.processor;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.repository.ModeratorRepository;
import kaspi_back_admin.kaspi_back.dto.CustomerDto;
import kaspi_back_admin.kaspi_back.dto.request.ChangeCustomerRequest;
import kaspi_back_admin.kaspi_back.dto.request.ChangePasswordRequest;
import kaspi_back_admin.kaspi_back.dto.response.CustomerFeaturesResponse;
import kaspi_back_admin.kaspi_back.mapper.CustomerMapper;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import kaspi_back_admin.kaspi_back.service.util_services.EntityUpdateUtil;
import kaspi_back_admin.kaspi_back.service.util_services.JwtService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class MyProfileProcessor {
    private final CustomerService customerService;
    private final PasswordEncoder passwordEncoder;
    private final CustomerMapper customerMapper;
    private final JwtService  jwtService;
    private final ModeratorRepository moderatorRepository;



    public Map<String, String> changePassword(Long customerId, ChangePasswordRequest request) {
        Customer customer = customerService.findCustomerById(customerId);

        customer.setPassword(passwordEncoder.encode(request.getNewPassword()));
        customerService.saveCustomer(customer);
        return  Map.of("success","Пароль успешно изменен");
    }


    public CustomerDto getCustomerById(Long customerId) {
        Customer customer = customerService.findCustomerById(customerId);
        return customerMapper.toCustomerDto(customer);
    }

    public Map<String, String> updateCustomer(ChangeCustomerRequest request, Long customerId) {
        // 1. Используем твой сервис
        Customer customer = customerService.findCustomerById(customerId);

        // 2. Твои утилиты для обновления текстовых полей
        EntityUpdateUtil.setIfHasText(customer::setIpName, request::getIpName);
        EntityUpdateUtil.setIfHasText(customer::setUsername, request::getUsername);

        EntityUpdateUtil.setIfHasText(customer::setTokenProd, request::getKaspiToken);
        EntityUpdateUtil.setIfHasText(customer::setKaspiPhone, request::getKaspiPhone);
        EntityUpdateUtil.setIfHasText(customer::setKaspiEmail, request::getKaspiEmail);
        EntityUpdateUtil.setIfHasText(customer::setKaspiPassword, request::getKaspiPhonePassword);

        EntityUpdateUtil.setIfPresent(customer::setPassword, request::getNewPassword, passwordEncoder::encode);
        EntityUpdateUtil.setIfHasText(customer::setPhone, request::getNewPhone);

        if (request.getManagerId() != null) {
            Moderator newManager = moderatorRepository.findById(request.getManagerId())
                    .orElseThrow(() -> new RuntimeException("Менеджер не найден"));
            customer.setModerator(newManager);
        }

        Customer saved = customerService.saveCustomerAndReturn(customer);
        String token = jwtService.generateToken(saved);
        return Map.of("token", token);
    }

    public CustomerFeaturesResponse getCustomerFeatures(Long customerId) {
        Customer customer = customerService.findCustomerById(customerId);

        return CustomerFeaturesResponse.builder()
                .inventoryEnabled(isEnabled(customer.getInventoryEnabled()))
                .preorderEnabled(isEnabled(customer.getPreorderEnabled()))
                .waybillEnabled(isEnabled(customer.getWaybillEnabled()))
                .build();
    }


    private boolean isEnabled(Boolean enabled) {
        return enabled != null && enabled;
    }
}
