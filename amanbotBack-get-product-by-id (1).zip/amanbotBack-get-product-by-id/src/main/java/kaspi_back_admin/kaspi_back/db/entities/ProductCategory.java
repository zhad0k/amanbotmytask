package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "product_categories")
public class ProductCategory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kaspi_id", unique = true)
    private Long kaspiId;

    private Integer level;

    @Column(unique = true)
    private String title;

    @Column(name = "kaspi_commission_start")
    private Float kaspiCommissionStart;

    @Column(name = "kaspi_commission_end")
    private Float kaspiCommissionEnd;

    @Column(name = "has_child")
    private Boolean hasChild;

    @Column(name = "parent_id")
    private Long parentId;

    @Column(name = "parent_title")
    private String parentTitle;

    @Column(name = "main_category_id")
    private Long mainCategoryId;

    @Column(name = "main_category_title")
    private String mainCategoryTitle;

    @Column(unique = true)
    private String code;
}
