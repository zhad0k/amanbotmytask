package kaspi_back_admin.kaspi_back.db.enums;

public enum ReviewStatus {
    NEW, SENT, FAILED, DELIVERED
}
