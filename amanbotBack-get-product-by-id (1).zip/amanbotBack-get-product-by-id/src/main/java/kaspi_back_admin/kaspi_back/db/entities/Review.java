package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "review")
public class Review extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "review_id")
    @SequenceGenerator(name = "review_id", sequenceName = "review_id", allocationSize = 1)
    private Long id;

    @Column(name = "content")
    private String content;

    @Min(1)
    @Max(5)
    @Column(name = "score")
    private Integer score;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
}
