package kaspi_back_admin.kaspi_back.db.jdbc;

import com.google.common.collect.Maps;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.mapper.CustomerRowMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

@Slf4j
@Repository
@RequiredArgsConstructor
public class CustomerJdbcRepository {
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public Page<Customer> searchCustomers(
            String tariff,
            String forSearch,
            OffsetDateTime dateFrom,
            OffsetDateTime dateTo,
            Pageable pageable
    ) {
        StringBuilder sql = new StringBuilder("""
        SELECT cus.*, 
               m.id        as m_id,
               m.username  as m_username,
               m.phone     as m_phone,
               m.email     as m_email,
               m.image_name as m_image_name,
               m.image_url  as m_image_url
        FROM customer cus
        LEFT JOIN moderator m ON cus.admin_id = m.id
        WHERE cus.is_active = true
        """);
        Map<String, Object> params = Maps.newHashMap();
        log.info("ForSearch: {}", forSearch);

        if (forSearch != null && !forSearch.isBlank()) {
            sql.append("""
                    AND (
                        LOWER(cus.full_name) LIKE CONCAT('%', :searchName, '%')
                        OR LOWER(cus.last_name) LIKE CONCAT('%', :searchName, '%')
                        OR cus.phone LIKE CONCAT('%', :searchPhone, '%')
                    )
                    """);

            params.put("searchName", forSearch.toLowerCase());
            params.put("searchPhone", forSearch);
        }

        if (tariff != null && !tariff.isBlank()) {
            if (TariffType.NOTIFICATION_FREE.equals(TariffType.valueOf(tariff))) {
                sql.append("""
                            AND (cus.tariff = 'NOTIFICATION_FREE')
                            AND ((cus.tariff_start_at is not null or cus.tariff_end_at is not null)
                                OR (cus.tariff_start_at_dumping is not null or cus.tariff_start_at_dumping is not null))
                        """);
            } else {
                sql.append("""
                            AND (cus.tariff = :tariff)
                        """);
                params.put("tariff", tariff);
            }

        }

        if (dateFrom != null && dateTo != null) {
            sql.append("""
                     AND ((cus.tariff_start_at IS NULL OR cus.tariff_start_at >= :dateFrom)
                         AND (cus.tariff_end_at IS NULL OR cus.tariff_end_at <= :dateTo))
                    AND ((cus.tariff_start_at_dumping IS NULL OR cus.tariff_start_at_dumping >= :dateFrom)
                         AND (cus.tariff_end_at_dumping IS NULL OR cus.tariff_end_at_dumping <= :dateTo))
                    """);
            params.put("dateFrom", dateFrom);
            params.put("dateTo", dateTo);
        }

        String dataSql = sql + " ORDER BY cus.id DESC LIMIT :limit OFFSET :offset";
        params.put("limit", pageable.getPageSize());
        params.put("offset", pageable.getOffset());

        List<Customer> customers = namedParameterJdbcTemplate.query(
                dataSql,
                params,
                new CustomerRowMapper()
        );

        String countSql = "SELECT COUNT(*) FROM (" + sql + ") AS count_query";

        Integer total = namedParameterJdbcTemplate.queryForObject(
                countSql,
                params,
                Integer.class
        );

        return new PageImpl<>(customers, pageable, total);
    }

    public Page<Customer> searchTrialCustomers(String forSearch, OffsetDateTime dateFrom,
                                               OffsetDateTime dateTo, Boolean active, Pageable pageable) {
        StringBuilder sql = new StringBuilder("""
            SELECT cus.*,
                   m.id         AS m_id,
                   m.username   AS m_username,
                   m.phone      AS m_phone,
                   m.email      AS m_email,
                   m.image_name AS m_image_name,
                   m.image_url  AS m_image_url
            FROM customer cus
            LEFT JOIN moderator m ON cus.admin_id = m.id
            WHERE cus.is_active = true
              AND cus.is_trial = true
            """);
        Map<String, Object> params = Maps.newHashMap();
        log.info("forSearch: {}", forSearch);

        if (forSearch != null && !forSearch.isBlank()) {
            sql.append("""
                    AND (
                        LOWER(cus.full_name) LIKE CONCAT('%', :searchName, '%')
                        OR LOWER(cus.last_name) LIKE CONCAT('%', :searchName, '%')
                        OR cus.phone LIKE CONCAT('%', :searchPhone, '%')
                    )
                    """);
            params.put("searchName", forSearch.toLowerCase());
            params.put("searchPhone", forSearch);
        }

        if (active != null) {
            sql.append("""
                        AND (
                            (:active = true AND COALESCE(cus.tariff_end_at_dumping, cus.tariff_end_at) >= CURRENT_TIMESTAMP)
                            OR
                            (:active = false AND COALESCE(cus.tariff_end_at_dumping, cus.tariff_end_at) < CURRENT_TIMESTAMP)
                        )
                    """);
            params.put("active", active);
        }

        if (dateFrom != null) {
            sql.append("""
                        AND ((cus.tariff_start_at IS NULL OR cus.tariff_start_at >= :dateFrom)
                             AND (cus.tariff_start_at_dumping IS NULL OR cus.tariff_start_at_dumping >= :dateFrom))
                    """);
            params.put("dateFrom", dateFrom);
        }

        if (dateTo != null) {
            sql.append("""
                        AND ((cus.tariff_end_at IS NULL OR cus.tariff_end_at <= :dateTo)
                             AND (cus.tariff_end_at_dumping IS NULL OR cus.tariff_end_at_dumping <= :dateTo))
                    """);
            params.put("dateTo", dateTo);
        }

        String dataSql = sql + " ORDER BY cus.id DESC LIMIT :limit OFFSET :offset";
        params.put("limit", pageable.getPageSize());
        params.put("offset", pageable.getOffset());

        List<Customer> customers = namedParameterJdbcTemplate.query(
                dataSql,
                params,
                new CustomerRowMapper()
        );

        String countSql = "SELECT COUNT(*) FROM (" + sql + ") AS count_query";

        Integer total = namedParameterJdbcTemplate.queryForObject(countSql, params, Integer.class);

        return new PageImpl<>(customers, pageable, total);
    }
}
