package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OrderStatus {

    // kaspi
    APPROVED_BY_BANK("Одобрен банком", "Банкпен мақұлданған"),
    ACCEPTED_BY_MERCHANT("Принят продавцом", "Сатушы қабылдады"),
    COMPLETED("Завершён", "Аяқталған"),
    CANCELLED("Отменён", "Бас тартылды"),
    CANCELLING("Отменяется", "Бас тартылуда"),
    KASPI_DELIVERY_RETURN_REQUESTED("Запрос на возврат", "Қайтаруға өтініш"),
    RETURNED("Возвращён", "Қайтарылды"),

    // наши (накладные)
    PACKING("Упаковка", "Қапталуда"),
    ASSEMBLE_REQUESTED("Формирование накладной", "Жүкқұжат жасалуда"),
    WAYBILL_PENDING("Ожидание накладной", "Жүкқұжат күтілуде"),
    WAYBILL_READY("Накладная готова", "Жүкқұжат дайын");

    private final String name;
    private final String nameKz;
}