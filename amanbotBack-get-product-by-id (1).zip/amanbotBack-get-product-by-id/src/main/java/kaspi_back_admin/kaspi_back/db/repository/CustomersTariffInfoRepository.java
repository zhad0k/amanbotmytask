package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.CustomersTariffInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CustomersTariffInfoRepository extends JpaRepository<CustomersTariffInfo, Long> {
    @Query("SELECT info FROM CustomersTariffInfo info WHERE info.customer.id = :customerId and info.isActive is true")
    List<CustomersTariffInfo> getAllByCustomerId(Long customerId);
}
