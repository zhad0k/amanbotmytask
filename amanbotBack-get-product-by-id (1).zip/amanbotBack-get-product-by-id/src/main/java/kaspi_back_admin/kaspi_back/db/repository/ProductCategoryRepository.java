package kaspi_back_admin.kaspi_back.db.repository;


import kaspi_back_admin.kaspi_back.db.entities.ProductCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductCategoryRepository extends JpaRepository<ProductCategory, Long> {
    @Query("FROM ProductCategory p WHERE p.code = :code")
    Optional<ProductCategory> findByCode(@Param("code") String code);

    Optional<ProductCategory> findByTitle(String title);
}