package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ModeratorRepository extends JpaRepository<Moderator, Long> {
    @Query(value = """
    SELECT m.phone
    FROM moderator m
    WHERE m.role = 'ROLE_MANAGER'
""", nativeQuery = true)
    List<String> findAllManagerPhone();

    @Query("SELECT moder FROM Moderator moder WHERE moder.phone = :phone")
    Optional<Moderator> findByPhone(String phone);

    @Query(value = """
        SELECT m
        FROM Moderator m
        WHERE m.role = 'ROLE_ADMIN'
        order by m.id
""")
    List<Moderator> findAllAdmins();

    @Query(value = """
        SELECT m
        FROM Moderator m
        WHERE m.isActive = true
        AND m.role = 'ROLE_ADMIN'
        ORDER BY m.createdDate ASC
        
""")
    Page<Moderator> findAllAdminsPage(Pageable pageable);
}
