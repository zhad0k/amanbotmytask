package kaspi_back_admin.kaspi_back.db.enums;

public enum Role {
    ROLE_CLIENT,
    ROLE_ADMIN,
    ROLE_MANAGER,
    ROLE_LEAD_ADMIN
}
