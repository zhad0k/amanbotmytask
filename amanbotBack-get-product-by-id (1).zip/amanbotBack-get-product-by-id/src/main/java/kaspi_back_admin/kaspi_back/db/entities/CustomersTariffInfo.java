package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "customers_tariff_info")
public class CustomersTariffInfo extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="customer_tariff_info_id")
    @SequenceGenerator(name = "customer_tariff_info_id", sequenceName = "customer_tariff_info_id", allocationSize = 1)
    private Long id;

    @JoinColumn(name = "customer_id")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Enumerated(EnumType.STRING)
    @Column(name = "tariff", nullable = false)
    private TariffType tariffType;

    @JoinColumn(name = "period_id")
    @ManyToOne
    private Period period;

    @Column(name = "expires_at")
    private OffsetDateTime expiresAt;

    @Column(name = "is_active")
    private Boolean isActive;


}
