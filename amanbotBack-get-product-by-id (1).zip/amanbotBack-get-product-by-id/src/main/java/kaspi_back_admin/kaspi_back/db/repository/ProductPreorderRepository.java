package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.ProductPreorder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProductPreorderRepository extends JpaRepository<ProductPreorder, Long> {
    @Query("""
           SELECT p FROM ProductPreorder p
           WHERE p.productId = :productId
             AND p.deleted = false
           """)
    List<ProductPreorder> findActiveByProduct(Long productId);


    @Query("""
           select p
           from ProductPreorder p
           where p.productId = :productId
             and p.deleted = false
           """)
    List<ProductPreorder> findByProductIdAndDeletedFalse(@Param("productId") Long productId);

    // Поиск по point + cityId (точный, для продуктов с несколькими городами)
    @Query("""
           select p from ProductPreorder p
           where p.productId = :productId
             and p.productStock.point = :point
             and p.productStock.cityId = :cityId
             and p.deleted = false
           """)
    Optional<ProductPreorder> findByProductIdAndPointAndCityIdAndDeletedFalse(
            @Param("productId") Long productId,
            @Param("point") String point,
            @Param("cityId") String cityId);

    // Fallback: поиск только по point (если cityId не передан)
    @Query("""
           select p
           from ProductPreorder p
           where p.productId = :productId
             and p.productStock.storeId like CONCAT('%', :point)
             and p.deleted = false
           """)
    Optional<ProductPreorder> findByProductIdAndPointAndDeletedFalse(@Param("productId") Long productId,
                                                             @Param("point") String point);

    @Query("""
           SELECT p
           FROM ProductPreorder p
           WHERE p.processed = false
             AND p.deleted = false
           """)
    List<ProductPreorder> findPending();

    @Query("""
        select pp
        from ProductPreorder pp
            join Product p on p.id = pp.productId
        where p.customer.id = :customerId
          and p.id in :productIds
          and pp.deleted = false
        """)
    List<ProductPreorder> findByCustomerIdAndProductIdIn(@Param("customerId") Long customerId,
                                                         @Param("productIds") Collection<Long> productIds);

    @Query("""
    select pp
    from ProductPreorder pp
        join Product p on p.id = pp.productId
    where p.customer.id = :customerId
      and p.id in :productIds
      and pp.deleted = false
      and pp.id = (
          select max(pp2.id)
          from ProductPreorder pp2
          where pp2.productId = pp.productId
            and pp2.deleted = false
      )
    """)
    List<ProductPreorder> findOnePerProduct(
            @Param("customerId") Long customerId,
            @Param("productIds") Collection<Long> productIds);

}
