package kaspi_back_admin.kaspi_back.db.enums;

public enum ReviewMoment {
    WHEN_SHIPPED,
    WHEN_DELIVERING,
    WHEN_RECEIVED
}
