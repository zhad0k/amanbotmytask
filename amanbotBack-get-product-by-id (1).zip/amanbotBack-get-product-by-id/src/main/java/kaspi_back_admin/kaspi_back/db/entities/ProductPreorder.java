package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(
    name = "product_preorder",
    indexes = {
        @Index(name = "idx_product_preorder_product_deleted", columnList = "product_id, deleted"),
        @Index(name = "idx_product_preorder_pending",         columnList = "deleted, processed")
    }
)
public class ProductPreorder extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "preorder_days")
    private Integer preorderDays;

    @Column(name = "preorder_count")
    private Integer preorderCount;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_stock_id")
    private ProductStock productStock;

    @Column(name = "processed", nullable = false)
    private boolean processed;

    @Column(name = "processed_date")
    private OffsetDateTime processedDate;

    @Column(name = "deleted", nullable = false)
    private boolean deleted;

    @Column(name = "deleted_date")
    private OffsetDateTime deletedDate;
}