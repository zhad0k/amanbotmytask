package kaspi_back_admin.kaspi_back.db.repository;

import jakarta.transaction.Transactional;
import kaspi_back_admin.kaspi_back.db.entities.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Transactional
public interface ReviewRepository extends JpaRepository<Review, Long> {
    Review findReviewByIdAndCustomerId(Long id, Long customerId);
    List<Review> getReviewsByCustomerId(Long customerId);
}
