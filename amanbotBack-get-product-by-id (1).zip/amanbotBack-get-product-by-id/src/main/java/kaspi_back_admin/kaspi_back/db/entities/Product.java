package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.BatchSize;

import java.util.ArrayList;
import java.util.List;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(
        name = "product",
        indexes = {
                @Index(name = "idx_product_customer_id",      columnList = "customer_id"),
                @Index(name = "idx_product_customer_available", columnList = "customer_id, available"),
                @Index(name = "idx_product_customer_price_auto", columnList = "customer_id, price_auto_change")
        }
)
public class Product extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="product_id")
    @SequenceGenerator(name = "product_id", sequenceName = "product_id", allocationSize = 1)
    private Long id;

    @OneToMany(mappedBy = "product", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<ProductPrice> productPrices;

    private String title;
    private String masterSku;
    private String sku;

    private String photoUrl;
    private Long price;
    private Long currentPricePlace;
    private Long targetPricePlace;
    private Long minPrice;
    private Long maxPrice;
    private Long currentPrice;
    private String code;
    private boolean available;
    private boolean priceAutoChange;

    @Column(name = "deactivated_by_mass_toggle", columnDefinition = "boolean default false")
    private Boolean deactivatedByMassToggle = false;


    //  private Long reservedRemainders;
    private Long soldRemainders;
    private Long calculatedRemainders;

    @Column(name = "product_card_long_url", columnDefinition = "TEXT")
    private String productCardLongUrl;
    private String availabilities;
    private String place;
    private String allPlaces;

    @Column(name = "url_image")
    private String urlImage;
    private Double rating;
    private String brand;

    private String cityId;
    private String cityName;

    private String masterCategory;
    private String categoryCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    private Customer customer;

//  @ElementCollection(fetch = FetchType.EAGER)
//  @CollectionTable(
//          name = "product_points",
//          joinColumns = @JoinColumn(name = "product_id")
//  )

//  @ElementCollection(fetch = FetchType.LAZY)
//  @CollectionTable(
//          name = "product_reserved_points",
//          joinColumns = @JoinColumn(name = "product_id")
//  )
//  @Column(name = "stock_count", nullable = false)
//  @OrderColumn(name = "idx")
//  private List<Long> reservedRemainderPoints;

    @BatchSize(size = 50)
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductStock> stocks = new ArrayList<>();

}