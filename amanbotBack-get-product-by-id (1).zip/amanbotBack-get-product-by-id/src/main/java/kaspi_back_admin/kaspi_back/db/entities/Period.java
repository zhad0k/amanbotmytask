package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "period")
public class Period {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="period_id")
    @SequenceGenerator(name = "period_id", sequenceName = "period_id", allocationSize = 1)
    private Long id;
    private String name;
    private Integer periodInMonths;
}
