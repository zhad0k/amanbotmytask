package kaspi_back_admin.kaspi_back.db.enums;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.service.impl.CustomerService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.OffsetDateTime;

public enum SearchType {
    DAMPING {
        @Override
        public Page<Customer> search(CustomerService service, String forSearch, Boolean active,
                                     TariffType tariffType, OffsetDateTime from, OffsetDateTime to,
                                     Long managerId, Pageable pageable) {
            return service.search(forSearch, active, tariffType, from, to, managerId, pageable);
        }

        @Override
        public OffsetDateTime getStartDate(Customer customer) {
            return customer.getTariffStartAt();
        }

        @Override
        public OffsetDateTime getEndDate(Customer customer) {
            return customer.getTariffEndAt();
        }

        @Override
        public OffsetDateTime getStartDateDumping(Customer customer) {
            return customer.getTariffStartAtDumping();
        }

        @Override
        public OffsetDateTime getEndDateDumping(Customer customer) {
            return customer.getTariffEndAtDumping();
        }

        @Override
        public Integer getActiveSlots(Customer customer) {
            return customer.getTariffType() != null ?
                    customer.getTariffType().getTier().getMaxInclusive() : 0;
        }

        @Override
        public void applyStartDate(Customer customer, OffsetDateTime from) {
            customer.setTariffStartAtDumping(from);
        }

        @Override
        public void applyEndDate(Customer customer, OffsetDateTime to) {
            customer.setTariffEndAtDumping(to);
        }

        @Override
        public Long getIdInstance(Customer customer) {
            return customer.getIdInstance();
        }

        @Override
        public String getKaspiMerchantEmail(Customer customer) {
            return customer.getKaspiEmailMerchant();
        }

        @Override
        public String getKaspiMerchantPassword(Customer customer) {
            return customer.getKaspiPasswordMerchant();
        }

        @Override
        public String getDumpingTariff(Customer customer) {
            return "";
        }
    },
    NOTIFICATION {
        @Override
        public Page<Customer> search(CustomerService service, String forSearch, Boolean active,
                                     TariffType tariffType, OffsetDateTime from, OffsetDateTime to,
                                     Long managerId, Pageable pageable) {
            return service.searchNotification(forSearch, active, tariffType, from, to, managerId, pageable);
        }

        @Override
        public OffsetDateTime getStartDate(Customer customer) {
            return customer.getTariffStartAt();
        }

        @Override
        public OffsetDateTime getEndDate(Customer customer) {
            return customer.getTariffEndAt();
        }

        @Override
        public OffsetDateTime getStartDateDumping(Customer customer) {
            return customer.getTariffStartAtDumping();
        }

        @Override
        public OffsetDateTime getEndDateDumping(Customer customer) {
            return customer.getTariffEndAtDumping();
        }

        @Override
        public Integer getActiveSlots(Customer customer) {
            return 0;
        }


        @Override
        public void applyStartDate(Customer customer, OffsetDateTime from) {
            customer.setTariffStartAt(from);
        }

        @Override
        public void applyEndDate(Customer customer, OffsetDateTime to) {
            customer.setTariffEndAt(to);
        }

        @Override
        public Long getIdInstance(Customer customer) {
            return customer.getIdInstance();
        }

        @Override
        public String getKaspiMerchantEmail(Customer customer) {
            return customer.getKaspiEmailMerchant();
        }

        @Override
        public String getKaspiMerchantPassword(Customer customer) {
            return customer.getKaspiPasswordMerchant();
        }

        @Override
        public String getDumpingTariff(Customer customer) {
            return "";
        }
    },
    VIP {
        @Override
        public Page<Customer> search(CustomerService service, String forSearch, Boolean active,
                TariffType tariffType, OffsetDateTime from, OffsetDateTime to,
                Long managerId, Pageable pageable) {
            return service.searchVip(forSearch, active, tariffType, from, to, managerId, pageable);
        }

        @Override
        public OffsetDateTime getStartDate(Customer customer) {
            return customer.getTariffStartAt();
        }

        @Override
        public OffsetDateTime getEndDate(Customer customer) {
            return customer.getTariffEndAt();
        }

        @Override
        public OffsetDateTime getStartDateDumping(Customer customer) {
            return customer.getTariffStartAtDumping();
        }

        @Override
        public OffsetDateTime getEndDateDumping(Customer customer) {
            return customer.getTariffEndAtDumping();
        }

        @Override
        public Integer getActiveSlots(Customer customer) {
            return customer.getTariffType() != null ?
                    customer.getTariffType().getTier().getMaxInclusive() : 0;
        }

        @Override
        public void applyStartDate(Customer customer, OffsetDateTime from) {
            customer.setTariffStartAtDumping(from);
        }

        @Override
        public void applyEndDate(Customer customer, OffsetDateTime to) {
            customer.setTariffEndAtDumping(to);
        }

        @Override
        public Long getIdInstance(Customer customer) {
            return customer.getIdInstance();
        }

        @Override
        public String getKaspiMerchantEmail(Customer customer) {
            return customer.getKaspiEmailMerchant();
        }

        @Override
        public String getKaspiMerchantPassword(Customer customer) {
            return customer.getKaspiPasswordMerchant();
        }

        @Override
        public String getDumpingTariff(Customer customer) {
            TariffType tariffType = customer.getTariffType();
            String base = "";
            if (tariffType != null) {
                if (tariffType.name().contains("UP_TO")) {
                    base = "Dumping до ";
                    return base + tariffType.getTier().getMaxInclusive();
                } else {
                    base = "Dumping от ";
                    return base + (tariffType.getTier().getMinInclusive() - 1);
                }
            }
            return base;
        }
    },
    TRIAL {
        @Override
        public Page<Customer> search(CustomerService service, String forSearch, Boolean active,
                                     TariffType tariffType, OffsetDateTime from, OffsetDateTime to,
                                     Long managerId, Pageable pageable) {
            return service.getAllTrial(forSearch, from, to, active, managerId, pageable);
        }

        @Override
        public OffsetDateTime getStartDate(Customer customer) {
            return customer.getTariffStartAtDumping() != null ? customer.getTariffStartAtDumping() : customer.getTariffStartAt();
        }

        @Override
        public OffsetDateTime getEndDate(Customer customer) {
            return customer.getTariffEndAtDumping() != null ? customer.getTariffEndAtDumping() : customer.getTariffEndAt();
        }

        @Override
        public OffsetDateTime getStartDateDumping(Customer customer) {
            return customer.getTariffStartAtDumping() != null ? customer.getTariffStartAtDumping() : customer.getTariffStartAt();
        }

        @Override
        public OffsetDateTime getEndDateDumping(Customer customer) {
            return customer.getTariffEndAtDumping() != null ? customer.getTariffEndAtDumping() : customer.getTariffEndAt();
        }

        @Override
        public Integer getActiveSlots(Customer customer) {
            return 10000;
        }

        @Override
        public void applyStartDate(Customer customer, OffsetDateTime from) {
            customer.setTariffStartAtDumping(from);
        }

        @Override
        public void applyEndDate(Customer customer, OffsetDateTime to) {
            customer.setTariffEndAtDumping(to);
        }

        @Override
        public Long getIdInstance(Customer customer) {
            return customer.getIdInstance();
        }

        @Override
        public String getKaspiMerchantEmail(Customer customer) {
            return customer.getKaspiEmailMerchant();
        }

        @Override
        public String getKaspiMerchantPassword(Customer customer) {
            return customer.getKaspiPasswordMerchant();
        }

        @Override
        public String getDumpingTariff(Customer customer) {
            if (customer.getTariffStartAtDumping() != null) {
                return "trial";
            }
            return "";
        }
    };

    public abstract Page<Customer> search(CustomerService customerService, String forSearch, Boolean active,
                                          TariffType tariffType, OffsetDateTime from, OffsetDateTime to,
                                          Long managerId, Pageable pageable);

    public abstract OffsetDateTime getStartDate(Customer customer);
    public abstract OffsetDateTime getEndDate(Customer customer);
    public abstract OffsetDateTime getStartDateDumping(Customer customer);
    public abstract OffsetDateTime getEndDateDumping(Customer customer);
    public abstract Integer getActiveSlots(Customer customer);
    public abstract void applyStartDate(Customer customer, OffsetDateTime from);
    public abstract void applyEndDate(Customer customer, OffsetDateTime to);
    public abstract Long getIdInstance(Customer customer);
    public abstract String getKaspiMerchantEmail(Customer customer);
    public abstract String getKaspiMerchantPassword(Customer customer);
    public abstract String getDumpingTariff(Customer customer);
}
