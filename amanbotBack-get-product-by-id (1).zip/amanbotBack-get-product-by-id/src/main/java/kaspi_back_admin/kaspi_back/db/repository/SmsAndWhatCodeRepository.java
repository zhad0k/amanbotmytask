package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.SmsAndWhatCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SmsAndWhatCodeRepository extends JpaRepository<SmsAndWhatCode,Long> {

    @Query("SELECT CASE WHEN COUNT(s) > 0 THEN true ELSE false END FROM SmsAndWhatCode s WHERE s.phone = :phone AND s.code = :smsCode")
    boolean existsByPhoneAndCode(@Param("phone")String phone, @Param("smsCode") String smsCode);
}
