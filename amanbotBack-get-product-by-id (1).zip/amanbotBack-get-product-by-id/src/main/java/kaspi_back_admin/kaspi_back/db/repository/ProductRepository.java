package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.Product;
import kaspi_back_admin.kaspi_back.db.repository.projections.StatisticsRow;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {
    // сортировка обязательна так как ломается на фронте логика
    @Query(value = """
       SELECT * FROM product p
       WHERE p.customer_id = :customerId
         AND (:active IS NULL OR p.available = :active)
         AND (:dampingActive IS NULL OR p.price_auto_change = :dampingActive)
         AND (CAST(:search AS TEXT) IS NULL OR POSITION(LOWER(:search) IN LOWER(p.title)) > 0)
       """,
            nativeQuery = true)
    Page<Product> findAllProductByCustomerId(Long customerId,
                                      Boolean active,
                                      Boolean dampingActive,
                                      @Param("search") String search,
                                      Pageable pageable);

    @Query("""
        SELECT p
        FROM Product p
        WHERE p.customer.id = :customerId
          AND (:active IS NULL OR p.available = :active)
          AND (:dampingActive IS NULL OR p.priceAutoChange = :dampingActive)
          AND (:title IS NULL OR LOWER(p.title) LIKE LOWER(CONCAT('%', :title, '%')))
        ORDER BY p.title ASC
    """)
    Page<Product> findAllByCustomerId(
            @Param("customerId") Long customerId,
            @Param("title") String title,
            @Param("active") Boolean active,
            @Param("dampingActive") Boolean dampingActive,
            Pageable pageable
    );

    @Query("""
        select distinct p
        from Product p
        left join fetch p.stocks
        where p in :products
        """)
    List<Product> fetchStocks(@Param("products") List<Product> products);
    // сортировка обязательна так как ломается на фронте логика
    @Query("""
        SELECT p
        FROM Product p
        WHERE p.customer.id = :customerId
        AND (:active IS NULL OR p.available = :active)
        AND (:dampingActive IS NULL OR p.priceAutoChange = :dampingActive)
        AND LOWER(p.title) LIKE LOWER(CONCAT('%',:title,'%'))
        """)
    Page<Product> findAllByCustomerIdAndTitle(Long customerId, String title, Boolean active, Boolean dampingActive, Pageable pageable);

    @Query("SELECT count(p) FROM Product p WHERE p.customer.id = :id AND p.available IS TRUE AND p.priceAutoChange IS TRUE")
    Long getActiveCountOfProductsForCustomer(Long id);

    @Query("SELECT p FROM Product p WHERE p.customer.id = :customerId AND p.id = :productId")
    Optional<Product> findByIdAndCustomerId(Long customerId, Long productId);

    @Query(
      value = """
      SELECT p
      FROM Product p
      JOIN p.customer c
      WHERE c.id = :customerId
      AND (:availableOnly = false OR p.available = true)
      AND (:preorderOnly = false OR EXISTS (
            SELECT 1 FROM ProductPreorder pp
            WHERE pp.productId = p.id AND pp.deleted = false
      ))
      AND (:dampingFilter = false OR (
            p.priceAutoChange = true
        AND c.tariffType IN (
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UNLIMITED,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UNLIMITED,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UNLIMITED,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UNLIMITED
        )
        AND c.tariffEndAtDumping IS NOT NULL
        AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP
      ))
      AND (:reviewsFilter = false OR (
            c.tariffType IN (
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC_PLUS,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO_PLUS,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_50,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_200,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_500,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UNLIMITED,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_50,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_200,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_500,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UNLIMITED
            )
        AND c.tariffEndAt IS NOT NULL
        AND c.tariffEndAt >= CURRENT_TIMESTAMP
      ))
      AND (:noBotsFilter = false OR (
              c.tariffType IS NULL
           OR c.tariffEndAt IS NULL
           OR c.tariffEndAt < CURRENT_TIMESTAMP
      ))
      AND (:forSearch IS NULL OR :forSearch = ''
           OR LOWER(p.title) LIKE LOWER(CONCAT('%', :forSearch, '%'))
           OR LOWER(p.sku) LIKE LOWER(CONCAT('%', :forSearch, '%'))
           OR LOWER(p.masterSku) LIKE LOWER(CONCAT('%', :forSearch, '%')))
      ORDER BY
        CASE WHEN :triggeredSort = true AND NOT EXISTS (
          SELECT 1 FROM ProductStock ps WHERE ps.product.id = p.id
          AND ps.stock IS NOT NULL AND ps.minimalStock IS NOT NULL
          AND ps.stock <= ps.minimalStock
          AND ps.action <> kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction.NONE
        ) THEN 1 ELSE 0 END ASC,
        CASE WHEN :lowStockSort = true THEN
          (SELECT MIN(ps2.stock) FROM ProductStock ps2 WHERE ps2.product.id = p.id AND ps2.stock IS NOT NULL)
        ELSE NULL END ASC NULLS LAST
      """,
      countQuery = """
      SELECT COUNT(p)
      FROM Product p
      JOIN p.customer c
      WHERE c.id = :customerId
      AND (:availableOnly = false OR p.available = true)
      AND (:preorderOnly = false OR EXISTS (
            SELECT 1 FROM ProductPreorder pp
            WHERE pp.productId = p.id AND pp.deleted = false
      ))
      AND (:dampingFilter = false OR (
            p.priceAutoChange = true
        AND c.tariffType IN (
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UNLIMITED,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UNLIMITED,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UNLIMITED,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_50,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_200,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_500,
              kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UNLIMITED
        )
        AND c.tariffEndAtDumping IS NOT NULL
        AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP
      ))
      AND (:reviewsFilter = false OR (
            c.tariffType IN (
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC_PLUS,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO_PLUS,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_50,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_200,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_500,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UNLIMITED,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_50,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_200,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_500,
                kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UNLIMITED
            )
        AND c.tariffEndAt IS NOT NULL
        AND c.tariffEndAt >= CURRENT_TIMESTAMP
      ))
      AND (:noBotsFilter = false OR (
              c.tariffType IS NULL
           OR c.tariffEndAt IS NULL
           OR c.tariffEndAt < CURRENT_TIMESTAMP
      ))
      AND (:forSearch IS NULL OR :forSearch = ''
           OR LOWER(p.title) LIKE LOWER(CONCAT('%', :forSearch, '%'))
           OR LOWER(p.sku) LIKE LOWER(CONCAT('%', :forSearch, '%'))
           OR LOWER(p.masterSku) LIKE LOWER(CONCAT('%', :forSearch, '%')))
      """
    )
    Page<Product> findPreorderProducts(
            Long customerId,
            boolean availableOnly,
            boolean preorderOnly,
            boolean dampingFilter,
            boolean reviewsFilter,
            boolean noBotsFilter,
            String forSearch,
            boolean lowStockSort,
            boolean triggeredSort,
            Pageable pageable
    );
    @Query("""
        SELECT
            COUNT(p) AS total,
            COALESCE(SUM(CASE WHEN p.available = TRUE AND p.priceAutoChange = TRUE THEN 1 ELSE 0 END), 0) AS active,
            COALESCE(SUM(CASE WHEN p.available = TRUE AND p.priceAutoChange = FALSE THEN 1 ELSE 0 END), 0) AS inactive,
            COALESCE(SUM(CASE WHEN p.available = FALSE THEN 1 ELSE 0 END), 0) AS archive
        FROM Product p
        WHERE p.customer.id = :customerId
        """)
    List<Object[]> aggregateCountForCustomer(Long customerId);

    @Query(
            value = """
                    WITH agg AS (
                      SELECT
                        e.offer_code,
                        SUM(CASE WHEN o.status = ANY (ARRAY['RETURNED','KASPI_DELIVERY_RETURN_REQUESTED']) THEN 1 ELSE 0 END) AS returned_count,
                        SUM(CASE WHEN o.status = ANY (ARRAY['CANCELLED','CANCELLING']) THEN 1 ELSE 0 END)                     AS cancelled_count,
                        SUM(CASE WHEN o.status <> ALL (ARRAY['RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED']) THEN 1 ELSE 0 END) AS sells_count,
                        SUM(CASE WHEN o.status <> ALL (ARRAY['RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED']) THEN e.total_price ELSE 0 END) AS sells_sum
                      FROM order_entries e
                      JOIN orders o ON o.id = e.order_id
                      WHERE o.customer_id = :customerId
                        AND o.creation_date BETWEEN :fromDate AND :toDate
                      GROUP BY e.offer_code
                    ),
                    products AS (
                      SELECT
                        p.id, p.title, p.code, p.price_auto_change AS active, p.available, p.product_card_long_url AS url,
                        COALESCE(p.url_image, '') AS imageUrl, COALESCE(p.rating, 0.0) AS rating
                      FROM product p
                      WHERE p.customer_id = :customerId
                        AND p.title ILIKE CONCAT('%', :forSearch, '%')
                    )
                    SELECT
                      t.id, t.title, t.code, t.active, t.available, t.url, t.imageUrl, t.rating, t.sellsCount, t.sellsSum,
                      t.returnedCount, t.cancelledCount
                    FROM (
                      SELECT
                        pr.id, pr.title, pr.code, pr.active, pr.available, pr.url, pr.imageUrl, pr.rating,
                        COALESCE(ag.sells_count, 0) AS sellsCount, COALESCE(ag.sells_sum, 0) AS sellsSum,
                        COALESCE(ag.returned_count, 0) AS returnedCount, COALESCE(ag.cancelled_count, 0)   AS cancelledCount
                      FROM products pr
                      LEFT JOIN agg ag ON ag.offer_code = pr.code
                    
                      UNION ALL
                    
                      SELECT
                        NULL::bigint AS id, '(Без карточки продукта)' AS title, ag.offer_code AS code,
                        FALSE AS active, FALSE AS available, NULL AS url, '' AS imageUrl, 0.0 AS rating,
                        ag.sells_count AS sellsCount, ag.sells_sum AS sellsSum, ag.returned_count AS returnedCount,
                        ag.cancelled_count AS cancelledCount
                      FROM agg ag
                      LEFT JOIN products pr ON pr.code = ag.offer_code
                      WHERE pr.id IS NULL
                        AND '(Без карточки продукта)' ILIKE CONCAT('%', :forSearch, '%')
                    ) t
                    WHERE t.available = :available
                    ORDER BY COALESCE(t.sellsCount, 0) DESC, COALESCE(t.returnedCount, 0) DESC,
                                                 COALESCE(t.cancelledCount, 0) DESC, COALESCE(t.code, '') ASC
                    """,
            countQuery = """
                    WITH agg AS (
                      SELECT
                        e.offer_code,
                        SUM(CASE WHEN o.status = ANY (ARRAY['RETURNED','KASPI_DELIVERY_RETURN_REQUESTED']) THEN 1 ELSE 0 END) AS returned_count,
                        SUM(CASE WHEN o.status = ANY (ARRAY['CANCELLED','CANCELLING']) THEN 1 ELSE 0 END)                     AS cancelled_count,
                        SUM(CASE WHEN o.status <> ALL (ARRAY['RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED']) THEN 1 ELSE 0 END) AS sells_count,
                        SUM(CASE WHEN o.status <> ALL (ARRAY['RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED']) THEN e.total_price ELSE 0 END) AS sells_sum
                      FROM order_entries e
                      JOIN orders o ON o.id = e.order_id
                      WHERE o.customer_id = :customerId
                        AND o.creation_date BETWEEN :fromDate AND :toDate
                      GROUP BY e.offer_code
                    ),
                    products AS (
                      SELECT
                        p.id, p.title, p.code, p.price_auto_change AS active, p.available,
                        p.product_card_long_url AS url, COALESCE(p.url_image, '') AS imageUrl, COALESCE(p.rating, 0.0) AS rating
                      FROM product p
                      WHERE p.customer_id = :customerId
                        AND p.title ILIKE CONCAT('%', :forSearch, '%')
                    )
                    SELECT COUNT(1)
                    FROM (
                      SELECT
                        pr.id, pr.title, pr.code, pr.active, pr.available, pr.url, pr.imageUrl,
                        pr.rating, COALESCE(ag.sells_count, 0) AS sellsCount, COALESCE(ag.sells_sum, 0) AS sellsSum,
                        COALESCE(ag.returned_count, 0) AS returnedCount, COALESCE(ag.cancelled_count, 0) AS cancelledCount
                      FROM products pr
                      LEFT JOIN agg ag ON ag.offer_code = pr.code
                    
                      UNION ALL
                    
                      SELECT
                        NULL::bigint AS id, '(Без карточки продукта)' AS title,
                        ag.offer_code AS code, FALSE AS active, FALSE AS available,
                        NULL AS url, '' AS imageUrl, 0.0 AS rating,
                        ag.sells_count AS sellsCount, ag.sells_sum AS sellsSum,
                        ag.returned_count AS returnedCount, ag.cancelled_count AS cancelledCount
                      FROM agg ag
                      LEFT JOIN products pr ON pr.code = ag.offer_code
                      WHERE pr.id IS NULL
                        AND '(Без карточки продукта)' ILIKE CONCAT('%', :forSearch, '%')
                    ) t
                    WHERE t.available = :available
                    """
            , nativeQuery = true
    )
    Page<StatisticsRow> findAllWithFullStats(Long customerId, String forSearch, boolean available, OffsetDateTime fromDate,
            OffsetDateTime toDate, Pageable pageable);

    List<Product> findAllByIdInAndCustomerId(List<Long> ids, Long customerId);
    List<Product> findAllByCustomerId(Long customerId);

    // Для накладных: подтянуть карточки товаров по offerCode (= Product.code)
    List<Product> findByCustomerIdAndCodeIn(Long customerId, java.util.Collection<String> codes);

    @Query("""
            SELECT FUNCTION('DATE', o.creationDate),
                   COUNT(e.id),
                   SUM(e.totalPrice)
            FROM Order o
            JOIN OrderEntry e ON o.id = e.order.id
            JOIN Product p ON p.code = e.offerCode
            WHERE o.customer.id = :customerId
              AND p.id = :productId
              AND o.status NOT IN ('RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED')
              AND o.creationDate BETWEEN :fromDate AND :toDate
            GROUP BY FUNCTION('DATE', o.creationDate)
            ORDER BY FUNCTION('DATE', o.creationDate)
            """)
    List<Object[]> getCustomerProductDailyStatistics(
            Long customerId,
            Long productId,
            OffsetDateTime fromDate,
            OffsetDateTime toDate
    );

    @Query("""
            SELECT FUNCTION('DATE', FUNCTION('DATE_TRUNC','month', o.creationDate)),
                   COUNT(o.id),
                   SUM(e.totalPrice)
            FROM Order o
            JOIN OrderEntry e ON o.id = e.order.id
            JOIN Product p ON p.code = e.offerCode
            WHERE o.customer.id = :customerId
              AND p.id = :productId
              AND o.status NOT IN ('RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED')
              AND o.creationDate BETWEEN :fromDate AND :toDate
            GROUP BY FUNCTION('DATE', FUNCTION('DATE_TRUNC','month', o.creationDate))
            ORDER BY FUNCTION('DATE', FUNCTION('DATE_TRUNC','month', o.creationDate))
            """)
    List<Object[]> getCustomerProductMonthlyStatistics(
            Long customerId, Long productId,
            OffsetDateTime fromDate, OffsetDateTime toDate
    );
    @Query("""
    SELECT p
    FROM Product p
    WHERE p.customer.id = :customerId
      AND p.available = true
      AND p.priceAutoChange = true
""")
    List<Product> findAllActiveByCustomerId(@Param("customerId") Long customerId);

    @Query("""
    SELECT p
    FROM Product p
    WHERE p.customer.id = :customerId
      AND p.priceAutoChange = false
      AND p.deactivatedByMassToggle = true
""")
    List<Product> findAllMassDeactivatedByCustomerId(@Param("customerId") Long customerId);
    @Query("""
        SELECT
            COUNT(o.id),
            SUM(e.totalPrice)
        FROM Product p
        JOIN OrderEntry e ON p.code = e.offerCode
        JOIN Order o ON o.id = e.order.id
        WHERE o.customer.id = :customerId
          AND p.id = :productId
          AND o.status NOT IN ('RETURNED','CANCELLED','CANCELLING','KASPI_DELIVERY_RETURN_REQUESTED')
          AND o.creationDate BETWEEN :fromDate AND :toDate
        """)
    List<Object[]> getCustomerProductSales(Long customerId, Long productId, OffsetDateTime fromDate, OffsetDateTime toDate);
}



