package kaspi_back_admin.kaspi_back.db.repository;


import jakarta.transaction.Transactional;
import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public interface CustomerRepository extends JpaRepository<Customer,Long> {


    Customer findByPhone(String phone);

    boolean existsByPhone(String phone);

    @Query("SELECT cus FROM Customer cus WHERE cus.phone =:username")
    Optional<Customer> findByUsername(String username);

    @Query("""
        SELECT DISTINCT c
        FROM Customer c
        LEFT JOIN FETCH c.products
        WHERE c.id = :id
    """)
    Optional<Customer> findByIdWithProducts(@Param("id") Long id);

    @Query
    ("""
        SELECT cus
        FROM Customer cus
        WHERE cus.tokenProd IS NOT NULL
        AND :today BETWEEN cus.tariffStartAt AND cus.tariffEndAt
        AND cus.idInstance is not null
        ORDER BY cus.createdDate DESC
    """)
    List<Customer> findAllWithProdTokenTariff( @Param("today") OffsetDateTime today);


    @Query
            ("""
        SELECT cus
        FROM Customer cus
        WHERE cus.tokenProd IS NOT NULL
        AND :today BETWEEN cus.tariffStartAt AND cus.tariffEndAt
        AND cus.idInstance is not null
        ORDER BY cus.createdDate DESC
    """)
    List<Customer> findAllWithProdTokenTariffNotTokenGreenApi( @Param("today") OffsetDateTime today);


 
    @Query("SELECT cus FROM Customer cus WHERE cus.id in (292,293)")
    List<Customer> findCustomersByIdsIn();

    @Query("""
        SELECT c
        FROM Customer c
        LEFT JOIN c.moderator m
        WHERE
             c.isActive is true
            AND (c.isTrial IS NULL OR c.isTrial = false)
            AND ((:active IS NULL)
            OR (:active = true AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP)
            OR (:active = false AND (
              c.tariffStartAtDumping IS NULL
              or c.tariffEndAtDumping IS NULL
              or c.tariffEndAtDumping < CURRENT_TIMESTAMP)))
            AND ((:tariffType IS NOT NULL AND c.tariffType = :tariffType)
                 OR (:tariffType is null and c.tariffType in (
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_50,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_200,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_500,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UNLIMITED,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_50,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_200,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_500,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UNLIMITED,
                         
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_50_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_200_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UP_TO_500_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_UNLIMITED_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_50_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_200_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UP_TO_500_NOTIFICATION_FREE,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.DAMPING_PRO_UNLIMITED_NOTIFICATION_FREE
                 )))
              AND (cast(:endDateFrom as timestamp) IS NULL OR c.tariffStartAtDumping >= :endDateFrom)
              AND (cast(:endDateTo as timestamp)   IS NULL OR c.tariffEndAtDumping <= :endDateTo)
              AND ((:managerId IS NULL OR :managerId = 0) OR m.id = :managerId)
              AND (coalesce(:forSearch, '') = '' OR c.phone LIKE concat('%', :forSearch, '%')
                       OR LOWER(c.ipName) LIKE LOWER(concat('%', :forSearch, '%')))
              ORDER BY c.id DESC
    """)
    Page<Customer> search(String forSearch, Boolean active, TariffType tariffType,
                          OffsetDateTime endDateFrom, OffsetDateTime endDateTo, Long managerId,
                          Pageable pageable
    );

    @Query("""
        SELECT c
        FROM Customer c
        LEFT JOIN c.moderator m
        WHERE 
            c.isActive is true 
            AND (c.isTrial IS NULL OR c.isTrial = false)
            AND ((:active IS NULL)
            OR (:active = true AND c.tariffEndAt >= CURRENT_TIMESTAMP)
            OR (:active = false AND (
              c.tariffStartAt IS NULL
              or c.tariffEndAt IS NULL
              or c.tariffEndAt < CURRENT_TIMESTAMP)))
            AND ((:tariffType IS NOT NULL AND c.tariffType = :tariffType)
                 OR (:tariffType is null and c.tariffType in (
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC_PLUS,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO_PLUS,
             
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_FREE_DUMPING_FREE,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC_DUMPING_FREE,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_BASIC_PLUS_DUMPING_FREE,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO_DUMPING_FREE,
                         kaspi_back_admin.kaspi_back.db.enums.TariffType.NOTIFICATION_PRO_PLUS_DUMPING_FREE
                 )))
              AND (cast(:from as timestamp) IS NULL OR c.tariffStartAt >= :from)
              AND (cast(:to as timestamp) IS NULL OR c.tariffEndAt <= :to)
              AND ((:managerId IS NULL OR :managerId = 0) OR m.id = :managerId)
              AND (coalesce(:forSearch, '') = '' OR c.phone LIKE concat('%', :forSearch, '%')
                       OR LOWER(c.ipName) LIKE LOWER(concat('%', :forSearch, '%')))
              ORDER BY c.id DESC
    """)
    Page<Customer> searchNotification(String forSearch, Boolean active, TariffType tariffType,
                                      OffsetDateTime from, OffsetDateTime to, Long managerId,
                                      Pageable pageable);

    @Query("""
        SELECT c
        FROM Customer c
        LEFT JOIN c.moderator m
        WHERE 
            c.isActive is true
            AND (c.isTrial IS NULL OR c.isTrial = false)
            AND ((:active IS NULL)
            AND (c.isTrial IS NULL OR c.isTrial = false)
            OR (:active = true AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP)
            OR (:active = false AND (
              c.tariffStartAtDumping IS NULL
              or c.tariffEndAtDumping IS NULL
              or c.tariffEndAtDumping < CURRENT_TIMESTAMP)))
            AND ((:tariffType IS NOT NULL AND c.tariffType = :tariffType)
                 OR (:tariffType IS NULL and c.tariffType in (
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_50,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_200,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UP_TO_500,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_UNLIMITED,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_50,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_200,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UP_TO_500,
                     kaspi_back_admin.kaspi_back.db.enums.TariffType.VIP_COMBO_UNLIMITED
                    )))
              AND (cast(:from as timestamp) IS NULL OR c.tariffStartAtDumping >= :from)
              AND (cast(:to as timestamp) IS NULL OR c.tariffEndAtDumping <= :to)
              AND ((:managerId IS NULL OR :managerId = 0) OR m.id = :managerId)
              AND (coalesce(:forSearch, '') = '' OR c.phone LIKE concat('%', :forSearch, '%')
                       OR LOWER(c.ipName) LIKE LOWER(concat('%', :forSearch, '%')))
              ORDER BY c.id DESC
    """)
    Page<Customer> searchVip(String forSearch, Boolean active, TariffType tariffType,
                             OffsetDateTime from, OffsetDateTime to, Long managerId,
                             Pageable pageable);

    @Query("""
        SELECT c
        FROM Customer c
        LEFT JOIN c.moderator m
        WHERE c.isActive is true
          AND c.isTrial = true
          AND ((:active IS NULL)
            OR (:active = true AND coalesce(c.tariffEndAtDumping, c.tariffEndAt) >= CURRENT_TIMESTAMP)
            OR (:active = false AND (
              coalesce(c.tariffEndAtDumping, c.tariffEndAt) IS NULL
              OR coalesce(c.tariffEndAtDumping, c.tariffEndAt) < CURRENT_TIMESTAMP)))
          AND (cast(:from as timestamp) IS NULL OR (
              (c.tariffStartAt IS NULL OR c.tariffStartAt >= :from)
              AND (c.tariffStartAtDumping IS NULL OR c.tariffStartAtDumping >= :from)))
          AND (cast(:to as timestamp) IS NULL OR (
              (c.tariffEndAt IS NULL OR c.tariffEndAt <= :to)
              AND (c.tariffEndAtDumping IS NULL OR c.tariffEndAtDumping <= :to)))
          AND ((:managerId IS NULL OR :managerId = 0) OR m.id = :managerId)
          AND (coalesce(:forSearch, '') = '' OR LOWER(c.fullName) LIKE LOWER(concat('%', :forSearch, '%'))
                   OR LOWER(c.lastName) LIKE LOWER(concat('%', :forSearch, '%'))
                   OR c.phone LIKE concat('%', :forSearch, '%'))
          ORDER BY c.id DESC
    """)
    Page<Customer> searchTrial(String forSearch, Boolean active,
                               OffsetDateTime from, OffsetDateTime to, Long managerId,
                               Pageable pageable);



    Optional<Customer> findByIdInstanceOrFullNameContains(Long idInstance, String name);
    @Query("""
    SELECT c FROM Customer c
    WHERE (
        (:filter = 'ALL'
            AND (c.isTrial IS NULL OR c.isTrial = false))
        OR
        (:filter = 'ACTIVE'
            AND (c.isTrial IS NULL OR c.isTrial = false)
            AND (
                (
                    c.tariffStartAt IS NOT NULL
                    AND c.tariffEndAt IS NOT NULL
                    AND c.tariffStartAt <= CURRENT_TIMESTAMP
                    AND c.tariffEndAt >= CURRENT_TIMESTAMP
                )
                OR
                (
                    c.tariffStartAtDumping IS NOT NULL
                    AND c.tariffEndAtDumping IS NOT NULL
                    AND c.tariffStartAtDumping <= CURRENT_TIMESTAMP
                    AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP
                )
            ))
        OR
        (:filter = 'INACTIVE'
            AND (c.isTrial IS NULL OR c.isTrial = false)
            AND (
                c.isActive = false
                OR NOT (
                    (
                        c.tariffStartAt IS NOT NULL
                        AND c.tariffEndAt IS NOT NULL
                        AND c.tariffStartAt <= CURRENT_TIMESTAMP
                        AND c.tariffEndAt >= CURRENT_TIMESTAMP
                    )
                    OR
                    (
                        c.tariffStartAtDumping IS NOT NULL
                        AND c.tariffEndAtDumping IS NOT NULL
                        AND c.tariffStartAtDumping <= CURRENT_TIMESTAMP
                        AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP
                    )
                )
            ))
        OR
        (:filter = 'ACTIVE_TEST'
            AND c.isActive = true
            AND c.isTrial = true
            AND (
                (
                    c.tariffStartAt IS NOT NULL
                    AND c.tariffEndAt IS NOT NULL
                    AND c.tariffStartAt <= CURRENT_TIMESTAMP
                    AND c.tariffEndAt >= CURRENT_TIMESTAMP
                )
                OR
                (
                    c.tariffStartAtDumping IS NOT NULL
                    AND c.tariffEndAtDumping IS NOT NULL
                    AND c.tariffStartAtDumping <= CURRENT_TIMESTAMP
                    AND c.tariffEndAtDumping >= CURRENT_TIMESTAMP
                )
            ))
      )
      AND (
            cast(:dateFrom as timestamp) IS NULL
            OR c.tariffStartAt >= :dateFrom
            OR c.tariffStartAtDumping >= :dateFrom
      )
      AND (
            cast(:dateTo as timestamp) IS NULL
            OR c.tariffEndAt <= :dateTo
            OR c.tariffEndAtDumping <= :dateTo
      )
      AND (
            :forSearch IS NULL
            OR :forSearch = ''
            OR c.phone LIKE CONCAT('%', :forSearch, '%')
            OR LOWER(c.fullName) LIKE LOWER(CONCAT('%', :forSearch, '%'))
            OR LOWER(c.lastName) LIKE LOWER(CONCAT('%', :forSearch, '%'))
            OR LOWER(c.ipName) LIKE LOWER(CONCAT('%', :forSearch, '%'))
      )
    ORDER BY
        CASE
            WHEN :filter = 'ACTIVE' AND c.isActive = true THEN 0
            WHEN :filter = 'ACTIVE' AND (c.isActive = false OR c.isActive IS NULL) THEN 1
            ELSE 0
        END ASC
    """)
    Page<Customer> findAllByFilter(
            @Param("filter") String filter,
            @Param("forSearch") String forSearch,
            @Param("dateFrom") OffsetDateTime dateFrom,
            @Param("dateTo") OffsetDateTime dateTo,
            Pageable pageable
    );
}
