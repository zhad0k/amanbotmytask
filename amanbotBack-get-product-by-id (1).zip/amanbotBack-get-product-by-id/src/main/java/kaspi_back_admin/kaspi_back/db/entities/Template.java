package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "templates")
public class Template {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="templates_id")
    @SequenceGenerator(name = "templates_id", sequenceName = "templates_id", allocationSize = 1)
    private Long id;

    @JoinColumn(name = "customer_id")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "value",columnDefinition = "TEXT")
    private String value;

    @Column(name = "value_kz",columnDefinition = "TEXT")
    private String valueKz;

    @Enumerated(EnumType.STRING)
    private SyncType type;
}
