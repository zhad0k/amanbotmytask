package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.CustomerLiteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CustomerLiteEntityRepository extends JpaRepository<CustomerLiteEntity,Long> {

    @Query("SELECT cli FROM CustomerLiteEntity cli WHERE cli.cellPhone = :phone")
    CustomerLiteEntity findByCellPhone(String phone);
}
