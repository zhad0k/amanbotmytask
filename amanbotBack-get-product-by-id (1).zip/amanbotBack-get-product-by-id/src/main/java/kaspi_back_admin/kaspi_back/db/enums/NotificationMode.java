package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum NotificationMode {
    NONE(0), // Режим, когда уведомления полностью отключены
    NEW_ORDERS(1), // Режим для уведомлений о новых заказах
    DELIVERED_ORDERS(2), // Режим для уведомлений о доставленных заказах
    ALL(NEW_ORDERS.mask | DELIVERED_ORDERS.mask); // Режим, включающий все уведомления (новые + доставленные)

    private final int mask;

    /**
     * Проверяет, включен ли указанный режим в текущем.
     * Пример: ALL.has(NEW_ORDERS) вернет true.
     */
    public boolean has(NotificationMode mode) {
        return (this.mask & mode.mask) != 0;
    }

    /**
     * Включает указанный режим в текущем и возвращает новый NotificationMode.
     * Пример: NONE.enable(NEW_ORDERS) → NEW_ORDERS
     */
    public NotificationMode enable(NotificationMode mode) {
        return fromMask(this.mask | mode.mask);
    }

    /**
     * Отключает указанный режим в текущем и возвращает новый NotificationMode.
     * Пример: ALL.disable(NEW_ORDERS) → DELIVERED_ORDERS
     */
    public NotificationMode disable(NotificationMode mode) {
        return fromMask(this.mask & ~mode.mask);
    }

    /**
     * Создает NotificationMode по переданной битовой маске.
     * Если точного совпадения нет, возвращает NONE.
     */
    public static NotificationMode fromMask(int mask) {
        for (NotificationMode value : values()) {
            if (value.mask == mask) {
                return value;
            }
        }
        return NONE;
    }
}
