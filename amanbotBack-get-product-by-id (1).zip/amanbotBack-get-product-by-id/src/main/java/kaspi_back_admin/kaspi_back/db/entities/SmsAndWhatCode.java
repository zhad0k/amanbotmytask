package kaspi_back_admin.kaspi_back.db.entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "sms_what_code")
public class SmsAndWhatCode {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="sms_code_id")
    @SequenceGenerator(name = "sms_code_id", sequenceName = "sms_code_id", allocationSize = 1)
    private Long id;

    private Integer code;
    private String phone;

    @Column(name = "used")
    private Boolean used;

}
