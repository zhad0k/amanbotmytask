package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import kaspi_back_admin.kaspi_back.db.enums.ReviewMoment;
import kaspi_back_admin.kaspi_back.db.enums.ReviewStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "kaspi_reviews",
        indexes = {
                @Index(name = "idx_kaspi_reviews_order_id", columnList = "order_id"),
                @Index(name = "idx_kaspi_reviews_order_entry_id", columnList = "order_entry_id"),
                @Index(name = "idx_kaspi_reviews_customer_id", columnList = "customer_id")
        })
public class KaspiReview extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "kaspi_reviews_id")
    @SequenceGenerator(name = "kaspi_reviews_id", sequenceName = "kaspi_reviews_id", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_entry_id")
    private OrderEntry orderEntry;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "sent_at")
    private OffsetDateTime sentAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "kaspi_moment")
    private ReviewMoment kaspiMoment;

    @Column(name = "kaspi_message_text", columnDefinition = "text")
    private String kaspiMessageText;

    @Column(name = "kaspi_clicked")
    private Boolean kaspiClicked;

    @Enumerated(EnumType.STRING)
    @Column(name = "kaspi_status")
    private ReviewStatus kaspiStatus;
}
