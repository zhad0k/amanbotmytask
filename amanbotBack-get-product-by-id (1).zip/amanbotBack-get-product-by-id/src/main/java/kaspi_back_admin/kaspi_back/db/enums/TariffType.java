package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TariffType {
    // NOTIFICATION
    NOTIFICATION_FREE     (Kind.NOTIFICATION, null,  "Пробный",     0),
    NOTIFICATION_BASIC (Kind.NOTIFICATION, null,  "Notification Basic", 14999),
    NOTIFICATION_BASIC_PLUS  (Kind.NOTIFICATION, null,  "Notification Basic Plus",  19999),
    NOTIFICATION_PRO (Kind.NOTIFICATION, null,  "Notification Pro", 24999),
    NOTIFICATION_PRO_PLUS  (Kind.NOTIFICATION, null,  "Notification Pro Plus",  29999),

    // DAMPING
    DAMPING_UP_TO_50   (Kind.DAMPING,  ProductTier.UP_TO_50,   "Damping До 50 товаров",    9999),
    DAMPING_UP_TO_200  (Kind.DAMPING,  ProductTier.UP_TO_200,  "Damping До 200 товаров",   14999),
    DAMPING_UP_TO_500  (Kind.DAMPING,  ProductTier.UP_TO_500,  "Damping До 500 товаров",   19999),
    DAMPING_UNLIMITED  (Kind.DAMPING,  ProductTier.UNLIMITED,  "Damping Безлимит",         32499),

    DAMPING_PRO_UP_TO_50   (Kind.DAMPING,  ProductTier.UP_TO_50,   "Damping Pro До 50 товаров",    19999),
    DAMPING_PRO_UP_TO_200  (Kind.DAMPING,  ProductTier.UP_TO_200,  "Damping Pro До 200 товаров",   24999),
    DAMPING_PRO_UP_TO_500  (Kind.DAMPING,  ProductTier.UP_TO_500,  "Damping Pro До 500 товаров",   29999),
    DAMPING_PRO_UNLIMITED  (Kind.DAMPING,  ProductTier.UNLIMITED,  "Damping Pro Безлимит",         42999),

    // VIP (Damping + Notification пакет)
    VIP_UP_TO_50   (Kind.VIP,   ProductTier.UP_TO_50,   "VIP до 50",    49999),
    VIP_UP_TO_200  (Kind.VIP,   ProductTier.UP_TO_200,  "VIP до 200",   64999),
    VIP_UP_TO_500  (Kind.VIP,   ProductTier.UP_TO_500,  "VIP до 500",   104999),
    VIP_UNLIMITED  (Kind.VIP,   ProductTier.UNLIMITED,  "VIP Безлимит", 157999),

    VIP_COMBO_UP_TO_50   (Kind.VIP,   ProductTier.UP_TO_50,   "VIP Combo Plus до 50",    59999),
    VIP_COMBO_UP_TO_200  (Kind.VIP,   ProductTier.UP_TO_200,  "VIP Combo Plus до 200",   74999),
    VIP_COMBO_UP_TO_500  (Kind.VIP,   ProductTier.UP_TO_500,  "VIP Combo Plus до 500",   114999),
    VIP_COMBO_UNLIMITED  (Kind.VIP,   ProductTier.UNLIMITED,  "VIP Combo Plus Безлимит", 167999),

    // NOTIFICATION + DAMPING (пробный период)
    NOTIFICATION_FREE_DUMPING_FREE  (Kind.NOTIFICATION_DAMPING, ProductTier.UNLIMITED,  "Notification Пробный + Dumping Пробный",     0),
    NOTIFICATION_BASIC_DUMPING_FREE  (Kind.NOTIFICATION_DAMPING, ProductTier.UNLIMITED,  "Notification Basic + Dumping Пробный", 14999),
    NOTIFICATION_BASIC_PLUS_DUMPING_FREE  (Kind.NOTIFICATION_DAMPING, ProductTier.UNLIMITED,  "Notification Basic Plus + Dumping Пробный", 19999),
    NOTIFICATION_PRO_DUMPING_FREE  (Kind.NOTIFICATION_DAMPING, ProductTier.UNLIMITED,  "Notification Pro  + Dumping Пробный",  24999),
    NOTIFICATION_PRO_PLUS_DUMPING_FREE  (Kind.NOTIFICATION_DAMPING, ProductTier.UNLIMITED,  "Notification Pro Plus + Dumping Пробный",  29999),

    // DAMPING + NOTIFICATION (пробный период)
    DAMPING_UP_TO_50_NOTIFICATION_FREE    (Kind.DAMPING_NOTIFICATION,  ProductTier.UP_TO_50,   "Dumping До 50 товаров + Notification Пробный",    9999),
    DAMPING_UP_TO_200_NOTIFICATION_FREE   (Kind.DAMPING_NOTIFICATION,  ProductTier.UP_TO_200,  "Dumping До 200 товаров + Notification Пробный",   14999),
    DAMPING_UP_TO_500_NOTIFICATION_FREE   (Kind.DAMPING_NOTIFICATION,  ProductTier.UP_TO_500,  "Dumping До 500 товаров + Notification Пробный",   19999),
    DAMPING_UNLIMITED_NOTIFICATION_FREE   (Kind.DAMPING_NOTIFICATION,  ProductTier.UNLIMITED,  "Dumping Безлимит + Notification Пробный",         32499),

    DAMPING_PRO_UP_TO_50_NOTIFICATION_FREE  (Kind.DAMPING_NOTIFICATION,  ProductTier.UP_TO_50,   "Damping Pro До 50 товаров + Notification Пробный",    19999),
    DAMPING_PRO_UP_TO_200_NOTIFICATION_FREE  (Kind.DAMPING_NOTIFICATION,  ProductTier.UP_TO_200,  "Damping Pro До 200 товаров + Notification Пробный",   24999),
    DAMPING_PRO_UP_TO_500_NOTIFICATION_FREE  (Kind.DAMPING_NOTIFICATION,  ProductTier.UP_TO_500,  "Damping Pro До 500 товаров + Notification Пробный",   29999),
    DAMPING_PRO_UNLIMITED_NOTIFICATION_FREE  (Kind.DAMPING_NOTIFICATION,  ProductTier.UNLIMITED,  "Damping Pro Безлимит + Notification Пробный",         42999);


    @AllArgsConstructor @Getter
    public enum Kind {
        DAMPING("Dumping Bot", "Мониторит цены конкурентов " +
                "Автоматически корректирует вашу цену " +
                "Удерживает оптимальную позицию в выдаче"),
        NOTIFICATION("Notification Bot", "Следит за отзывами и рейтингом в режиме реального времени " +
                "Мгновенно уведомляет о любых изменениях " +
                "Автоматически запрашивает отзывы у клиентов"),
        VIP("VIP", "Объединённая система Notification Bot (Premium) и Dumping Bot " +
                "Анализирует конкурентов и корректирует цену, чтобы удерживать выгодную позицию."),
        NOTIFICATION_DAMPING("Notification + Dumping Bot",
                "Покупка Notification Bot с пробным периодом Dumping Bot"),
        DAMPING_NOTIFICATION("Dumping + Notification Bot",
                "Покупка Dumping Bot с пробным периодом Notification Bot");

        private final String displayName;
        private final String description;
    }

    @AllArgsConstructor @Getter
    public enum ProductTier {
        UP_TO_50  (0,    50),
        UP_TO_200 (51,   200),
        UP_TO_500 (201,  500),
        UNLIMITED (501,  Integer.MAX_VALUE);
        private final int minInclusive;
        private final int maxInclusive;
    }

    @AllArgsConstructor @Getter
    public enum BillingPlan {
        ONE_MONTH("1 месяц",    1,  1),
        THREE_PLUS_ONE("3+1",   3,  4),
        SIX_PLUS_TWO("6+2",     6,  8),
        NINE_PLUS_THREE("9+3",  9, 12),
        TWO_PLUS_ONE("2+1",     2,  3),
        FOUR_PLUS_TWO("4+2",4,6);

        private final String label;
        private final int monthsToPay;
        private final int totalMonths;

        public long priceToPay(long monthlyPriceKzt) {
            return monthlyPriceKzt * (long) monthsToPay;
        }
        public long priceIfPaidMonthly(long monthlyPriceKzt) {
            return monthlyPriceKzt * (long) totalMonths;
        }
    }

    private final Kind kind;
    private final ProductTier tier;
    private final String displayName;
    private final long monthlyPriceKzt;
}