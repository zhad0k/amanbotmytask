package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.TelegramSubscription;
import kaspi_back_admin.kaspi_back.db.enums.TelegramNotificationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TelegramSubscriptionRepository extends JpaRepository<TelegramSubscription, Long> {

    Optional<TelegramSubscription> findBySubscriberChatIdAndType(
            Long chatId,
            TelegramNotificationType type
    );

    @Query("""
            SELECT ts
            FROM TelegramSubscription ts
            WHERE ts.type = :type
              AND ts.enabled = true
              AND ts.subscriber.isActive = true
            """)
    List<TelegramSubscription> findActiveSubscriptionsByType(TelegramNotificationType type);
}