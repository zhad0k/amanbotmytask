package kaspi_back_admin.kaspi_back.db.entities;



import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.List;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "merchant")
public class Merchant extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="merchant_id")
    @SequenceGenerator(name = "merchant_id", sequenceName = "merchant_id", allocationSize = 1)
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;



    private String name;

    private boolean isActive;
    private boolean enable_parsing;
    private OffsetDateTime tariffStartAt;
    private OffsetDateTime tariffEndAt;
    private Long subscriptionDays;
    private String login;
    private String password;
    private String token;
    private boolean priceAutoChange;
    private Long priceDifference;
    private Long pricePlace;
    private String competitors_to_exclude;
    private String xmlFilePath;



}
