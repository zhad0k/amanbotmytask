package kaspi_back_admin.kaspi_back.db.enums;

public enum DeliveryType {
    PICKUP, DELIVERY
}
