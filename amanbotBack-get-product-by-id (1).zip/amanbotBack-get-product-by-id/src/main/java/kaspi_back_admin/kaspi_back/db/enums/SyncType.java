package kaspi_back_admin.kaspi_back.db.enums;

public enum SyncType {
    NEW_ORDER,
    DELIVERED_COMPLETED
}