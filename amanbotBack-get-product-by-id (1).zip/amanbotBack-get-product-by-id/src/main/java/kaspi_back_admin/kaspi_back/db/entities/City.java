package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "city")
public class City {

    @Id
    @Column(name = "city_id")
    private String id;

    @Column(name = "city_name")
    private String name;
}