package kaspi_back_admin.kaspi_back.db.enums;

public enum NotifyStatus {
    REGISTER, PAYMENT
}
