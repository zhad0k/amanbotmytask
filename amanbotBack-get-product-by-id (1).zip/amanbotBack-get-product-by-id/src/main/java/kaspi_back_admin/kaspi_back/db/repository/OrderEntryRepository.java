package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.OrderEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface OrderEntryRepository extends JpaRepository<OrderEntry, Long> {
    Optional<OrderEntry> findByKaspiEntryId(String kaspiEntryId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update OrderEntry e set e.offerCode = :productCode where e.kaspiEntryId = :kaspiEntryId")
    void overwriteOfferCode(@Param("kaspiEntryId") String kaspiEntryId,
                           @Param("productCode") String productCode);

    @Query("""
        select e.weight
        from OrderEntry e
        where e.offerCode = :productCode
        order by e.createdAt desc
        limit 1
        """)
    Double getLastWeightByProductCode(String productCode);
}
