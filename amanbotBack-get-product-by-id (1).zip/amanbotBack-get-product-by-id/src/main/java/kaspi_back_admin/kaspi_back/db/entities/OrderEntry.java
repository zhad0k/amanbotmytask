package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.enums.UnitType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "order_entries",
        indexes = @Index(name = "idx_order_entries_order_id", columnList = "order_id"))
public class OrderEntry  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "order_entries_id")
    @SequenceGenerator(name = "order_entries_id", sequenceName = "order_entries_id", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @Column(name = "kaspi_entry_id", nullable = false, unique = true, length = 64)
    private String kaspiEntryId;

    private Integer entryNumber;

    @Enumerated(EnumType.STRING)
    private UnitType unitType;

    private Double quantity;
    private Double weight;

    private Double deliveryCost;
    private Double basePrice;
    private Double totalPrice;

    private String categoryCode;
    private String categoryTitle;

    private String offerCode;
    @Column(length = 512)
    private String offerName;

    private Boolean isImeiRequired;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;
}
