package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.NotificationPolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface NotificationPolicyRepository extends JpaRepository<NotificationPolicy, Long> {

    @Query("""
           select p
           from NotificationPolicy p
           where p.customerId = :customerId
             and p.enabled = true
           """)
    Optional<NotificationPolicy> findByCustomer(@Param("customerId") Long customerId);

    @Query("""
           select p from NotificationPolicy p
           where p.customerId = :customerId
           """)
    Optional<NotificationPolicy> findAnyByCustomerId(@Param("customerId") Long customerId);
}