package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;
import java.time.OffsetDateTime;

@Entity
@Table(name = "notification_policy",
        uniqueConstraints = @UniqueConstraint(columnNames = {"customer_id"}))
@Getter
@Setter
public class NotificationPolicy extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private LocalTime allowedFrom;
    private LocalTime allowedTo;
    private int daysMask;
    private boolean enabled = true;

    @Column(name = "deleted_date")
    private OffsetDateTime deletedDate;
}