package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PreorderFilterType {
    ALL("Все товары", "Барлық тауарлар"),
    DAMPING_ENABLED("Только с демпингом", "Тек демпингпен"),
    REVIEWS_ENABLED("Только с отзывами", "Тек пікірлері бар"),
    NO_BOTS("Без ботов", "Ботсыз");
    private final String name;
    private final String nameKz;
}