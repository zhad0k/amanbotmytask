package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepository extends JpaRepository<City, String> {
}