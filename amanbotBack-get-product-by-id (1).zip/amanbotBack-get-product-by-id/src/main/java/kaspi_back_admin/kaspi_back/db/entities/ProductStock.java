package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.enums.MinimalStockAction;
import lombok.*;

@Entity
@Table(
    name = "product_stock",
    indexes = {
        @Index(name = "idx_product_stock_product_id", columnList = "product_id")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductStock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String point;

    private String cityId;

    private Long stock;

    private String storeId;

    @Column(name = "minimal_stock")
    private Integer minimalStock;

    @Column(name = "stock_by_customer")
    private Integer stockByCustomer;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    private Boolean stockSpecified;

    @Builder.Default
    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private MinimalStockAction action = MinimalStockAction.NONE;
}