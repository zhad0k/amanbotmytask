package kaspi_back_admin.kaspi_back.db.entities;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "customer_lite")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerLiteEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "customer_lite_id")
    @SequenceGenerator(name = "customer_lite_id", sequenceName = "customer_lite_id", allocationSize = 1)
    private Long id;

    @Column(name = "kaspi_customer_id", length = 64, nullable = false)
    private String kaspiCustomerId;

    private String name;
    private String cellPhone;
    private String firstName;
    private String lastName;

    @OneToOne(mappedBy = "customerLite", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Order order;

    @Column(name = "is_permission_asked")
    private Boolean isPermissionAsked = false;

    @Column(name = "is_allowed_to_send")
    private Boolean isAllowedToSend = false;
}
