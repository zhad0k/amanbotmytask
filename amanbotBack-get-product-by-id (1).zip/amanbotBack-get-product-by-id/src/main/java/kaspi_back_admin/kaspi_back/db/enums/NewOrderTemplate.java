package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum NewOrderTemplate {


    START_RU("Здравствуйте, %s! 👋\nБлагодарим вас за покупку в магазине %s.\n\n"),
    ORDER_INFO_RU("Ваш заказ успешно оформлен и оплачен ✅\n\n📦 Товар: %s\n🔢 Количество: %s\n🆔 ID заказа: %s\n\n"),
    DELIVERY_INFO_RU("🚚 Доставка по адресу: %s\n🗓 Ориентировочная дата прибытия: %s\n\n"),
    FOOTER_RU("Просим вас ожидать доставку.\n\nСпасибо, что выбрали нас! 🙏\nС уважением, команда %s\n\n"),


    START_KZ("\n\nСәлеметсіз бе, %s! 👋\n%s дүкенінен сатып алғаныңызға алғыс айтамыз.\n\n"),
    ORDER_INFO_KZ("Сіздің тапсырысыңыз сәтті рәсімделіп, төлем қабылданды ✅\n\n📦 Тауар: %s\n🔢 Саны: %s\n🆔 Тапсырыс ID: %s\n\n"),
    DELIVERY_INFO_KZ("🚚 Жеткізу мекенжайы: %s\n🗓 Шамамен жеткізу күні: %s\n\n"),
    FOOTER_KZ("Тапсырысыңызды күтуіңізді сұраймыз.\n\nБізді таңдағаныңыз үшін рахмет! 🙏\nҚұрметпен, %s командасы");

    private final String text;
}

