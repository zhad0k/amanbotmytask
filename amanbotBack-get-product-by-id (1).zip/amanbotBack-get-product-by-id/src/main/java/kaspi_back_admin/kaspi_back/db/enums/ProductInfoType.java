//package kaspi_back_admin.kaspi_back.db.enums;
//
//public enum ProductInfoType {
//    DAMPING,
//    PREORDER,
//    INVENTORY;
//
//    public static ProductInfoType from(String value) {
//        if (value == null || value.isBlank()) {
//            throw new IllegalArgumentException("type is required");
//        }
//        return switch (value.trim().toLowerCase()) {
//            case "damping" -> DAMPING;
//            case "preorder" -> PREORDER;
//            case "inventory" -> INVENTORY;
//            default -> throw new IllegalArgumentException("Invalid type: " + value);
//        };
//    }
//}