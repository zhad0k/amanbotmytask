package kaspi_back_admin.kaspi_back.db.entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "kaspi_order_product")
public class KaspiOrderProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="kaspi_order_product_id")
    @SequenceGenerator(name = "kaspi_order_product_id", sequenceName = "kaspi_order_product_id", allocationSize = 1)
    private Long id;


    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "kaspi_order_id")
    private KaspiOrder kaspiOrder;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "kaspi_product_id")
    private Product kaspiProduct;


}
