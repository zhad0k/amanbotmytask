package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.enums.OrderState;
import kaspi_back_admin.kaspi_back.db.enums.OrderStatus;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "orders",
        indexes = {
                @Index(name = "idx_orders_code", columnList = "code")
        })
public class Order  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "orders_id")
    @SequenceGenerator(name = "orders_id", sequenceName = "orders_id", allocationSize = 1)
    private Long id;

    @Column(name = "kaspi_id", nullable = false, unique = true, length = 64)
    private String kaspiId;

    @Column(name = "code", nullable = false, unique = true, length = 64)
    private String code;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    private Double totalPrice;
    private Double deliveryCostForSeller;
    private Boolean isKaspiDelivery;
    private Boolean preOrder;
    private Boolean signatureRequired;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    @Enumerated(EnumType.STRING)
    private OrderState state;

    private String deliveryMode;
    private String paymentMode;

    private OffsetDateTime creationDate;
    private OffsetDateTime approvedByBankDate;
    private OffsetDateTime plannedDeliveryDate;
    private OffsetDateTime reservationDate;


    private String deliveryStreetName;
    private String deliveryStreetNumber;
    private String deliveryTown;
    private String deliveryDistrict;
    private String deliveryBuilding;
    private String deliveryApartment;
    @Column(length = 512)
    private String deliveryFormattedAddress;
    private Double deliveryLatitude;
    private Double deliveryLongitude;


    private String originPosId;
    private String originPosDisplayName;
    private String originCityCode;
    private String originCityName;


    @Column(columnDefinition = "text")
    private String waybillUrl;
    private String waybillNumber;
    private OffsetDateTime courierTransmissionDate;
    private OffsetDateTime courierTransmissionPlanDate;
    private Boolean kaspiExpress;
    private Boolean returnedToWarehouse;

    private Boolean assembled;

    @Column(name = "review_sent", nullable = false)
    private boolean reviewSent;

    @Column(name = "buy_notiffication", nullable = false)
    private boolean butNotification;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<OrderEntry> entries = new ArrayList<>();

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "customer_lite_id")
    private CustomerLiteEntity customerLite;
}
