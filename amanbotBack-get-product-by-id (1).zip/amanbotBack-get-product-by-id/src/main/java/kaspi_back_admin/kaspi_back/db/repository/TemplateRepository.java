package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.Template;
import kaspi_back_admin.kaspi_back.db.enums.SyncType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.EnumSet;
import java.util.List;


public interface TemplateRepository extends JpaRepository<Template, Long> {
    @Query("""
        SELECT t FROM Template t
        WHERE t.customer.id = :customerId
        and t.type = :type
""")
    Template findAllTemplatesByCustomerId(Long customerId, SyncType type);

    @Query("""
        SELECT t FROM Template t
        WHERE t.customer.id = 0
            and t.type = :type
        ORDER BY function('RANDOM')
        LIMIT 1
""")
    Template findRandomTemplate(@Param("type") SyncType type);

    @Query("""
        SELECT t
        FROM Template t
        WHERE t.customer.id = 0
        AND t.type = :type
""")
    List<Template> findAllByType(SyncType type);

    @Query("SELECT t FROM Template t WHERE t.type in :types and t.customer.id = 0 ORDER BY t.id DESC")
    List<Template> findAllByTypeIn(EnumSet<SyncType> types);
}
