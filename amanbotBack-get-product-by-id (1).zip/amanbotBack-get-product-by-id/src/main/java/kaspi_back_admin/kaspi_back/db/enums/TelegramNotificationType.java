package kaspi_back_admin.kaspi_back.db.enums;

public enum TelegramNotificationType {
    SMS_CODE("SMS code"),
    CONTACT_REQUESTS("Contact requests"),
    ORDERS("Orders"),
    STOCK("Stock"),
    ERRORS("Errors");

    private final String title;

    TelegramNotificationType(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}