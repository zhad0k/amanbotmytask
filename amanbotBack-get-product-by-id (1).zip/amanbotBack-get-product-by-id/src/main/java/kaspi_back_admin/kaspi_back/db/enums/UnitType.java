package kaspi_back_admin.kaspi_back.db.enums;

public enum UnitType {
    MEASURABLE_PIECES, MEASURABLE, PIECES
}
