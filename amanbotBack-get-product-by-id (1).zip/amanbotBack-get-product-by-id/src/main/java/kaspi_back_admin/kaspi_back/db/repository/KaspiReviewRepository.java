package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.KaspiReview;
import kaspi_back_admin.kaspi_back.db.enums.ReviewStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.OffsetDateTime;
import java.util.Collection;

public interface KaspiReviewRepository extends JpaRepository<KaspiReview, Long> {

    long countByCustomer_Id(Long customerId);
    long countByCustomer_IdAndKaspiStatus(Long customerId, ReviewStatus status);
    long countByCustomer_IdAndKaspiStatusIn(Long customerId, Collection<ReviewStatus> statuses);


    @Query("""
    SELECT COUNT(r)
    FROM KaspiReview r
    WHERE r.customer.id = :customerId
      AND r.sentAt >= :from
      AND r.sentAt <= :to
""")
    Long countByCustomerIdAndStatuses(
                                       @Param("customerId") Long customerId,
                                       @Param("from") OffsetDateTime from,
                                       @Param("to")   OffsetDateTime to
    );

    @Query("""
       SELECT r
       FROM KaspiReview r
       join fetch r.order o
       WHERE r.customer.id = :customerId
       ORDER BY r.createdDate DESC
       """)
    Page<KaspiReview> findDeliveredReviewsByCustomer(
            @Param("customerId") Long customerId,
            Pageable pageable
    );


    @Query("SELECT count(*) FROM KaspiReview kr WHERE kr.customer.moderator.id = :id")
    Long countReviewsByCustomerModerator(Long id);
}
