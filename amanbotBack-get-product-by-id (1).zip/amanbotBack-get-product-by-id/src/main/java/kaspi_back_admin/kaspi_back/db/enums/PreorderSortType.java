package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PreorderSortType {
    NEW("Сначала новые","Жаңа"),
    AVAILABLE("В наличии","Қоймада бар"),
    PREORDER("С предзаказом","Алдын ала тапсырыспен"),
    CHEAP("Дешёвые","Арзан"),
    EXPENSIVE("Дорогие","Қымбат"),
    LOW_STOCK("Мало остатка","Аз қалдық"),
    TRIGGERED("Правило сработало","Ереже іске қосылды");
    private final String name;
    private final String nameKz;
}