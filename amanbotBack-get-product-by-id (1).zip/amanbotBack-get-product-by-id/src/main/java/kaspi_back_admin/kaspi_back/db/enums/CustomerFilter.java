package kaspi_back_admin.kaspi_back.db.enums;

public enum CustomerFilter {
    ACTIVE,
    INACTIVE,
    ACTIVE_TEST,
    ALL
}