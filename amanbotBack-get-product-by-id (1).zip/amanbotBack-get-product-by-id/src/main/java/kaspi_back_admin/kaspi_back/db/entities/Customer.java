package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import kaspi_back_admin.kaspi_back.db.enums.NotificationMode;
import kaspi_back_admin.kaspi_back.db.enums.Role;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(
        name = "customer",
        indexes = {
                @Index(name = "idx_customer_tariff_type",columnList = "tariff")
        }
)
public class Customer extends BaseEntity implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="customers_id")
    @SequenceGenerator(name = "customers_id", sequenceName = "customers_id", allocationSize = 1)
    private Long id;

    private String fullName;
    private String lastName;
    private String iin;
    private String password;
    private String username;
    private String email;
    private String phone;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_manually_edited")
    private boolean isManuallyEdited;
    @Column(name = "id_code")
    private String idCode;
    @Enumerated(EnumType.STRING)
    @Column(name = "role",nullable = false)
    private Role role;

    @Column(name = "token_prod")
    private String tokenProd;

    @Column(name = "ip_name")
    private String ipName;
    private String kaspiEmail;
    private String kaspiPhone;
    private String kaspiPassword;
    private String merchantId;
    private BigDecimal balance;

    @Column(name = "has_kaspi_password")
    private Boolean hasKaspiMerchantPassword;
    @Column(name = "kaspi_password_merchant")
    private String kaspiPasswordMerchant;
    @Column(name = "kaspi_email_merchant")
    private String kaspiEmailMerchant;

    @Column(name = "tariff_start_at")
    private OffsetDateTime tariffStartAt;

    @Column(name = "tariff_end_at")
    private OffsetDateTime tariffEndAt;

    @Column(name = "tariff_start_at_dumping")
    private OffsetDateTime tariffStartAtDumping;

    @Column(name = "tariff_end_at_dumping")
    private OffsetDateTime tariffEndAtDumping;

    @Column(name = "is_preorder_enabled")
    private Boolean preorderEnabled;

    @Column(name = "is_inventory_enabled")
    private Boolean inventoryEnabled;

    @Column(name = "is_waybill_enabled")
    private Boolean waybillEnabled;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority(role.name()));
    }

    @Override
    public String getUsername() {
        return phone;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Enumerated(EnumType.STRING)
    @Column(name = "tariff", nullable = false)
    private TariffType tariffType;

    @JoinColumn(name = "period_id")
    @OneToOne(fetch = FetchType.LAZY)
    private Period period;

    @Column(name = "kaspi_review_message")
    private String kaspiReviewMessage;

    @Column(name = "whatsapp_phone")
    private String whatsappPhone;

    @JoinColumn(name = "admin_id")
    @ManyToOne(fetch = FetchType.LAZY)
    private Moderator moderator;

    @Column(name = "id_instance")
    private Long idInstance;

    @Column(name = "token_green_api")
    private String tokenGreenApi;

    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Merchant> merchant;


    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Comment> comments;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private NotificationMode notificationType = NotificationMode.ALL;

    @Column(name = "is_trial")
    private Boolean isTrial;
  
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Product> products;

    public void changeKaspiEmail(String email) {
        this.kaspiEmailMerchant = StringUtils.trimWhitespace(email);
    }

    public void changeKaspiMerchantId(String merchantId) {
        this.merchantId = StringUtils.trimWhitespace(merchantId);
    }

    public void changeKaspiPassword(String password) {
        this.kaspiPasswordMerchant = password;
        this.hasKaspiMerchantPassword = StringUtils.hasText(password);
    }

    public boolean hasExistingKaspiCredentials() {
        return StringUtils.hasText(kaspiEmailMerchant) ||
                StringUtils.hasText(kaspiPasswordMerchant) ||
                hasKaspiMerchantPassword;
    }
}

