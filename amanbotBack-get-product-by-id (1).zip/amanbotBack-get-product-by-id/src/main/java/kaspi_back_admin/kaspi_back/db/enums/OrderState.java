package kaspi_back_admin.kaspi_back.db.enums;

public enum OrderState {
    NEW, SIGN_REQUIRED, PICKUP, DELIVERY, KASPI_DELIVERY, ARCHIVE
}
