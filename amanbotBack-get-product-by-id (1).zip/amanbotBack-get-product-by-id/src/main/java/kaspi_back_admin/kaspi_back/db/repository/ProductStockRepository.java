package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.ProductStock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductStockRepository extends JpaRepository<ProductStock, Long> {

    // Поиск по point + cityId (точный, для продуктов с несколькими городами)
    @Query("""
        SELECT s FROM ProductStock s
        WHERE s.product.id = :productId
          AND s.point = :point
          AND s.cityId = :cityId
    """)
    Optional<ProductStock> findByProductIdAndPointAndCityId(
            @Param("point") String point,
            @Param("cityId") String cityId,
            @Param("productId") Long productId);

    // Fallback: поиск только по point (если cityId не передан)
    @Query("""
        SELECT s FROM ProductStock s
        WHERE s.product.id = :productId
          AND s.storeId LIKE CONCAT('%', :point)
    """)
    Optional<ProductStock> findStoreIdContainsForProduct(String point, Long productId);
}
