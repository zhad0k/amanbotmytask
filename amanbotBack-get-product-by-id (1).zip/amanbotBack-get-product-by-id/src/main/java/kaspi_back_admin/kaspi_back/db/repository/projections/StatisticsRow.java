package kaspi_back_admin.kaspi_back.db.repository.projections;

public interface StatisticsRow {
    Long getId();
    String getTitle();
    String getCode();
    Boolean getActive();
    Boolean getAvailable();
    String getUrl();
    String getImageUrl();
    Double getRating();
    Long getSellsCount();
    Double getSellsSum();
    Long getReturnedCount();
    Long getCancelledCount();
}
