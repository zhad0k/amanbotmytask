package kaspi_back_admin.kaspi_back.db.entities;

import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.enums.TelegramNotificationType;
import lombok.*;

@Entity
@Table(
        name = "telegram_subscription",
        uniqueConstraints = @UniqueConstraint(columnNames = {"subscriber_id", "type"})
)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TelegramSubscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private TelegramSubscriber subscriber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TelegramNotificationType type;

    @Column(nullable = false)
    private boolean enabled;
}