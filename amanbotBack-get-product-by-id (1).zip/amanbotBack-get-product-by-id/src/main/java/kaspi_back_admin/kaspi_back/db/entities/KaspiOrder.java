package kaspi_back_admin.kaspi_back.db.entities;


import jakarta.persistence.*;
import kaspi_back_admin.kaspi_back.db.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;
import java.util.List;


@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "kaspi_order")
public class KaspiOrder extends BaseEntity {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY,generator="kaspi_order_id")
    @SequenceGenerator(name = "kaspi_order_id", sequenceName = "kaspi_order_id", allocationSize = 1)
    private Long id;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "kaspi_order_id")
    private List<KaspiOrderProduct> kaspiOrderProducts;

    private Long orderId;
    private OffsetDateTime orderDate;
    private String orderType;
    private String orderStatus;
}
