package kaspi_back_admin.kaspi_back.db.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MinimalStockAction {
    NONE("Ничего не делать","Ештеңе істеме"),
    REMOVE_FROM_SALE("Снять с продажи","Сатылымнан алып тастау"),
    SET_PREORDER("Поставить на предзаказ","Алдын ала тапсырысқа қою"),
    RESET_STOCK("Восстановить остаток", "Қоймадағы қалдықты жаңарту");

    private final String title;
    private final String titleKz;
}