package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.Order;
import kaspi_back_admin.kaspi_back.db.enums.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> findByKaspiId(String kaspiId);

    @Query("""
        select count(o)
        from Order o
        where o.customer.id = :customerId
          and o.creationDate >= :from
          and o.creationDate <= :to
    """)
    long countByCustomerId(@Param("customerId") Long customerId,
                                                @Param("from") OffsetDateTime from,
                                                @Param("to")   OffsetDateTime to);

    List<Order> findByCustomerId(Long customerId);


    @Query("""
           select o
           from Order o
           where o.customer.id = :customerId
             and o.state <> kaspi_back_admin.kaspi_back.db.enums.OrderState.ARCHIVE
           order by o.creationDate desc
           """)
    List<Order> findNotArchivedByCustomerId(@Param("customerId") Long customerId);


    @Query("""
           select distinct o
           from Order o
           left join fetch o.entries e
           left join fetch o.customerLite cli
           where o.customer.id = :customerId
             and o.state = kaspi_back_admin.kaspi_back.db.enums.OrderState.ARCHIVE
             and o.status = kaspi_back_admin.kaspi_back.db.enums.OrderStatus.COMPLETED
             and o.reviewSent = false
           order by o.creationDate desc
           """)
    List<Order> findArchivedByCustomerId(@Param("customerId") Long customerId);

    @Query("""
           select distinct o
           from Order o
           left join fetch o.entries e
           left join fetch o.customerLite cli
           where o.customer.id = :customerId
             and o.status = kaspi_back_admin.kaspi_back.db.enums.OrderStatus.ACCEPTED_BY_MERCHANT
             and o.deliveryMode in ('DELIVERY_LOCAL', 'DELIVERY_REGIONAL_TODOOR','DELIVERY_PICKUP')
             and o.butNotification = false
           order by o.creationDate desc
           """)
    List<Order> findNewOrdersForNotification(@Param("customerId") Long customerId);

    @Query("SELECT count(o) FROM Order o WHERE o.customer.id = :id")
    long countAllByCustomerId(Long id);

    @Query("""
           SELECT o.creationDate
           FROM Order o
           WHERE o.customer.id = :id
           ORDER BY o.creationDate ASC
           LIMIT 1
           """)
    OffsetDateTime findEarliestDate(Long id);

    @Query("""
    SELECT o
    FROM Order o
    WHERE o.customer.id = :customerId
      AND o.status in :statuses
      AND o.isKaspiDelivery = true
      AND (:forSearch IS NULL OR :forSearch = '' OR LOWER(o.code) LIKE LOWER(CONCAT('%', :forSearch, '%')))
""")
    Page<Order> findKaspiDeliveryHandoverByCustomerId(
            @Param("customerId") Long customerId,
            @Param("statuses") Collection<OrderStatus> statuses,
            @Param("forSearch") String forSearch,
            Pageable pageable
    );

    // Заказы, готовые к передаче на сборку: реальный статус Kaspi ACCEPTED_BY_MERCHANT,
    // Kaspi-доставка, накладной ещё нет.
    @Query("""
           select o.code
           from Order o
           where o.customer.id = :customerId
             and o.status = kaspi_back_admin.kaspi_back.db.enums.OrderStatus.ACCEPTED_BY_MERCHANT
             and o.isKaspiDelivery = true
             and (o.waybillUrl is null or o.waybillUrl = '')
             and (:forSearch is null or :forSearch = '' or LOWER(o.code) like LOWER(CONCAT('%', :forSearch, '%')))
           """)
    List<String> findToAssembleWithoutWaybill(@Param("customerId") Long customerId,
                                              @Param("forSearch") String forSearch);

    long countByCustomerIdAndCodeIn(Long customerId, List<String> codes);
}
