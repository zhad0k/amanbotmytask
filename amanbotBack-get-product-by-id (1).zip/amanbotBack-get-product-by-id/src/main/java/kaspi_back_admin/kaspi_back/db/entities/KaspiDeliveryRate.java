package kaspi_back_admin.kaspi_back.db.entities;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;

import java.math.BigDecimal;

@Entity
@Table(
        name = "kaspi_delivery_rates",
        uniqueConstraints = @UniqueConstraint(
                name = "uq_delivery_rate",
                columnNames = {"condition_type", "min_value", "max_value_key", "tire_type"}
        )
)
public class KaspiDeliveryRate {

    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Getter
    @Enumerated(EnumType.STRING)
    @Column(name = "condition_type", nullable = false, length = 10)
    private ConditionType conditionType;

    @Getter
    @Column(name = "min_value", nullable = false, precision = 12, scale = 2)
    private BigDecimal minValue;

    @Getter
    @Column(name = "max_value", precision = 12, scale = 2)
    private BigDecimal maxValue;

    @Column(name = "max_value_key", nullable = false, precision = 12, scale = 2)
    private BigDecimal maxValueKey;

    @Getter
    @Enumerated(EnumType.STRING)
    @Column(name = "tire_type", nullable = false, length = 10)
    private TireType tireType;

    @Getter
    @Column(name = "price_city", nullable = false, precision = 10, scale = 2)
    private BigDecimal priceCity;

    @Getter
    @Column(name = "price_kz", nullable = false, precision = 10, scale = 2)
    private BigDecimal priceKz;

    @Getter
    @Column(name = "price_express", nullable = false, precision = 10, scale = 2)
    private BigDecimal priceExpress;

    @PrePersist
    @PreUpdate
    void syncMaxValueKey() {
        this.maxValueKey = (this.maxValue != null)
                ? this.maxValue
                : new BigDecimal("-1");
    }


    public enum ConditionType { AMOUNT, WEIGHT }
    public enum TireType      { NONE, CAR, TRUCK }

    protected KaspiDeliveryRate() {}

    public KaspiDeliveryRate(
            ConditionType conditionType,
            BigDecimal    minValue,
            BigDecimal    maxValue,
            TireType      tireType,
            BigDecimal    priceCity,
            BigDecimal    priceKz,
            BigDecimal    priceExpress
    ) {
        this.conditionType = conditionType;
        this.minValue      = minValue;
        this.maxValue      = maxValue;
        this.tireType      = tireType;
        this.priceCity     = priceCity;
        this.priceKz       = priceKz;
        this.priceExpress  = priceExpress;
        syncMaxValueKey();
    }

    public void updatePrices(BigDecimal city, BigDecimal kz, BigDecimal express) {
        this.priceCity    = city;
        this.priceKz      = kz;
        this.priceExpress = express;
    }
}