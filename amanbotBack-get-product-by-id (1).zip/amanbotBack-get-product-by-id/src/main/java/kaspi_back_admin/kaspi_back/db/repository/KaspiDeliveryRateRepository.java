package kaspi_back_admin.kaspi_back.db.repository;

import kaspi_back_admin.kaspi_back.db.entities.KaspiDeliveryRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.Optional;

public interface KaspiDeliveryRateRepository extends JpaRepository<KaspiDeliveryRate, Long> {
    @Query("""
        SELECT r FROM KaspiDeliveryRate r
        WHERE r.conditionType = :conditionType
          AND r.minValue      <= :amount
          AND r.maxValue      >  :amount
    """)
    Optional<KaspiDeliveryRate> findByAmount(
            @Param("amount") BigDecimal amount,
            @Param("conditionType") KaspiDeliveryRate.ConditionType conditionType
    );

    @Query("""
        SELECT r FROM KaspiDeliveryRate r
        WHERE r.conditionType = :conditionType
          AND r.tireType      = :tireType
          AND r.minValue      <= :weightKg
          AND (r.maxValue IS NULL OR r.maxValue > :weightKg)
    """)
    Optional<KaspiDeliveryRate> findByWeight(
            @Param("weightKg") BigDecimal weightKg,
            @Param("conditionType") KaspiDeliveryRate.ConditionType conditionType,
            @Param("tireType") KaspiDeliveryRate.TireType tireType
    );

    @Query("""
        SELECT r FROM KaspiDeliveryRate r
        WHERE r.conditionType = 'weight'
          AND r.tireType      = :tireType
          AND r.minValue      <= :weightKg
          AND (r.maxValue IS NULL OR r.maxValue > :weightKg)
    """)
    Optional<KaspiDeliveryRate> findByTire(
            @Param("conditionType") KaspiDeliveryRate.ConditionType conditionType,
            @Param("tireType")  KaspiDeliveryRate.TireType tireType,
            @Param("weightKg")  BigDecimal weightKg
    );
}
