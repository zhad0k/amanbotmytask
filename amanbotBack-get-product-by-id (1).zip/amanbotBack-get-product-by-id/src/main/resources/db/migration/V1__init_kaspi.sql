CREATE SEQUENCE IF NOT EXISTS customers_id START 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS sms_code_id START 1 INCREMENT BY 1;


CREATE TABLE IF NOT EXISTS customer (
    id BIGINT PRIMARY KEY DEFAULT nextval('customers_id'),
    full_name          VARCHAR(255),
    last_name          VARCHAR(255),
    iin                VARCHAR(20),
    password           VARCHAR(255) NOT NULL,
    username           VARCHAR(100),
    email              VARCHAR(255),
    phone              VARCHAR(32),
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    is_manually_edited BOOLEAN NOT NULL DEFAULT FALSE,
    id_code            VARCHAR(255),
    role               VARCHAR(50) NOT NULL,
    token_prod         TEXT,
    created_date       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_date       TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_customer_phone    ON customer(phone);

CREATE TABLE IF NOT EXISTS sms_what_code (
    id BIGINT PRIMARY KEY DEFAULT nextval('sms_code_id'),
    code  INTEGER NOT NULL,
    phone VARCHAR(32) NOT NULL,
    used  BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS ix_sms_what_code_phone ON sms_what_code(phone);