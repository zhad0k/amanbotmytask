ALTER TABLE if exists customer_lite
    ADD COLUMN if not exists is_permission_asked BOOLEAN DEFAULT FALSE;

ALTER TABLE if exists customer_lite
    ADD COLUMN if not exists is_allowed_to_send BOOLEAN DEFAULT FALSE;