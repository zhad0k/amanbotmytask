ALTER TABLE IF EXISTS customer
    ADD kaspi_email VARCHAR(255);

ALTER TABLE IF EXISTS customer
    ADD kaspi_password VARCHAR(255);

ALTER TABLE IF EXISTS customer
    ADD kaspi_phone VARCHAR(255);