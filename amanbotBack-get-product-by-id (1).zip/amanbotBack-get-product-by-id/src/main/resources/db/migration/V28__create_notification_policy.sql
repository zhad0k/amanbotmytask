CREATE TABLE IF NOT EXISTS notification_policy (
         id            BIGSERIAL PRIMARY KEY,
         customer_id   BIGINT      NOT NULL,
         allowed_from  TIME        NOT NULL,
         allowed_to    TIME        NOT NULL,
         days_mask     INTEGER     NOT NULL,
         enabled       BOOLEAN     NOT NULL DEFAULT TRUE,

         created_date   TIMESTAMPTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP,
         updated_date   TIMESTAMPTZ,
         deleted_date   TIMESTAMPTZ,

         CONSTRAINT uq_notification_policy_customer UNIQUE (customer_id),
         CONSTRAINT chk_days_mask_range CHECK (days_mask BETWEEN 0 AND 127),
         CONSTRAINT chk_allowed_from_to CHECK (allowed_from <> allowed_to)
);