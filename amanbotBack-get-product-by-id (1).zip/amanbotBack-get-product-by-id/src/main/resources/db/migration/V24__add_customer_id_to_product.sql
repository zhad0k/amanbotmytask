ALTER TABLE product ADD COLUMN customer_id BIGINT;
ALTER TABLE product
    ADD CONSTRAINT fk_product_customer FOREIGN KEY (customer_id) REFERENCES customer(id);
