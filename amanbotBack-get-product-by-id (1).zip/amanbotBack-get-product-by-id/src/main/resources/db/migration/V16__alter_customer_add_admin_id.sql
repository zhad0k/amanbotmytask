ALTER TABLE customer
    ADD COLUMN admin_id BIGINT;