-- V27: Create process_log table for logging execution time and results
-- This table stores logs for authentication and price update processes

CREATE TABLE IF NOT EXISTS process_log (
    id BIGSERIAL PRIMARY KEY,
    process_type VARCHAR(50) NOT NULL,
    customer_id BIGINT,
    customer_name VARCHAR(255),
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE,
    duration_ms BIGINT,
    status VARCHAR(20),
    error_message VARCHAR(1000),
    processed_items INTEGER,
    updated_items INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_process_log_process_type ON process_log(process_type);
CREATE INDEX IF NOT EXISTS idx_process_log_customer_id ON process_log(customer_id);
CREATE INDEX IF NOT EXISTS idx_process_log_start_time ON process_log(start_time DESC);
CREATE INDEX IF NOT EXISTS idx_process_log_status ON process_log(status);

-- Add comment to table
COMMENT ON TABLE process_log IS 'Logs for tracking execution time and results of scheduled processes';
COMMENT ON COLUMN process_log.process_type IS 'Type of process: PRICE_UPDATE, AUTH';
COMMENT ON COLUMN process_log.status IS 'Process status: IN_PROGRESS, SUCCESS, FAILED';
COMMENT ON COLUMN process_log.duration_ms IS 'Process duration in milliseconds';

