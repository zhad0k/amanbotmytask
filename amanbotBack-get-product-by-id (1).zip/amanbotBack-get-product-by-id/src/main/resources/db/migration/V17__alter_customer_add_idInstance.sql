ALTER TABLE customer
    ADD COLUMN id_instance BIGINT;