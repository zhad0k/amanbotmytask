ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS buy_notiffication boolean NOT NULL DEFAULT false;