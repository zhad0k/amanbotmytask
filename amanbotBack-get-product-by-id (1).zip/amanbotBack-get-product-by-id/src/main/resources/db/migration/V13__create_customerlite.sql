CREATE SEQUENCE customer_lite_id START WITH 1 INCREMENT BY 1;

CREATE TABLE customer_lite (
                               id BIGSERIAL PRIMARY KEY,
                               kaspi_customer_id VARCHAR(64) NOT NULL,
                               name VARCHAR(255),
                               cell_phone VARCHAR(64),
                               first_name VARCHAR(255),
                               last_name VARCHAR(255)
);

ALTER TABLE orders
    ADD COLUMN customer_lite_id BIGINT,
    ADD CONSTRAINT fk_orders_customer_lite
        FOREIGN KEY (customer_lite_id) REFERENCES customer_lite(id)
        ON DELETE CASCADE;