ALTER TABLE customer
    ADD balance DECIMAL;

ALTER TABLE moderator
    ADD image_name VARCHAR(255);

ALTER TABLE moderator
    ADD image_url VARCHAR(255);