ALTER TABLE customer
    ADD ip_name VARCHAR(255);