-- ORDERS
CREATE TABLE IF NOT EXISTS public.orders (
    id                      BIGSERIAL PRIMARY KEY,
    kaspi_id                VARCHAR(64) NOT NULL UNIQUE,
    code                    VARCHAR(64) NOT NULL UNIQUE,
    customer_id             BIGINT NOT NULL,
    total_price             DOUBLE PRECISION,
    delivery_cost_for_seller DOUBLE PRECISION,
    is_kaspi_delivery       BOOLEAN,
    pre_order               BOOLEAN,
    signature_required      BOOLEAN,
    status                  VARCHAR(64),
    state                   VARCHAR(64),
    delivery_mode           VARCHAR(128),
    payment_mode            VARCHAR(128),
    creation_date           TIMESTAMPTZ,
    approved_by_bank_date   TIMESTAMPTZ,
    planned_delivery_date   TIMESTAMPTZ,
    reservation_date        TIMESTAMPTZ,
    delivery_street_name    VARCHAR(255),
    delivery_street_number  VARCHAR(64),
    delivery_town           VARCHAR(128),
    delivery_district       VARCHAR(128),
    delivery_building       VARCHAR(128),
    delivery_apartment      VARCHAR(64),
    delivery_formatted_address VARCHAR(512),
    delivery_latitude       DOUBLE PRECISION,
    delivery_longitude      DOUBLE PRECISION,
    origin_pos_id           VARCHAR(128),
    origin_pos_display_name VARCHAR(255),
    origin_city_code        VARCHAR(64),
    origin_city_name        VARCHAR(128),
    waybill_url             TEXT,
    waybill_number          VARCHAR(128),
    courier_transmission_date TIMESTAMPTZ,
    courier_transmission_plan_date TIMESTAMPTZ,
    kaspi_express           BOOLEAN,
    returned_to_warehouse   BOOLEAN,
    assembled               BOOLEAN,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
    );


CREATE INDEX IF NOT EXISTS idx_orders_code ON public.orders(code);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);

-- PRODUCTS
CREATE TABLE IF NOT EXISTS public.products (
                                               id           BIGSERIAL PRIMARY KEY,
                                               sku          VARCHAR(128) UNIQUE,
    name         VARCHAR(255) NOT NULL,
    price        DOUBLE PRECISION NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
    );

-- ORDER_ENTRIES
CREATE TABLE IF NOT EXISTS public.order_entries (
                                                    id             BIGSERIAL PRIMARY KEY,
                                                    order_id       BIGINT NOT NULL,
                                                    kaspi_entry_id VARCHAR(64) NOT NULL UNIQUE,
    entry_number   INTEGER,
    unit_type      VARCHAR(64),
    quantity       DOUBLE PRECISION,
    weight         DOUBLE PRECISION,
    delivery_cost  DOUBLE PRECISION,
    base_price     DOUBLE PRECISION,
    total_price    DOUBLE PRECISION,
    category_code  VARCHAR(128),
    category_title VARCHAR(255),
    offer_code     VARCHAR(128),
    offer_name     VARCHAR(512),
    is_imei_required BOOLEAN,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
    );

CREATE INDEX IF NOT EXISTS idx_order_entries_order_id ON public.order_entries(order_id);



-- KASPI_REVIEWS
CREATE TABLE IF NOT EXISTS public.kaspi_reviews (
                                                    id                 BIGSERIAL PRIMARY KEY,
                                                    order_id           BIGINT NOT NULL,
                                                    order_entry_id     BIGINT,
                                                    customer_id        BIGINT NOT NULL,
                                                    sent_at            TIMESTAMPTZ,
                                                    kaspi_moment       VARCHAR(64) NOT NULL,
    kaspi_message_text TEXT,
    kaspi_clicked      BOOLEAN NOT NULL DEFAULT FALSE,
    kaspi_status       VARCHAR(64) NOT NULL,
    created_date       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_date       TIMESTAMPTZ NOT NULL DEFAULT now()
    );

CREATE INDEX IF NOT EXISTS idx_kaspi_reviews_order_id ON public.kaspi_reviews(order_id);
CREATE INDEX IF NOT EXISTS idx_kaspi_reviews_order_entry_id ON public.kaspi_reviews(order_entry_id);
CREATE INDEX IF NOT EXISTS idx_kaspi_reviews_customer_id ON public.kaspi_reviews(customer_id);




-- TRIGGERS
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'set_row_updated_at') THEN
        CREATE OR REPLACE FUNCTION set_row_updated_at()
        RETURNS trigger AS $fn$
BEGIN
            NEW.updated_at := now();
RETURN NEW;
END
        $fn$ LANGUAGE plpgsql;
END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_set_updated_at_orders') THEN
CREATE TRIGGER trg_set_updated_at_orders
    BEFORE UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION set_row_updated_at();
END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_set_updated_at_products') THEN
CREATE TRIGGER trg_set_updated_at_products
    BEFORE UPDATE ON public.products
    FOR EACH ROW EXECUTE FUNCTION set_row_updated_at();
END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_set_updated_at_order_entries') THEN
CREATE TRIGGER trg_set_updated_at_order_entries
    BEFORE UPDATE ON public.order_entries
    FOR EACH ROW EXECUTE FUNCTION set_row_updated_at();
END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_set_updated_at_kaspi_reviews') THEN
CREATE TRIGGER trg_set_updated_at_kaspi_reviews
    BEFORE UPDATE ON public.kaspi_reviews
    FOR EACH ROW EXECUTE FUNCTION set_row_updated_at();
END IF;
END $$;
