ALTER TABLE if exists customer
    ADD COLUMN if not exists balance DECIMAL(38,2);

ALTER TABLE if exists moderator
    ADD COLUMN if not exists image_url varchar(255);

ALTER TABLE if exists moderator
    ADD COLUMN if not exists image_name varchar(255);