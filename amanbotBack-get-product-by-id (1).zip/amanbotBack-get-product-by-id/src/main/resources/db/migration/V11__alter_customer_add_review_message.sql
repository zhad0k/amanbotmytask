ALTER TABLE IF EXISTS customer
    ADD kaspi_review_message VARCHAR(255);