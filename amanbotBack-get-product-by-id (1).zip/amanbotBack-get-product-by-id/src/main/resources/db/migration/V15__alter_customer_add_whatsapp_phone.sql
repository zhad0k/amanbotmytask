ALTER TABLE IF EXISTS customer
    ADD whatsapp_phone VARCHAR(255);