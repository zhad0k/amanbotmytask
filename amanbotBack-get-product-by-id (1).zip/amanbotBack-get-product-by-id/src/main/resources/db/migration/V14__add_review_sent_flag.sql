ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS review_sent boolean NOT NULL DEFAULT false;