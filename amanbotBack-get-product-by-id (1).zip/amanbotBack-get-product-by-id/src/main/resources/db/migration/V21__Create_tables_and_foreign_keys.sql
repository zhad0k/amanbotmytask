

CREATE SEQUENCE IF NOT EXISTS merchant_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS comment_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS product_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS product_price_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS kaspi_order_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE IF NOT EXISTS kaspi_order_product_id START WITH 1 INCREMENT BY 1;


CREATE TABLE IF NOT EXISTS merchant (
    id BIGINT PRIMARY KEY DEFAULT nextval('merchant_id'),
    customer_id BIGINT NOT NULL,
    name VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    enable_parsing BOOLEAN DEFAULT false,
    tariff_start_at TIMESTAMP WITH TIME ZONE,
    tariff_end_at TIMESTAMP WITH TIME ZONE,
    subscription_days BIGINT,
    login VARCHAR(255),
    password VARCHAR(255),
    token VARCHAR(255),
    price_auto_change BOOLEAN DEFAULT false,
    price_difference BIGINT,
    price_place BIGINT,
    competitors_to_exclude TEXT,
    xml_file_path VARCHAR(500),
    created_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS comment (
    id BIGINT PRIMARY KEY DEFAULT nextval('comment_id'),
    text TEXT,
    rating BIGINT,
    customer_id BIGINT NOT NULL, -- Note: keeping the typo as in entity
    created_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS product (
    id BIGINT PRIMARY KEY DEFAULT nextval('product_id'),
    merchant_id BIGINT NOT NULL,
    title VARCHAR(500),
    price BIGINT,
    current_price_place BIGINT,
    target_price_place BIGINT,
    min_price BIGINT,
    max_price BIGINT,
    code VARCHAR(255),
    available BOOLEAN DEFAULT true,
    price_auto_change BOOLEAN DEFAULT false,
    reserved_remainders BIGINT,
    sold_remainders BIGINT,
    calculated_remainders BIGINT,
    product_card_long_url TEXT,
    availabilities TEXT,
    created_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);



CREATE TABLE IF NOT EXISTS product_price (
    id BIGINT PRIMARY KEY DEFAULT nextval('product_price_id'),
    product_id BIGINT NOT NULL,
    date_of_changing TIMESTAMP WITH TIME ZONE,
    changed_price BIGINT,
    created_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS kaspi_order (
    id BIGINT PRIMARY KEY DEFAULT nextval('kaspi_order_id'),
    order_id BIGINT,
    order_date TIMESTAMP WITH TIME ZONE,
    order_type VARCHAR(255),
    order_status VARCHAR(255),
    created_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS kaspi_order_product (
    id BIGINT PRIMARY KEY DEFAULT nextval('kaspi_order_product_id'),
    kaspi_order_id BIGINT NOT NULL,
    kaspi_product_id BIGINT NOT NULL,
    created_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);



ALTER TABLE merchant DROP CONSTRAINT IF EXISTS fk_merchant_customer;
ALTER TABLE merchant
ADD CONSTRAINT fk_merchant_customer
FOREIGN KEY (customer_id) REFERENCES customer(id)
ON DELETE CASCADE ON UPDATE CASCADE;



ALTER TABLE comment DROP CONSTRAINT IF EXISTS fk_comment_customer;
ALTER TABLE comment
ADD CONSTRAINT fk_comment_customer 
FOREIGN KEY (customer_id) REFERENCES customer(id)
ON DELETE CASCADE ON UPDATE CASCADE;




ALTER TABLE product DROP CONSTRAINT IF EXISTS fk_product_merchant;
ALTER TABLE product
ADD CONSTRAINT fk_product_merchant 
FOREIGN KEY (merchant_id) REFERENCES merchant(id) 
ON DELETE CASCADE ON UPDATE CASCADE;


ALTER TABLE product_price DROP CONSTRAINT IF EXISTS fk_product_price_product;
ALTER TABLE product_price
ADD CONSTRAINT fk_product_price_product 
FOREIGN KEY (product_id) REFERENCES product(id) 
ON DELETE CASCADE ON UPDATE CASCADE;



ALTER TABLE kaspi_order_product DROP CONSTRAINT IF EXISTS fk_kaspi_order_product_order;
ALTER TABLE kaspi_order_product
ADD CONSTRAINT fk_kaspi_order_product_order 
FOREIGN KEY (kaspi_order_id) REFERENCES kaspi_order(id) 
ON DELETE CASCADE ON UPDATE CASCADE;


ALTER TABLE kaspi_order_product DROP CONSTRAINT IF EXISTS fk_kaspi_order_product_product;
ALTER TABLE kaspi_order_product
ADD CONSTRAINT fk_kaspi_order_product_product 
FOREIGN KEY (kaspi_product_id) REFERENCES product(id) 
ON DELETE CASCADE ON UPDATE CASCADE;


CREATE INDEX IF NOT EXISTS idx_merchant_customer_id ON merchant(customer_id);
CREATE INDEX IF NOT EXISTS idx_comment_customer_id ON comment(customer_id);
CREATE INDEX IF NOT EXISTS idx_product_merchant_id ON product(merchant_id);
CREATE INDEX IF NOT EXISTS idx_product_price_product_id ON product_price(product_id);
CREATE INDEX IF NOT EXISTS idx_kaspi_order_product_order_id ON kaspi_order_product(kaspi_order_id);
CREATE INDEX IF NOT EXISTS idx_kaspi_order_product_product_id ON kaspi_order_product(kaspi_product_id);
CREATE INDEX IF NOT EXISTS idx_merchant_active ON merchant(is_active);



CREATE INDEX IF NOT EXISTS idx_merchant_active ON merchant(is_active);

