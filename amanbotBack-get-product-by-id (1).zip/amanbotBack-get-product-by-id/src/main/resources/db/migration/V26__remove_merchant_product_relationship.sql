-- V26: Remove relationship between Product and Merchant
-- This migration removes the foreign key constraint and merchant_id column from product table

-- Step 1: Drop foreign key constraint if it exists
DO $$
BEGIN
    -- Check if the foreign key constraint exists and drop it
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_product_merchant' 
        AND table_name = 'product'
    ) THEN
        ALTER TABLE product DROP CONSTRAINT fk_product_merchant;
    END IF;
END $$;

-- Step 2: Drop the merchant_id column from product table
DO $$
BEGIN
    -- Check if the column exists and drop it
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'product' 
        AND column_name = 'merchant_id'
    ) THEN
        ALTER TABLE product DROP COLUMN merchant_id;
    END IF;
END $$;

-- Step 3: Drop any indexes related to merchant_id if they exist
DO $$
BEGIN
    -- Drop index if it exists
    IF EXISTS (
        SELECT 1 FROM pg_indexes 
        WHERE indexname = 'idx_product_merchant_id'
    ) THEN
        DROP INDEX idx_product_merchant_id;
    END IF;
END $$;

-- Step 4: Update the customer_id column to be NOT NULL (if it's not already)
-- This ensures that products are now directly linked to customers
DO $$
BEGIN
    -- First, update any NULL customer_id values to a default customer if needed
    -- (You might want to adjust this logic based on your business requirements)
    UPDATE product 
    SET customer_id = (
        SELECT id FROM customer 
        WHERE is_active = true 
        LIMIT 1
    )
    WHERE customer_id IS NULL;
    
    -- Then make the column NOT NULL
    ALTER TABLE product ALTER COLUMN customer_id SET NOT NULL;
EXCEPTION
    WHEN OTHERS THEN
        -- If there are still NULL values, you might need to handle them differently
        RAISE NOTICE 'Could not set customer_id to NOT NULL due to existing NULL values';
END $$;
