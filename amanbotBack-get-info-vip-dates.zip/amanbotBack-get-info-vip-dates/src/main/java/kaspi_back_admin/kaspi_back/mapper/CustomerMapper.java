package kaspi_back_admin.kaspi_back.mapper;

import kaspi_back_admin.kaspi_back.db.entities.Customer;
import kaspi_back_admin.kaspi_back.db.entities.Moderator;
import kaspi_back_admin.kaspi_back.db.enums.SearchType;
import kaspi_back_admin.kaspi_back.db.enums.TariffType;
import kaspi_back_admin.kaspi_back.dto.CustomerDetailsDto;
import kaspi_back_admin.kaspi_back.dto.CustomerDto;
import kaspi_back_admin.kaspi_back.dto.ModeratorDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.Optional;

@Component
public class CustomerMapper {
    @Value("${admin.url}")
    private String adminUrl;

    public CustomerDto toCustomerDto(Customer customer) {
        CustomerDto customerDto = new CustomerDto();
        customerDto.setFullName(nvl(customer.getFullName()));
        customerDto.setIpName(nvl(customer.getIpName()));
        customerDto.setTariff(customer.getTariffType().getDisplayName());
        customerDto.setTariffKind(String.valueOf(customer.getTariffType().getKind()));
        customerDto.setTariff(nvl(customer.getTariffType() != null ? customer.getTariffType().getDisplayName() : "Бесплатный"));
        customerDto.setTariffName(isTrial(customer) ? "Пробный" : customer.getTariffType().getDisplayName());
        customerDto.setPhone(nvl(customer.getPhone()));
        customerDto.setStartDate(customer.getTariffStartAt());
        customerDto.setEndDate(customer.getTariffEndAt());
        customerDto.setStartDateDumping(customer.getTariffStartAtDumping());
        customerDto.setEndDateDumping(customer.getTariffEndAtDumping());
        fillVipDates(customerDto, customer);
        customerDto.setManager(toModeratorDto(customer.getModerator()));
        customerDto.setPreorderEnabled(isEnabled(customer.getPreorderEnabled()));
        customerDto.setInventoryEnabled(isEnabled(customer.getInventoryEnabled()));
        customerDto.setWaybillEnabled(isEnabled(customer.getWaybillEnabled()));
        return customerDto;
    }

    public CustomerDto toDto(Customer customer) {
        CustomerDto customerDto = new CustomerDto();
        customerDto.setId(customer.getId());
        customerDto.setFullName(customer.getFullName());
        customerDto.setIpName(customer.getIpName());
        customerDto.setPhone(customer.getPhone());
        if (customer.getTariffType() != null) {
            customerDto.setTariff(customer.getTariffType().getDisplayName());
            customerDto.setTariffName(isTrial(customer) ? "Пробный" : customer.getTariffType().getDisplayName());
        }
        customerDto.setStartDate(customer.getTariffStartAt());
        customerDto.setEndDate(customer.getTariffEndAt());
        customerDto.setStartDateDumping(customer.getTariffStartAtDumping());
        customerDto.setEndDateDumping(customer.getTariffEndAtDumping());
        fillVipDates(customerDto, customer);
        customerDto.setTariff(nvl(customer.getTariffType() != null ?
                customer.getTariffType().getDisplayName() : "Бесплатный"));
        customerDto.setManager(toModeratorDto(customer.getModerator()));
        customerDto.setIdInstance(customer.getIdInstance());
        if (customer.getHasKaspiMerchantPassword() != null){
            customerDto.setHasKaspiMerchantPassword(customer.getHasKaspiMerchantPassword());
        }
        customerDto.setKaspiEmailMerchant(customer.getKaspiEmailMerchant());
        customerDto.setKaspiPasswordMerchant(customer.getKaspiPasswordMerchant());
        return customerDto;
    }

    public CustomerDto toDtoTrial(Customer customer) {
        CustomerDto dto = new CustomerDto();

        dto.setId(customer.getId());
        dto.setIpName(nvl(customer.getIpName()));
        dto.setFullName(nvl(customer.getFullName()));
        dto.setPhone(nvl(customer.getPhone()));
        dto.setActive(customer.isActive());
        dto.setManager(toModeratorDto(customer.getModerator()));
        dto.setIdInstance(customer.getIdInstance());

        dto.setHasKaspiMerchantPassword(
                Optional.ofNullable(customer.getHasKaspiMerchantPassword()).orElse(false)
        );
        dto.setKaspiEmailMerchant(customer.getKaspiEmailMerchant());
        dto.setKaspiPasswordMerchant(customer.getKaspiPasswordMerchant());
        dto.setKaspiMerchantId(customer.getMerchantId());

        dto.setManager(toModeratorDto(customer.getModerator()));

        TariffType tariff = customer.getTariffType();
        if (tariff == null) {
            return dto;
        }
        dto.setTariff(tariff.name());
        dto.setTariffKind(tariff.getKind().name());
        dto.setTariffName(isTrial(customer) ? "Пробный" : tariff.getDisplayName());
        dto.setIsTrial(customer.getIsTrial());

        dto.setPreorderEnabled(isEnabled(customer.getPreorderEnabled()));
        dto.setInventoryEnabled(isEnabled(customer.getInventoryEnabled()));
        dto.setWaybillEnabled(isEnabled(customer.getWaybillEnabled()));

        dto.setStartDate(customer.getTariffStartAt());
        dto.setEndDate(customer.getTariffEndAt());
        dto.setStartDateDumping(customer.getTariffStartAtDumping());
        dto.setEndDateDumping(customer.getTariffEndAtDumping());

        if (tariff.getKind() == TariffType.Kind.VIP) {
            dto.setStartDateVip(customer.getTariffStartAt());
            dto.setEndDateVip(customer.getTariffEndAt());
        }
        fillVipDates(dto, customer);

        return dto;
    }

    private ModeratorDto toModeratorDto(Moderator moderator) {
        if (moderator == null) {
            return null;
        }
        return ModeratorDto.builder()
                .id(moderator.getId())
                .name(moderator.getUsername())
                .phone(moderator.getPhone())
                .imageName(moderator.getImageName())
                .imageUrl(adminUrl + moderator.getImageUrl())
                .build();
    }

    private String nvl(String value) {
        return value != null ? value : "";
    }

    public CustomerDetailsDto toSearchDto(Customer customer, SearchType searchType) {
        OffsetDateTime start = searchType.getStartDate(customer);
        OffsetDateTime end = searchType.getEndDate(customer);
        OffsetDateTime startDumping = searchType.getStartDateDumping(customer);
        OffsetDateTime endDumping = searchType.getEndDateDumping(customer);

        Integer activeSlots = searchType.getActiveSlots(customer);
        Integer remainingSlots = searchType.getActiveSlots(customer);

        CustomerDetailsDto dto = new CustomerDetailsDto();
        dto.setId(customer.getId());
        dto.setIpName(nvl(customer.getIpName()));
        dto.setPhone(nvl(customer.getPhone()));
        dto.setStartDateDumping(startDumping);
        dto.setEndDateDumping(endDumping);
        dto.setStartDate(start);
        dto.setEndDate(end);
        dto.setActive(end != null && end.isAfter(OffsetDateTime.now()));
        dto.setActiveSlots(activeSlots);
        dto.setRemainingSlots(remainingSlots);
        dto.setTariffName(isTrial(customer) ? "Пробный" : customer.getTariffType().getDisplayName());
        dto.setTariff(nvl(customer.getTariffType() != null ?
                customer.getTariffType().name() : "Бесплатный"));
        dto.setTariffKind(customer.getTariffType().getKind().name());
        dto.setManagerDto(toModeratorDto(customer.getModerator()));
        dto.setInstanceId(searchType.getIdInstance(customer));
        dto.setKaspiEmail(searchType.getKaspiMerchantEmail(customer));
        dto.setKaspiPassword(searchType.getKaspiMerchantPassword(customer));
        dto.setHasKaspiMerchantPassword(Optional.ofNullable(customer.getHasKaspiMerchantPassword()).orElse(false));
        dto.setDumpingTariff(searchType.getDumpingTariff(customer));
        dto.setPreorderEnabled(isEnabled(customer.getPreorderEnabled()));
        dto.setInventoryEnabled(isEnabled(customer.getInventoryEnabled()));
        dto.setWaybillEnabled(isEnabled(customer.getWaybillEnabled()));
        return dto;
    }

    private void fillVipDates(CustomerDto dto, Customer customer) {
        if (customer.getTariffType() != null
                && customer.getTariffType().getKind() == TariffType.Kind.VIP) {
            dto.setStartDateVip(customer.getTariffStartAt());
            dto.setEndDateVip(customer.getTariffEndAt());
        }
    }
    private boolean isEnabled(Boolean enabled) {
        return enabled != null && enabled;
    }

    private boolean isTrial(Customer c) {
        return Boolean.TRUE.equals(c.getIsTrial());
    }
}
